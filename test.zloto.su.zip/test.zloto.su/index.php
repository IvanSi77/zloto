<?php


require_once('config.php');


// ____________________ ���� �� ������� ____________________


if(!empty($_GET['ads']) && !empty($_GET['id'])){


$ads_name=preg_replace("#[^a-z\_\-0-9]+#i",'','ads_'.$_GET['ads'].'_m');
$ads_name=substr($ads_name,0,30);
$ads_name=strtolower($ads_name);


if(empty($ads_name) || strlen($ads_name)<8 || empty($$ads_name)){ exit; }


$ads_name=str_replace('_m','',$ads_name);
$ads_name_data=preg_replace("#\_[0-9]{1,10}$#i",'',$ads_name);


$id=preg_replace('#[^0-9]+#','',$_GET['id']);
$id=number_format($id,0,'','');


if(empty($id) || !is_numeric($id) || strlen($id)>10){ exit; }


$s_q=mysqli_query($db,"SELECT * FROM $ads_name WHERE id=$id LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);


$ads_url=$s_m['url'];


if(!empty($s_m['id'])){


$s_q='';
$s_m='';


// ����� ��������� �� �������������� � ���, �.�. ����� ���� ���� � ���� IP � ��������������, �� � ��� IP �� ���������, ����� ���� ���������
if($u_id>0){
$s_q=mysqli_query($db,"SELECT * FROM ads_clicks WHERE uid=$u_id AND name='$ads_name' AND num=$id LIMIT 1");
}
if(empty($u_id) && empty($chain_1_clicks_auth_m)){
$s_q=mysqli_query($db,"SELECT * FROM ads_clicks WHERE uid=0 AND ip='$ip' AND name='$ads_name' AND num=$id LIMIT 1");
}


if($s_q!=''){ $s_m=mysqli_fetch_assoc($s_q); }


// ���� ����� ���, �� ����������� � ���������� ����
if($s_q!='' && empty($s_m['id'])){


mysqli_query($db,"UPDATE $ads_name SET date_2='$time',date_2_word='".date("d.m.y H:i:s",$time)."',clicks=clicks+1 WHERE id=$id LIMIT 1") or die('cant update click '.$ads_name);
mysqli_query($db,"UPDATE data SET ".$ads_name_data."_clicks=".$ads_name_data."_clicks+1 LIMIT 1") or die('cant update data '.$ads_name.'_clicks');
mysqli_query($db,"INSERT INTO ads_clicks SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',uid=$u_id,login='".$mydm['login']."',avatar='".$mydm['avatar']."',ip='$ip',name='$ads_name',num=$id") or die('cant insert ads_clicks '.$ads_name.' num '.$id);


}


// ���� ������� �������, �� ��������������
header('Location: '.$ads_url);


}
}


// ____________________ ������ ____________________


$s_q=mysqli_query($db,"SELECT * FROM data LIMIT 1") or die('cant select data');
$d=mysqli_fetch_assoc($s_q);
if(!isset($d['users'])){ exit('data error'); }


// ____________________ ����� ____________________


$kassa=$d['up_payeer_s']*(100-$kassa_pr_p)/100+$d['up_fk_s']*(100-$kassa_pr_fk)/100-$d['w_payeer_s']-$d['w_fk_s']+$d['kassa_change_s']-$d['admin_up_m_r']-$d['admin_ms_r']-$d['admin_gizmo_r']-$d['admin_serf_r']-$d['admin_ads_r']-$d['admin_deps_r']-$d['admin_def_r'];
$kassa=number_format($kassa,2,'.','');


// ____________________ ������ ������ �����������, ������ ���������, ����� �� �������� ____________________


if($u_id>0 && !empty($mydm['uid']) && (empty($_SESSION['my_time']) || $_SESSION['my_time']<$time-3600)){
$_SESSION['my_time']=$time;
if($auth_m==1){
$auth_f=0; $auth_t=''; $auth=array(); eval($d['auth']);
for($n=0;$n<sizeof($auth);$n++){ if($auth[$n][0]==$mydm['uid']){ $auth_f=1; break; } }
if($auth_f==0){
array_unshift($auth,array($mydm['uid'],$mydm['avatar'],$mydm['login']));
for($n=0;$n<$auth_c;$n++){
if(empty($auth[$n])){ break; }
$auth_t.='$auth[]=array('.$auth[$n][0].',"'.$auth[$n][1].'","'.$auth[$n][2].'");';
}
mysqli_query($db,"UPDATE data SET auth='$auth_t'");
}
}
mysqli_query($db,"UPDATE users SET date_2='$time',date_2_word='".date('d.m.y H:i:s',$time)."',ip_came='$ip' WHERE uid='$u_id' LIMIT 1");
}


// ____________________ ������� �������� ____________________


if($u_id>0 && !empty($mydm['sp_uid_1']) && (empty($_SESSION['rb_time']) || $_SESSION['rb_time']<$time-1800)){
$_SESSION['rb_time']=$time;
if(!isset($_SESSION['up_m_rb'])){ $_SESSION['up_m_rb']=0; }
if(!isset($_SESSION['serf_rb'])){ $_SESSION['serf_rb']=0; }
if(!isset($_SESSION['ads_rb'])){ $_SESSION['ads_rb']=0; }
if(!isset($_SESSION['ms_rb'])){ $_SESSION['ms_rb']=0; }
if(!isset($_SESSION['gizmo_rb'])){ $_SESSION['gizmo_rb']=0; }
if(!isset($_SESSION['deps_rb'])){ $_SESSION['deps_rb']=0; }
$s_q=mysqli_query($db,"SELECT ban,login,up_m,up_m_rb,serf_rb,ads_rb,ms_rb,gizmo_rb,deps_rb FROM users WHERE uid=".$mydm['sp_uid_1']." LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(empty($s_m) || $s_m['ban']==1){ $set_up_m_rb=0; $set_serf_rb=0; $set_ads_rb=0; $set_ms_rb=0; $set_gizmo_rb=0; $set_deps_rb=0; }
else{
if(empty($s_m['login'])){ echo 'no sp login'; exit; }
if(!isset($s_m['up_m_rb']) || !is_numeric($s_m['up_m_rb']) || $s_m['up_m_rb']>100){ echo 'no refback up_m_rb'; exit; }
if(!isset($s_m['serf_rb']) || !is_numeric($s_m['serf_rb']) || $s_m['serf_rb']>100){ echo 'no refback serf_rb'; exit; }
if(!isset($s_m['ads_rb']) || !is_numeric($s_m['ads_rb']) || $s_m['ads_rb']>100){ echo 'no refback ads_rb'; exit; }
if(!isset($s_m['ms_rb']) || !is_numeric($s_m['ms_rb']) || $s_m['ms_rb']>100){ echo 'no refback ms_rb'; exit; }
if(!isset($s_m['gizmo_rb']) || !is_numeric($s_m['gizmo_rb']) || $s_m['gizmo_rb']>100){ echo 'no refback gizmo_rb'; exit; }
if(!isset($s_m['deps_rb']) || !is_numeric($s_m['deps_rb']) || $s_m['deps_rb']>100){ echo 'no refback deps_rb'; exit; }
$set_up_m_rb=$s_m['up_m_rb'];
$set_serf_rb=$s_m['serf_rb'];
$set_ads_rb=$s_m['ads_rb'];
$set_ms_rb=$s_m['ms_rb'];
$set_gizmo_rb=$s_m['gizmo_rb'];
$set_deps_rb=$s_m['deps_rb'];
if($up_m_refback_m>=1  && $s_m['up_m']<$up_m_refback_m){ $set_up_m_rb=0; }
if(!empty($rb_other_m) && $s_m['up_m']<$rb_other_m){ $set_serf_rb=0; $set_ads_rb=0; $set_ms_rb=0; $set_gizmo_rb=0; $set_deps_rb=0; }
}
if(empty($_SESSION['sp_login_1']) || $_SESSION['sp_login_1']!=$s_m['login']){ $_SESSION['sp_login_1']=$s_m['login']; }
if(isset($set_up_m_rb) && $_SESSION['up_m_rb']!=$set_up_m_rb){ $_SESSION['up_m_rb']=$set_up_m_rb; }
if(isset($set_serf_rb) && $_SESSION['serf_rb']!=$set_serf_rb){ $_SESSION['serf_rb']=$set_serf_rb; }
if(isset($set_ads_rb) && $_SESSION['ads_rb']!=$set_ads_rb){ $_SESSION['ads_rb']=$set_ads_rb; }
if(isset($set_ms_rb) && $_SESSION['ms_rb']!=$set_ms_rb){ $_SESSION['ms_rb']=$set_ms_rb; }
if(isset($set_gizmo_rb) && $_SESSION['gizmo_rb']!=$set_gizmo_rb){ $_SESSION['gizmo_rb']=$set_gizmo_rb; }
if(isset($set_deps_rb) && $_SESSION['deps_rb']!=$set_deps_rb){ $_SESSION['deps_rb']=$set_deps_rb; }
}


// ____________________ Ѩ����� - ������ ������ � ������ ____________________


if($u_id>0){
if(!isset($_SESSION['serf_clicks_data'])){
$pre='';
$s_q=mysqli_query($db,"SELECT num,date_2 FROM serf_clicks WHERE uid=$u_id AND date_2>$time AND status!=0") or die('cant select serf_clicks');
while($s_m=mysqli_fetch_assoc($s_q)){ $pre.=$s_m['num'].'-'.$s_m['date_2'].'|'; }
$_SESSION['serf_clicks_data']=$pre;
}
preg_match_all('#(\d+)\-(\d+)\|#',$_SESSION['serf_clicks_data'],$m);
$serf_my_clicks=array();
$serf_menu_clicks='';
$pre='';
if(!empty($m[1])){
for($n=0;$n<sizeof($m[1]);$n++){
if($m[2][$n]>$time){ $serf_my_clicks[]=$m[1][$n]; $serf_menu_clicks.=$m[1][$n].','; $pre.=$m[0][$n]; }
}
}
if($_SESSION['serf_clicks_data']!=$pre){ $_SESSION['serf_clicks_data']=$pre; }
if(!empty($serf_menu_clicks)){
$serf_menu_clicks=trim($serf_menu_clicks,',');
$serf_menu_clicks='id NOT IN('.$serf_menu_clicks.') AND';
}
}


// ____________________ ������������ �� ��������� ������ ____________________


if(isset($_GET['mobile']) && ($_GET['mobile']==0 || $_GET['mobile']==1)){
if($_GET['mobile']==0){ $_SESSION['mobile']=0; setcookie('mobile',0,$time+31536000,'/','',0); $mobile=0; }
else{ $_SESSION['mobile']=1; setcookie('mobile',1,$time+31536000,'/','',0); $mobile=1; }
}


// ____________________ �������� ____________________


$page='';
if(!empty($_GET['page'])){
$page=preg_replace("#[^a-z\_\-0-9]+#i",'',$_GET['page']);
$page=substr($page,0,30);
$page=strtolower($page);
}


// ____________________ ������� �������� ____________________


if(!empty($_GET['ref']) && empty($_SESSION['sp_uid_1']) && empty($_SESSION['uid'])){
session_unset();
$_GET['ref']=preg_replace("#[^0-9]+#i",'',$_GET['ref']);
$_GET['ref']=number_format($_GET['ref'],0,'','');
$_GET['ref']=(int)$_GET['ref'];
if(!empty($_GET['ref']) && is_numeric($_GET['ref']) && strlen($_GET['ref'])<11){
$s_q=mysqli_query($db,"SELECT uid FROM users WHERE uid='".$_GET['ref']."' LIMIT 1") or die('cant get sp uid');
$s_m=mysqli_fetch_row($s_q);
if(!empty($s_m[0])){ $_SESSION['sp_uid_1']=$s_m[0]; }
}
}


// ____________________ ������ ���ب� ____________________


if(empty($_SESSION['uid']) && !isset($_SESSION['url_from']) && !empty($_SERVER['HTTP_REFERER'])){
$url_from=preg_replace('#[^a-z0-9\.\?\/\:\=\-\_]+#i','',$_SERVER['HTTP_REFERER']);
$url_from=preg_replace('#([^\/]*\/\/[^\/]*).*#','$1',$url_from);
$url_from=substr($url_from,0,100);
if(strlen($url_from)>100){ echo 'too big url_from length'; exit; }
$_SESSION['url_from']=$url_from;
}


// ____________________ ������ - ���������� ____________________


if(!empty($mydm['uid'])){
mysqli_query($db,"UPDATE users SET date_2='$time' WHERE uid='$u_id' LIMIT 1") or die('cant update date_2');
$ioq=mysqli_query($db,"SELECT id FROM online WHERE uid='".$mydm['uid']."' LIMIT 1") or die ('cant online 1');
$iom=mysqli_fetch_row($ioq);
$ion=1;
if(empty($iom[0])){
mysqli_query($db,"INSERT INTO online (ip,last_time,uid,login,avatar) VALUES ('$ip','".($time+$online_time*60)."','".$mydm['uid']."','".$mydm['login']."','".$mydm['avatar']."')") or die ('cant online 2');
$ion=0;
}
if($ion==1){
mysqli_query($db,"UPDATE online SET last_time='".($time+$online_time*60)."' WHERE uid='".$mydm['uid']."' LIMIT 1") or die ('cant online 3');
}
}


// ____________________ ������ - ������ ____________________


$who_online='';
$who_count=0;


$who_q=mysqli_query($db,"SELECT uid,login,avatar FROM online ORDER BY id DESC");
while($who_m=mysqli_fetch_row($who_q)){
$who_count++;
$profile_link=md5($who_m[0].$profile_hash);
$profile_link=$who_m[0].'_'.substr($profile_link,0,4);
if($u_id==$admin_uid){
$who_online.='<span>
<a target="_blank" href="/profile/'.$profile_link.'">
<table class="head_who_online_table" cellpadding="0px" cellspacing="0px">
<tr><td><img src="'.$who_m[2].'"></td><td><span>'.$who_m[1].'</span></td></tr>
</table>
</a>
</span>';
}
else{
$who_online.='<span>
<table class="head_who_online_table" cellpadding="0px" cellspacing="0px">
<tr><td><img src="'.$who_m[2].'"></td><td><span>'.$who_m[1].'</span></td></tr>
</table>
</span>';
}
}


if($who_count==0){ $who_online='<div>������ ������ ���</div>'; }


// ____________________ ������ - �������� ____________________


if($d['online_opt']<$time){
mysqli_query($db,"DELETE FROM online WHERE last_time<$time");
mysqli_query($db,"OPTIMIZE TABLE online") or die('cant optimize online');
mysqli_query($db,"UPDATE data SET online_opt='".($time+60)."' LIMIT 1") or die('cant update online_opt');
}


// ____________________ ������� �� F ����˨� ____________________


if($fk_m==1 && $d['fk_b']>=10 && $d['fk_time']<$time){


mysqli_query($db,"UPDATE data SET fk_time='".($time+60)."' LIMIT 1") or die('cant data');


$data=array('shopId'=>$fk_id,'nonce'=>time(),'i'=>1,'account'=>$fk_wallet_id,'amount'=>$d['fk_b'],'currency'=>'RUB');
ksort($data);
$sign=hash_hmac('sha256',implode('|',$data),$fk_api_key);
$data['signature']=$sign;
$data=json_encode($data);


$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,'https://api.freekassa.ru/v1/withdrawals/create');
curl_setopt($curl,CURLOPT_HEADER,0);
curl_setopt($curl,CURLOPT_FAILONERROR,0);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_TIMEOUT,10);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
$result=trim(curl_exec($curl));
curl_close($curl);
$result=json_decode($result,true);
if(!empty($result['type']) && $result['type']=='success'){
mysqli_query($db,"UPDATE data SET fk_b=0 LIMIT 1") or die('cant data');
}


}


// ____________________ ���������� ������ ____________________


$now_d=date('j',$time);


//____________________ ��������� �����, �������, ����� ____________________


if($now_d==$d['day']){
mysqli_query($db,"UPDATE data SET v_n=v_n+1,v_t=v_t+1 LIMIT 1") or die('cant update views');
}


if($now_d!=$d['day']){
// ������� ������ ������ REQUEST
mysqli_query($db,'DELETE FROM request WHERE date<'.($time-$history_request*86400));
// ������� ������ ������ ����������� ����������
mysqli_query($db,'DELETE FROM refs_profit WHERE date<'.($time-$history_refs_profit*86400));
// ������� ������ ������ ������ �� �������
mysqli_query($db,'DELETE FROM ads_clicks WHERE date<'.($time-$ads_clicks_history*86400));
// ������� ������ ������ ���������� � ������� �� �����
if(!empty($history_balance_up_w)){ mysqli_query($db,'DELETE FROM balance_up_w WHERE date<'.($time-$history_balance_up_w*86400)); }
// ������� ������ �����������, ���� ����� �� ��������
mysqli_query($db,'UPDATE users SET message="" WHERE date_2<'.($time-30*86400));
// �������� ���������� �������� ������� � Ѩ������
if(!empty($serf_w_reset_m)){
mysqli_query($db,'UPDATE users SET serf_w=0');
}
// ��������� ������
if($reviews_m==1 && $reviews_main==1 && $reviews_last_rnd==0){
$reviews_last='';
$reviews_last_a=array();
$s_q=mysqli_query($db,"SELECT * FROM reviews WHERE modering=0 ORDER BY id DESC LIMIT 1000") or die('cant select reviews last');
while($s_m=mysqli_fetch_assoc($s_q)){
$reviews_last_a[]=$s_m;
}
shuffle($reviews_last_a);
for($n=0;$n<3;$n++){
if(!isset($reviews_last_a[$n]['uid'])){ break; }
$reviews_last_a[$n]['text']=substr($reviews_last_a[$n]['text'],0,300);
$reviews_last_a[$n]['text']=str_replace('"',"\\'",$reviews_last_a[$n]['text']);
$reviews_last_a[$n]['text']=preg_replace('#\<[^>]*$#mi','',$reviews_last_a[$n]['text']);
$reviews_last.='$reviews_last[]=array('.$reviews_last_a[$n]['uid'].',\"'.$reviews_last_a[$n]['avatar'].'\",\"'.$reviews_last_a[$n]['login'].'\",\"'.$reviews_last_a[$n]['text'].'\");';
}
if($reviews_last!=''){ $reviews_last_t=',reviews_last=\''.$reviews_last.'\''; }
}
// �������� ���������� ����� ������������������ �������������
mysqli_query($db,"UPDATE data SET users_real_today=0,users_pseudo_today=0,day=$now_d,v_y=v_n,v_n=1,v_t=v_t+1$reviews_last_t LIMIT 1") or die('cant update');
// ������� ������ �������� ������� �������
$rw_a=array();
$rw_q=mysqli_query($db,"SELECT num,id FROM room_winners ORDER BY id DESC") or die ('cant select room_winners');
while($rw_m=mysqli_fetch_row($rw_q)){
if(!isset($rw_a[$rw_m[0]])){ $rw_a[$rw_m[0]]=array(0,0); }
if($rw_a[$rw_m[0]][0]<15){
$rw_a[$rw_m[0]][0]++;
$rw_a[$rw_m[0]][1]=$rw_m[1];
}
}
foreach($rw_a as $rw_i=>$rw_v){
if($rw_v[0]==15){
mysqli_query($db,"DELETE FROM room_winners WHERE num=".$rw_i." AND id<".$rw_v[1]);
}
}
// ������� ������ ��������� � �������� � ���������
mysqli_query($db,"DELETE FROM support WHERE date<".($time-$support_message_h*86400)." OR (type!='' AND date<".($time-60).")") or die('cant delete support');
// ������������ �������
mysqli_query($db,"OPTIMIZE TABLE ads_clicks,promocode_a,promocode_v,reviews,games,balance_up_w,balance_w,request,refs_profit,room_status,room_winners,users,data,support") or die('cant optimize common');
// ������� ������ ���� �� ����
$s_q=mysqli_query($db,"SELECT date FROM chat_message ORDER BY id ASC LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(!empty($s_m['date'])){
$chat_p_dir=opendir($_SERVER['DOCUMENT_ROOT'].'/chat/photo/') or die('cant opendir chat photo');
while($chat_p_file=readdir($chat_p_dir)){
if($chat_p_file!='.' && $chat_p_file!='..'){
$chat_p_time=preg_replace('#(\d{10}).*#','\1',$chat_p_file);
if(is_numeric($chat_p_time) && strlen($chat_p_time)==10 && $s_m['date']-60>$chat_p_time){
unlink($_SERVER['DOCUMENT_ROOT'].'/chat/photo/'.$chat_p_file) or die('cant delete chat photo');
}}}
closedir($chat_p_dir);
}
// ������� ������ ���� �� ���������
$support_photo_h=$time-$support_photo_h*86400;
$support_photo_exist=array();
$s_q=mysqli_query($db,"SELECT message FROM support WHERE message LIKE '%photo/%'") or die('cant select support photo');
while($s_m=mysqli_fetch_assoc($s_q)){
preg_match_all('#support\/photo\/(\d{10})#mi',$s_m['message'],$m);
if(!empty($m[1])){ foreach($m[1] as $v){ $support_photo_exist[]=$v; }}}
$support_p_dir=opendir($_SERVER['DOCUMENT_ROOT'].'/support/photo/') or die('cant opendir support photo');
while($support_p_file=readdir($support_p_dir)){
if($support_p_file!='.' && $support_p_file!='..'){
$support_p_time=preg_replace('#(\d{10}).*#','\1',$support_p_file);
if(is_numeric($support_p_time) && strlen($support_p_time)==10 && ($support_photo_h>$support_p_time || !in_array($support_p_time,$support_photo_exist))){
unlink($_SERVER['DOCUMENT_ROOT'].'/support/photo/'.$support_p_file) or die('cant delete support photo');
}}}
closedir($support_p_dir);
// ������� ������ ������
$ses_t=$time-5*86400; // ����� ������� ���� ������� ������ ����������� ������������
$ses_p=ini_get('session.save_path').'/';
if(empty($ses_p)){ echo 'no session.save_path'; exit; }
$ses_d=opendir($ses_p);
while($ses_f=readdir($ses_d)){
$ses_s=filesize($ses_p.$ses_f);
if($ses_f!='.' && $ses_f!='..' && $ses_f!='.htaccess' && $ses_f!='index.html' && ((is_numeric($ses_s) && $ses_s<230) || (filemtime($ses_p.$ses_f)<$ses_t))){
@unlink($ses_p.$ses_f);
}}
closedir($ses_d);
clearstatcache();
}


// ____________________ �������� ____________________


$title=$site_title;
$include='no';
$text_1='';
$text_2='';
$text_3='';
$admin_panel=0;


$pads=0;


if($mobile==0){ $left_width='width="210px"'; $pads=10; $common_height='height="100%"'; }


$text_1.='<a name="tomenu"></a>
<table class="common" width="100%" '.$common_height.' cellpadding="0px" cellspacing="'.$pads.'px">
<tr>
<td class="left"'.$left_width.'>';


if($mobile==0){ $text_2.='</td><td class="center">'; }
else{ $text_2.='</td><tr><td class="center">'; }


if($include=='no' && $u_id==0 && $page=='login'){ $include='pages/login.php'; }


if($include=='no' && !empty($inc_pages[$page])){ $title=$inc_pages[$page]; $include='pages/'.$page.'.php'; }


if($include=='no' && $u_id>0 && !empty($inc_cabinet[$page])){
$title=$inc_cabinet[$page];
if($page=='chat'){ $include='chat/chat.php'; }
elseif($page=='support_dialog'){ $include='support/support_dialog.php'; }
else{ $include='cabinet/'.$page.'.php'; }
}


if($include=='no' && $u_id>0 && !empty($inc_games[$page])){
$title=$inc_games[$page];
$include='games/'.$page.'/'.$page.'.php';
}


if($include=='no' && $u_id>0 && $u_id==$admin_uid && in_array($page,$inc_admin)){
if(empty($is_admin)){ $admin_auth=1; $include='admin/a_auth.php'; }
else{ $admin_panel=1; }
}


// ____________________ HEADER ____________________


require_once("pages/head.php");


// ____________________ ����� ���� ��� ������� ____________________


if(empty($main_m) && $include=='no' && empty($admin_panel)){ $page=''; $include='pages/main.php'; }
else{
echo $text_1;
require_once("pages/left.php");
echo $text_2;
$text_3='</td></tr></table>';
}


// ____________________ �������� ��� ������� ____________________


if(empty($admin_panel)){
if(!empty($main_m) && $include=='no'){ $include='pages/main.php'; }
if($page=='support_dialog'){
try{
require_once($include);
}catch(Throwable $support_error){
error_log('Zend-Loto support dialog fatal: '.$support_error->getMessage().' in '.$support_error->getFile().':'.$support_error->getLine());
http_response_code(500);
echo '<div class="sd_stop">�� ������� ��������� �������� ���������. ������ �������� � ������ PHP; ���������� �������� �������� �����.</div>';
}
}
else{ require_once($include); }
}


// ____________________ ������� ____________________


if(!empty($admin_panel) || (!empty($admin_auth) && $is_admin==1)){
if($page=='support_main'){ require_once('support/support_main.php'); }
else{
$a_menu='<div class="a_menu_div">
<a class="a_menu_0" href="/?page=a_stat">����������</a>
<a class="a_menu_0" href="/?page=a_users">������������</a>
<a class="a_menu_0" href="/?page=a_top_traffic">��� ������</a>
<a class="a_menu_0" href="/?page=a_up_m">����������</a>
<a class="a_menu_0" href="/?page=a_w">�������</a>
<a class="a_menu_0" href="/?page=a_rp">�����������</a>
<a class="a_menu_0" href="/?page=a_deps">������������</a>
<a class="a_menu_0" href="/?page=a_promocode_a">���������</a>
<a class="a_menu_0" href="/?page=a_serf_u">Ѹ�����</a>
<a class="a_menu_0" href="/?page=a_serf_c">�����</a>
<a class="a_menu_0" href="/?page=a_news_list">�������</a>
<a class="a_menu_0" href="/?page=a_bots">����</a>
<a class="a_menu_0" href="/?page=a_lottery">�������</a>
<a class="a_menu_0" href="/?page=a_options">���������</a>
</div>
<div id="a_message" class="a_message"></div>';
$a_menu=str_replace("\r\n",'',$a_menu);
$a_menu=str_replace("\n",'',$a_menu);
$a_menu=str_replace('0" href="/?page='.$page,'1" href="/?page='.$page,$a_menu);
echo '<div class="a_common">'.$a_menu;
require_once('admin/'.$page.'.php');
echo '</div>';
}
}


echo $text_3;


// ____________________ ������ ____________________


if($mobile==0 && !empty($ads_banner_4_m)){


$ads_value=str_replace('<','$ads_banner_4_last[]=array(',$d['ads_banner_4_last']);
$ads_banner_4_last=array();
eval($ads_value);
for($n=0;$n<sizeof($ads_banner_4_last);$n++){
if($ads_banner_4_last[$n][1]<$time){ array_splice($ads_banner_4_last,$n,1); $n--; }
}
shuffle($ads_banner_4_last);
echo '<div class="footer_banner_4">';
for($n=0;$n<$ads_banner_4_c;$n++){
if(!empty($ads_banner_4_last[$n])){ echo '<a target="_blank" href="'.$serf_site.'/?ads=banner_4&id='.$ads_banner_4_last[$n][0].'"><img src="'.$ads_banner_4_last[$n][2].'"></a>'; }
else{ echo '<a target="_blank" href="'.$serf_site.'/ads_banner_4/"><img src="'.$serf_site.'/images/cabinet/ads_is_banner/100100.gif"></a>'; }
}
echo '</div>';


}


// ____________________ FOOTER ____________________


if(!empty($mobile) && !empty($page)){ echo '<div class="footer" style="margin-bottom:30px;">'; }
else{ echo '<div class="footer">'; }


if($translate==1){


echo '<div id="translate" style="display:none;">
<a href="#" onclick="doGTranslate(\'ru|ar\');return false;" class="gflag nturl" style="background-position:-100px -0px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30"/></a>
<a href="#" onclick="doGTranslate(\'ru|az\');return false;" class="gflag nturl" style="background-position:-500px -600px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|be\');return false;" class="gflag nturl" style="background-position:-0px -600px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|en\');return false;" class="gflag nturl" style="background-position:-0px -0px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|fr\');return false;" class="gflag nturl" style="background-position:-200px -100px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|de\');return false;" class="gflag nturl" style="background-position:-300px -100px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|ko\');return false;" class="gflag nturl" style="background-position:-0px -200px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|zh-CN\');return false;" class="gflag nturl" style="background-position:-300px 0px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|ja\');return false;" class="gflag nturl" style="background-position:-700px -100px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|ru\');return false;" class="gflag nturl" style="background-position:-500px -200px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
<a href="#" onclick="doGTranslate(\'ru|uk\');return false;" class="gflag nturl" style="background-position:-100px -400px;"><img src="//gtranslate.net/flags/blank.png" height="30" width="30" /></a>
</div>


<style type="text/css">
a.gflag {vertical-align:middle;font-size:32px;padding:1px 0;background-repeat:no-repeat;background-image:url(//gtranslate.net/flags/32.png);}
a.gflag img {border:0;}
a.gflag:hover {background-image:url(//gtranslate.net/flags/32a.png);}
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
</style>


<div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() { new google.translate.TranslateElement({pageLanguage: \'ru\',autoDisplay: false}, \'google_translate_element2\');}
</script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
function GTranslateFireEvent(a,b) {
try {
if(document.createEvent) {
var c = document.createEvent("HTMLEvents");
c.initEvent(b, true, true);
a.dispatchEvent(c)
} else {
var c = document.createEventObject();
a.fireEvent("on" + b, c)
}
} catch(e) {}
}
function doGTranslate(a) {
if(a.value) a = a.value;
if(a == "") return;
var b = a.split("|")[1];
var c;
var d = document.getElementsByTagName("select");
for (var i = 0; i < d.length; i++) if (d[i].className == "goog-te-combo") c = d[i];
if (document.getElementById("google_translate_element2") == null || document.getElementById("google_translate_element2").innerHTML.length == 0 || c.length == 0 || c.innerHTML.length == 0) {
setTimeout(function () {
doGTranslate(a)
},
500)
} else {
c.value = b;
GTranslateFireEvent(c, "change");
GTranslateFireEvent(c, "change")
}
}
</script>';


}


echo '<div class="footer_own">� '.date('Y');


if($mobile==0){


echo ' <a href="https://freekassa.ru" target="_blank" rel="noopener noreferrer"><img src="/images/small-white-2.png" title="����� ��������" style="border-radius:6px;"></a>
<a href="https://www.fkwallet.ru"><img src="/images/iconsmall_wallet9.png" title="����� �����������"></a>
<a href="https://payeer.com/" target="_blank"><img src="/images/footer_payeer.png"></a> ';


}


if($translate==1){
echo '<span class="footer_language" title="LANGUAGE" onclick="view(\'translate\');"></span>';
}


echo '</div>


</div>';


if(empty($mobile) && !empty($ads_block) && !empty($u_id)){


echo '<span id="ads_banner" class="ads banner" style="height:1px;"></span>


<script type="text/javascript">setTimeout("ads_block_check();",1000);</script>';


}


echo '</body></html>';


?>
