<?php


$search_type=array();
$search_type['uid']=array(1,'UID ������������');
$search_type['login']=array(0,'������ ������������');
$search_type['sum']=array(1,'�����');
$search_type['percent']=array(1,'��������');
$search_type['plan']=array(1,'������ ������');


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


// ____________________ ����� ____________________


if(!empty($_POST['a_deps_s_type']) && isset($_POST['a_deps_s_text'])){
$a_deps_s_type=preg_replace("#[^a-z\_\-0-9]+#mi",'',$_POST['a_deps_s_type']);
if(!empty($search_type[$a_deps_s_type])){
$_SESSION['a_deps_s_type']=$a_deps_s_type;
$a_deps_s_text=substr($_POST['a_deps_s_text'],0,40);
$_SESSION['a_deps_s_text']=preg_replace("#[^0-9\.\+\ \-\;\&\#a-zA-Z�����������������������������������������Ũ�������������������������߯���]+#mi",'',$a_deps_s_text);
}
}


}


$np_sort_a=array();
$np_sort_a[]=array('�������','id DESC');
$np_sort_a[]=array('���� ���������','date_2 DESC');
$np_sort_a[]=array('uid','uid ASC');
$np_sort_a[]=array('��������','login ASC');
$np_sort_a[]=array('�����','sum DESC');
$np_sort_a[]=array('��������','percent DESC');
$np_sort_a[]=array('������','plan ASC');


if(isset($_GET['sort'])){
$pre=preg_replace('#[^0-9]+#','',$_GET['sort']);
$pre=preg_replace('#^[0]+#','',$pre);
$pre=number_format($pre,0,'','');
if(!empty($np_sort_a[$pre])){
$np_sort_n=$pre;
$np_sort=$np_sort_a[$pre][1];
}
}


if(!isset($np_sort_n)){ $np_sort_n=0; $np_sort=$np_sort_a[0][1]; }


// ____________________ ��� ������ ____________________


$where='';


if(!empty($_SESSION['a_deps_s_type']) && !empty($_SESSION['a_deps_s_text'])){
$a_deps_s_type=$_SESSION['a_deps_s_type'];
$a_deps_s_text=$_SESSION['a_deps_s_text'];
if($search_type[$a_deps_s_type][0]==0){
$where="WHERE $a_deps_s_type LIKE '%".$a_deps_s_text."%'";
}
if($search_type[$a_deps_s_type][0]==1){
$where="WHERE $a_deps_s_type='$a_deps_s_text'";
}
}


$np_pp=10;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM deps_list $where") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="a_np_def" href="/?page=a_deps&str=1&sort='.$np_sort_n.'#a_np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="a_np_def" href="/?page=a_deps&str=1&sort='.$np_sort_n.'#a_np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="a_np_now" href="/?page=a_deps&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="a_np_def" href="/?page=a_deps&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="a_np_def" href="/?page=a_deps&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="a_np_def" href="/?page=a_deps&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


echo '<div class="a_sort_common"><span class="a_sort_word">����������� ��: </span>';


for($n=0;$n<sizeof($np_sort_a);$n++){
$np_link_a='';
if($n==$np_sort_n){ $np_link_a='_2'; }
echo '<a class="a_sort_a'.$np_link_a.'" href="/?page=a_deps&sort='.$n.'">'.$np_sort_a[$n][0].'</a>';
}


echo '</div>


<br>


<form id="form_search" method="POST">
<table align="center" cellpadding="2px" cellspacing="0px">
<tr>';
if(!empty($_SESSION['a_deps_s_text'])){
echo '<td><div class="a_users_search_button" onclick="document.getElementById(\'a_deps_s_text\').value=\'\'; document.getElementById(\'form_search\').submit();">��������</div></td>';
}
echo '<td class="a_users_search_word">����� ��: </td>
<td>
<select class="a_users_search_select" name="a_deps_s_type">';
foreach($search_type as $s_t_i=>$s_t_v){
if(!empty($_SESSION['a_deps_s_type']) && $s_t_i==$_SESSION['a_deps_s_type']){
echo '<option value="'.$s_t_i.'" selected>'.$s_t_v[1].'</option>';
}
else{ echo '<option value="'.$s_t_i.'">'.$s_t_v[1].'</option>'; }
}
echo '</select>
</td>
<td><input id="a_deps_s_text" autocomplete="off" class="a_users_search_input" type="text" placeholder="������� �����" name="a_deps_s_text" maxlength="40" value="'.$_SESSION['a_deps_s_text'].'"><input type="hidden" name="a_time" value="'.$time.'"></td>
<td><div class="a_users_search_button" onclick="document.getElementById(\'form_search\').submit();">�����</div></td></tr>
</table>
</form>


<br>';


if(!empty($np_links)){ echo '<a name="a_np_a" class="a_np_a"></a><div class="a_np_div">'.$np_links.'</div><br>'; }


echo '<table class="a_deps_s_table" align="center" cellpadding="5px" cellspacing="0px">
<tr class="a_deps_s_title">
<td>#</td>
<td>������<br>���������</td>
<td>UID</td><td></td><td>������������</td>
<td>�����<br>�������</td>
<td>�������<br>���������</td>
<td style="padding-left:50px;">������</td>
</tr>';


$up_a=array();
$uids=array();
$la=array();


$s_q=mysqli_query($db,"SELECT * FROM deps_list $where ORDER BY $np_sort LIMIT $np_start,$np_pp");
while($s_m=mysqli_fetch_assoc($s_q)){
$up_a[]=$s_m;
if(!in_array($s_m['uid'],$uids)){ $uids[]=$s_m['uid']; }
}


if(!empty($uids)){
$suids=implode(',',$uids);
$laq=mysqli_query($db,"SELECT uid,avatar FROM users WHERE uid IN ($suids) LIMIT ".sizeof($uids)) or die ('cant select avatar');
while($lam=mysqli_fetch_row($laq)){
$la[$lam[0]]=$lam[1];
}
}


$js_a='';
$n=0;
$row_tr_n=0;


foreach($up_a as $m){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
$n++;
$id_style='';
if($n>$deps_show_my){ $id_style='id="d_'.$n.'" style="display:none;"'; }
$profile_link=md5($m['uid'].$profile_hash);
$profile_link=$m['uid'].'_'.substr($profile_link,0,4);
echo '<tr class="a_deps_s_tr_'.$row_tr_n.'" '.$id_style.'>
<td class="a_deps_s_id">'.$m['id'].'</td>
<td class="a_deps_s_date">'.date('d.m.y H:i:s',$m['date']).'<br><span>'.date('d.m.y H:i:s',$m['date_2']).'</span></td>
<td class="a_deps_s_uid">'.$m['uid'].'</td>
<td class="a_deps_s_avatar"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$la[$m['uid']].'"></a></td>
<td class="a_deps_s_login"><a target="_blank" href="/profile/'.$profile_link.'">'.$m['login'].'</a></td>
<td class="a_deps_s_sum"><font>'.$m['sum'].'</font><br><span>'.$m['percent'].'%</span></td>
<td class="a_deps_s_profit"><font>'.number_format($m['sum']*$m['percent']/100,4,'.','').' (+'.number_format($m['sum']*$m['percent']/100-$m['sum'],4,'.','').')</font><br><span id="deps_s_take_'.$n.'">+';
if($m['date_2']>$time){
echo number_format($m['sum']*$m['percent']/100/($m['date_2']-$m['date'])*($time-$m['date']),12,'.','');
}
else{
echo number_format($m['sum']*$m['percent']/100,4,'.','');
}
echo '</span></td>';


if($m['date_2']>$time){
$js_a.='deps.push(['.$n.','.($m['date_2']-$time).','.($m['date_2']-$m['date']).','.number_format($m['sum']*$m['percent']/100/($m['date_2']-$m['date'])*($time-$m['date']),12,'.','').','.(number_format($m['sum']*$m['percent']/100/($m['date_2']-$m['date']),20,'.','')).']);';
$deps_pr=number_format(($time-$m['date'])/($m['date_2']-$m['date'])*100,4,'.','');
$t_seconds=$m['date_2']-$time;
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='00�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='00�'){ $t_m=''; }
$t_w=$t_d.$t_h.$t_m.$t_s;
$t_w=preg_replace('#^0#','',$t_w);
$deps_s_status='<div><span id="deps_s_pr_'.$n.'" style="width:'.$deps_pr.'%;"><b>'.$deps_pr.'%&nbsp;'.$t_w.'</b></span></div>';
}
else{
$deps_s_status='<font>���������</font>';
}


echo '<td class="a_deps_s_status">
<table cellpadding="0" cellspacing="0">
<tr><td class="a_deps_s_status_img"><img src="/images/cabinet/deps/deps_plan_'.$m['plan'].'.png"></td><td>'.$deps_s_status.'</td></tr></table></td>
</tr>';
}


echo '</table>';


if(!empty($np_links)){ echo '<br><div class="a_np_div">'.$np_links.'</div><br>'; }


echo '<script type="text/javascript">
"use strict";


var deps=[]; '.$js_a.'


var t_start=Math.round(new Date().getTime()/1000);
var refresh=0;
var t_ms_s=new Date().getTime();


function deps_f(){
try{
for(var n=0;n<deps.length;n++){
var t_seconds=deps[n][1]-(Math.round(new Date().getTime()/1000)-t_start);
var t_elapsed=(Math.round(new Date().getTime()/1000)-t_start);
var t_ms=deps[n][1]*1000-(new Date().getTime()-t_ms_s);
var t_ms_e=new Date().getTime()-t_ms_s;
if(t_seconds<2){ refresh=1; setTimeout("location.href=location.href",2000); }
else{
var t_d=parseInt(t_seconds/86400); var t_h=parseInt((t_seconds-t_d*86400)/3600); var t_m=parseInt((t_seconds-t_d*86400-t_h*3600)/60); var t_s=parseInt(t_seconds-t_d*86400-t_h*3600-t_m*60);
if(t_h<10){ t_h="0"+t_h; } if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_d+="�"; t_h+="�"; t_m+="�"; t_s+="�";
if(t_d=="0�"){ t_d=""; } if(t_d=="" && t_h=="00�"){ t_h=""; } if(t_d=="" && t_h=="" && t_m=="00�"){ t_m=""; }
var t_w=t_d+t_h+t_m+t_s;
t_w=t_w.replace(/^0/,"");
var deps_pr=((deps[n][2]*1000-t_ms)/(deps[n][2]*1000)*100).toFixed(4);
if(deps_pr>100){ deps_pr=100; }
document.getElementById("deps_s_take_"+deps[n][0]).innerHTML="+"+(deps[n][3]+(deps[n][4]/1000)*t_ms_e).toFixed(12);
if(document.getElementById("deps_s_pr_"+deps[n][0])!=null){
document.getElementById("deps_s_pr_"+deps[n][0]).style.width=deps_pr+"%";
document.getElementById("deps_s_pr_"+deps[n][0]).innerHTML="<b>"+deps_pr+"%&nbsp;"+t_w+"</b>";
}
}
}
if(refresh==0){
requestAnimationFrame(deps_f);
}
}
catch(e){}
}


if(deps.length>0){
deps_f();
}


</script>';


?>
