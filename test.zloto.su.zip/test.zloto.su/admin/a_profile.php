<?php


if(empty($_GET['p_id'])){ exit; }


$p_id=preg_replace('#[^0-9a-z\_]+#i','',$_GET['p_id']);
preg_match('/^([0-9]{1,7})/',$p_id,$m);
if(empty($m[0]) || strlen($m[0])>7){ exit; }
$m[0]=preg_replace('#[^0-9]+#','',$m[0]);
if(empty($m[0]) || strlen($m[0])>7){ exit; }
preg_match('/([0-9a-z]{4})$/',$p_id,$z);
if(empty($z[0]) || strlen($z[0])!=4){ exit; }
$z[0]=preg_replace('#[^0-9a-z]+#','',$z[0]);
if(empty($z[0]) || strlen($z[0])!=4){ exit; }


$m[0]+=0;
$gen_hash=md5($m[0].$profile_hash);
$gen_hash=substr($gen_hash,0,4);
if(empty($gen_hash) || strlen($gen_hash)!=4 || $gen_hash!=$z[0]){ exit; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_POST['a_time']=substr($_POST['a_time'],0,20);
$_SESSION['a_time']=0+$_POST['a_time'];


// ____________________ ��� � ������ ____________________


if(isset($_POST['ban_mode']) && strlen($_POST['ban_mode'])==1 && ($_POST['ban_mode']==0 || $_POST['ban_mode']==1) && !empty($_POST['ban_id'])){
$ban_mode=$_POST['ban_mode'];
$ban_id=preg_replace("#[^0-9]+#",'',$_POST['ban_id']);
$ban_id=number_format($ban_id,0,'','')+0;
if(!empty($ban_id) && is_numeric($ban_id) && strlen($ban_id)<11 && $ban_id!=$u_id && $ban_id!=$admin_uid){
for($n=1;$n<20;$n++){
if(!isset($mydm['sp_uid_'.$n])){ break; }
mysqli_query($db,"UPDATE users SET sp_ban_".$n."=$ban_mode WHERE sp_uid_".$n."=$ban_id") or die ('cant update ban level '.$n);
}
mysqli_query($db,"UPDATE users SET ban=$ban_mode WHERE uid=$ban_id LIMIT 1") or die ('cant update ban user');
if($ban_mode==0){ $message_success='������������ �������� �� ���� �������'; }
else{ $message_success='������������ ������� �� ���� �������'; }
}
}


// ____________________ �������� ������ �� ������� ____________________


if(!empty($_POST['balance'])){
$sum=preg_replace("#[^0-9\.\,\-]+#",'',$_POST['balance']);
$sum=str_replace(',','.',$sum);
$sum=preg_replace("#\.+#",'.',$sum);
$sum=number_format($sum,4,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>10){ $sum=0; }
mysqli_query($db,"UPDATE users SET balance=balance+$sum WHERE uid='".$m[0]."' LIMIT 1") or die ('cant update balance');
$message_success=1;
}


// ____________________ �������� ������ �� ����� ____________________


if(!empty($_POST['money'])){
$sum=preg_replace("#[^0-9\.\,\-]+#",'',$_POST['money']);
$sum=str_replace(',','.',$sum);
$sum=preg_replace("#\.+#",'.',$sum);
$sum=number_format($sum,4,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>10){ $sum=0; }
mysqli_query($db,"UPDATE users SET money=money+$sum WHERE uid='".$m[0]."' LIMIT 1") or die ('cant update money');
$message_success=1;
}


// ____________________ �������� �������� ____________________


if(isset($_POST['payeer'])){
$up_payeer=$_POST['payeer'];
$up_payeer=preg_replace("#[^0-9]+#i",'',$up_payeer);
$up_payeer=substr($up_payeer,0,16);
if(!empty($up_payeer)){ $up_payeer='P'.$up_payeer; }
if($_POST['payeer']=='d'){ $up_payeer='d'; }
mysqli_query($db,"UPDATE users SET p_payeer='$up_payeer' WHERE uid='".$m[0]."' LIMIT 1") or die('cant update wallet number');
$message_success=1;
}


if(isset($_POST['qiwi'])){
$up_qiwi=$_POST['qiwi'];
$up_qiwi=preg_replace("#[^0-9]+#i",'',$up_qiwi);
$up_qiwi=substr($up_qiwi,0,16);
if(!empty($up_qiwi)){ $up_qiwi='+'.$up_qiwi; }
if($_POST['qiwi']=='d'){ $up_qiwi='d'; }
mysqli_query($db,"UPDATE users SET p_qiwi='$up_qiwi' WHERE uid='".$m[0]."' LIMIT 1") or die('cant update wallet number');
$message_success=1;
}


if(isset($_POST['yandex'])){
$up_yandex=$_POST['yandex'];
$up_yandex=preg_replace("#[^0-9]+#i",'',$up_yandex);
$up_yandex=substr($up_yandex,0,21);
if($_POST['yandex']=='d'){ $up_yandex='d'; }
mysqli_query($db,"UPDATE users SET p_yandex='$up_yandex' WHERE uid='".$m[0]."' LIMIT 1") or die('cant update wallet number');
$message_success=1;
}


// ____________________ ���������� ��������� ____________________


if(!empty($_POST['message'])){


$message=$_POST['message'];
$message=mb_convert_encoding($message,'HTML-ENTITIES','windows-1251');
$message=iconv("utf-8","windows-1251//IGNORE",$message);


$m_decode=array(
'&#1072;'=>'�','&#1073;'=>'�','&#1074;'=>'�','&#1075;'=>'�','&#1076;'=>'�','&#1077;'=>'�','&#1105;'=>'�','&#1078;'=>'�','&#1079;'=>'�','&#1080;'=>'�','&#1081;'=>'�',
'&#1082;'=>'�','&#1083;'=>'�','&#1084;'=>'�','&#1085;'=>'�','&#1086;'=>'�','&#1087;'=>'�','&#1088;'=>'�','&#1089;'=>'�','&#1090;'=>'�','&#1091;'=>'�','&#1092;'=>'�',
'&#1093;'=>'�','&#1094;'=>'�','&#1095;'=>'�','&#1096;'=>'�','&#1097;'=>'�','&#1098;'=>'�','&#1099;'=>'�','&#1100;'=>'�','&#1101;'=>'�','&#1102;'=>'�','&#1103;'=>'�',
'&#1110;'=>'�','&#1111;'=>'�','&#1108;'=>'�','&#1169;'=>'�',
'&#1040;'=>'�','&#1041;'=>'�','&#1042;'=>'�','&#1043;'=>'�','&#1044;'=>'�','&#1045;'=>'�','&#1025;'=>'�','&#1046;'=>'�','&#1047;'=>'�','&#1048;'=>'�','&#1049;'=>'�',
'&#1050;'=>'�','&#1051;'=>'�','&#1052;'=>'�','&#1053;'=>'�','&#1054;'=>'�','&#1055;'=>'�','&#1056;'=>'�','&#1057;'=>'�','&#1058;'=>'�','&#1059;'=>'�','&#1060;'=>'�',
'&#1061;'=>'�','&#1062;'=>'�','&#1063;'=>'�','&#1064;'=>'�','&#1065;'=>'�','&#1066;'=>'�','&#1067;'=>'�','&#1068;'=>'�','&#1069;'=>'�','&#1070;'=>'�','&#1071;'=>'�',
'&#1031;'=>'�','&#1030;'=>'�','&#1028;'=>'�','&#1168;'=>'�'
);


$message=str_replace(array_keys($m_decode),array_values($m_decode),$message);
$message=str_replace(array('`',"'",'�','�'),'&apos;',$message);
$message=str_replace(array('�','�','�','�','"'),'&quot;',$message);
$message=str_replace("\t",' ',$message);
$message=preg_replace('# +#mi',' ',$message);
$message=preg_replace('#^\ +#mi','',$message);
$message=preg_replace('#\ +$#mi','',$message);
$message=str_replace('<br>','#@#br',$message);
$message=str_replace('<br />','#@#br',$message);
$message=str_replace('<','&lt;',$message);
$message=str_replace('>','&gt;',$message);
$message=str_replace("\r",'',$message);
$message=str_replace("\n",'#@#br',$message);
$message=preg_replace('#[^0-9\ \/\_\.\,\:\;\|\~\?\!\-\+\=\*\^\%\#\$\&\@\�\(\)\{\}\[\]a-zA-Z�����������������������������������������Ũ�������������������������߯���]+#mi','',$message);
$message=str_replace('#@#br','<br>',$message);
$message=trim($message);
$message=substr($message,0,500);
mysqli_query($db,"UPDATE users SET message='".date('d.m.y H:i:s',$time)."<br>$message' WHERE uid='".$m[0]."' LIMIT 1");


$message_success=1;
}


// ____________________ ��������� ����������� ���������� ____________________


if(!empty($_POST['up_sum']) && !empty($_POST['up_batch']) && !empty($_POST['up_type'])){
$sum=preg_replace("#[^0-9\.\,\-]+#",'',$_POST['up_sum']);
$sum=str_replace(',','.',$sum);
$sum=preg_replace("#\.+#",'.',$sum);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>10){
$message_error='����� ��������';
}
$batch=preg_replace("#[^0-9]+#",'',$_POST['up_batch']);
if(empty($batch) || !is_numeric($batch) || strlen($batch)>30){
$message_error='���������� ��������';
}
$update=preg_replace("#[^0-9]+#",'',$_POST['up_type']);
if(empty($update) || ($update!=1 && $update!=2)){
$message_error='��� ������� ��������';
}
if(empty($message_error)){
$p_same_q=mysqli_query($db,"SELECT id FROM balance_up_m WHERE batch='$batch' LIMIT 1") or die('cant check same');
if(mysqli_num_rows($p_same_q)>0){
$message_error='����� ���������� ��� ����';
}
}
if(empty($message_error)){
$mydq=mysqli_query($db,"SELECT * FROM users WHERE uid='".$m[0]."' LIMIT 1") or die('cant select user');
$mydm=mysqli_fetch_assoc($mydq);
if(empty($mydm['uid'])){
$message_error='������������ �� ������';
}
}


if(empty($message_error)){


$u_id=$mydm['uid'];


// ____________________ ��������� �� ����� CABINET/UP.PHP ____________________


$admin_up_m_r='';
$admin_s=0;
if(!empty($up_m_com)){
if($update==1){ $pre_sum=$sum*(100-$kassa_pr_p)/100; }
if($update==2){ $pre_sum=$sum*(100-$kassa_pr_fk)/100; }
$pre_up_m_r=number_format($sum/100*$up_m_com,4,'.','')+0;
if($pre_up_m_r>0 && is_numeric($pre_up_m_r)){
$admin_s=$pre_up_m_r;
$admin_up_m_r=',admin_up_m_r=(admin_up_m_r+'.$pre_up_m_r.')';
}
}


$to_sp_1=0;
$to_sp_2=0;
$to_sp_3=0;


if($mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){ $to_sp_1=number_format(($sum/100*$up_m_r_1),4,'.','')+0; }
if($mydm['sp_uid_2']>0 && $mydm['sp_ban_2']==0){ $to_sp_2=number_format(($sum/100*$up_m_r_2),4,'.','')+0; }
if($mydm['sp_uid_3']>0 && $mydm['sp_ban_3']==0){ $to_sp_3=number_format(($sum/100*$up_m_r_3),4,'.','')+0; }


if($to_sp_1>0){
$s_q=mysqli_query($db,"SELECT up_m,up_m_rb FROM users WHERE uid=".$mydm['sp_uid_1']." AND ban=0 LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(isset($s_m['up_m']) && !empty($s_m['up_m_rb']) && is_numeric($s_m['up_m_rb']) && $s_m['up_m_rb']<=100){
if($up_m_refback_m==0.5){ $up_m_rb=$s_m['up_m_rb']; }
if($up_m_refback_m>=1 && $s_m['up_m']>=$up_m_refback_m){ $up_m_rb=$s_m['up_m_rb']; }
}
}


$update_ref_sum='';
$ref_sum=number_format($to_sp_1+$to_sp_2+$to_sp_3,4,'.','')+0;
if($ref_sum>0 && is_numeric($ref_sum)){
$update_ref_sum=',ref_sum=(ref_sum+'.$ref_sum.')';
}


$bonus_p=0;
$bonus_s=0;


if(!empty($up_m_bonus_d_1) && !empty($up_m_bonus_d_2) && is_numeric($up_m_bonus_d_1) && is_numeric($up_m_bonus_d_2) && $up_m_bonus_d_1<$up_m_bonus_d_2 && $time>$up_m_bonus_d_1 && $time<$up_m_bonus_d_2){


if($mydm['up_m']==0 && $up_m_bonus_f>0){
$pre_bonus_f=number_format($sum/100*$up_m_bonus_f,4,'.','')+0;
if($pre_bonus_f>0){
$bonus_p=$up_m_bonus_f;
$bonus_s=$pre_bonus_f;
}
}


$bonus_s_now=0;


if(!empty($up_m_bonus_a)){
foreach($up_m_bonus_a as $i=>$v){
if(!empty($v) && $sum>=$i){
$bonus_s_now=$v;
}
}
}


if(!empty($bonus_s_now)){
$pre_bonus_s=number_format($sum/100*$bonus_s_now,4,'.','')+0;
if($pre_bonus_s>0){
$bonus_p+=$bonus_s_now;
$bonus_s+=$pre_bonus_s;
}
}


$bonus_p=number_format($bonus_p,4,'.','')+0;
$bonus_s=number_format($bonus_s,4,'.','')+0;


}


$bonus_up_m_r='';


if(!empty($bonus_s)){
$bonus_up_m_r=',bonus_up_m_r=(bonus_up_m_r+'.$bonus_s.')';
}


$bm_text='balance=(balance+'.number_format($sum+$bonus_s,4,'.','').'),';


$refback=0;
$to_rb_up_m='';


if(!empty($up_m_rb)){
$refback=$to_sp_1*$up_m_rb/100;
$refback=number_format($refback,4,'.','')+0;
if($refback>0){
$to_rb_up_m='to_rb_up_m=(to_rb_up_m+'.$refback.'),';
if($up_m_refback_to=='balance'){ $bm_text='balance=(balance+'.number_format($sum+$bonus_s+$refback,4,'.','').'),'; }
else{ $bm_text='balance=(balance+'.number_format($sum+$bonus_s,4,'.','').'),money=(money+'.$refback.'),'; }
}
$to_sp_1=$to_sp_1-$refback;
$to_sp_1=number_format($to_sp_1,4,'.','')+0;
if($to_sp_1<0){ $to_sp_1=0; }
}


$to_sp_1_t='';
$to_sp_2_t='';
$to_sp_3_t='';


if($to_sp_1>0){ $to_sp_1_t='to_sp_1=(to_sp_1+'.$to_sp_1.'),'; }
if($to_sp_2>0){ $to_sp_2_t='to_sp_2=(to_sp_2+'.$to_sp_2.'),'; }
if($to_sp_3>0){ $to_sp_3_t='to_sp_3=(to_sp_3+'.$to_sp_3.'),'; }


mysqli_query($db,"INSERT INTO balance_up_m (date,date_word,uid,login,sum,admin_s,bonus_p,bonus_s,refback,to_sp_1,to_sp_2,to_sp_3,batch,type) VALUES ('$time','".date("d.m.y H:i:s",$time)."','$u_id','".$mydm['login']."','$sum','$admin_s','$bonus_p','$bonus_s','$refback','$to_sp_1','$to_sp_2','$to_sp_3','$batch','$update')") or die('inserting error');


$s_q=mysqli_query($db,"SELECT * FROM data LIMIT 1") or die('cant select data');
$d=mysqli_fetch_assoc($s_q);
if(!isset($d['users'])){ exit('data error'); }


// ��� �������� ����������


$contest_up='';


$contest_up_d_1=strtotime($d['contest_up_d_1']);
$contest_up_d_2=strtotime($d['contest_up_d_2']);


if(!empty($contest_up_m) && $time>$contest_up_d_1 && $time<$contest_up_d_2 && date('Y',$contest_up_d_1)!=2000){ $contest_up=',contest_up=contest_up+'.$sum; }


mysqli_query($db,"UPDATE users SET $bm_text $to_rb_up_m $to_sp_1_t $to_sp_2_t $to_sp_3_t up_m=up_m+$sum,up_m_time=$time,bonus_up_m_r=(bonus_up_m_r+$bonus_s) $contest_up WHERE uid=$u_id LIMIT 1") or die('cant update user up_m');


$p_datas_q=mysqli_query($db,"SELECT COUNT(*) FROM users WHERE up_m>0 AND bot=0") or die('cant count');
$p_datas_m=mysqli_fetch_row($p_datas_q);
$update_active=0+$p_datas_m[0];


$update_last_t='';
$up_last=array();
eval($d['up_last']);
$sum=number_format($sum,2,'.','');


if($update==1){ array_unshift($up_last,array($time,$mydm['uid'],$mydm['avatar'],$mydm['login'],"p",$sum)); }
if($update==2){ array_unshift($up_last,array($time,$mydm['uid'],$mydm['avatar'],$mydm['login'],"fk",$sum)); }


for($n=0;$n<$up_last_c;$n++){
if(empty($up_last[$n])){ break; }
$update_last_t.='$up_last[]=array("'.$up_last[$n][0].'","'.$up_last[$n][1].'","'.$up_last[$n][2].'","'.$up_last[$n][3].'","'.$up_last[$n][4].'","'.$up_last[$n][5].'","'.$up_last[$n][6].'");';
}


if($update==1){
mysqli_query($db,"UPDATE data SET active='$update_active',up_payeer_s=up_payeer_s+$sum,up_payeer_c=up_payeer_c+1,up_last='$update_last_t' $bonus_up_m_r $admin_up_m_r $update_ref_sum") or die('cant data');
}


if($update==2){
mysqli_query($db,"UPDATE data SET active='$update_active',up_fk_s=up_fk_s+$sum,up_fk_c=up_fk_c+1,up_last='$update_last_t' $bonus_up_m_r $admin_up_m_r $update_ref_sum") or die('cant data');
}


// ��� �������� ���������


if(!empty($contest_ref_m) && $mydm['date']>strtotime($d['contest_ref_d_1']) && $mydm['date']<strtotime($d['contest_ref_d_2']) && $mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){
mysqli_query($db,"UPDATE users SET contest_ref=contest_ref+".$sum." WHERE uid='".$mydm['sp_uid_1']."' AND ban=0 LIMIT 1") or die('cant update contest_ref');
}


// ____________________ ������� ����������� ____________________


if($to_sp_1>0 || $refback>0){  mysqli_query($db,"UPDATE users SET $up_m_way=($up_m_way+$to_sp_1),nrs=(nrs+$to_sp_1),refs_r_1=(refs_r_1+$to_sp_1),rb_up_m=(rb_up_m+$refback) WHERE uid='".$mydm['sp_uid_1']."' LIMIT 1") or die('cant update sp balance 1'); }
if($to_sp_2>0){ mysqli_query($db,"UPDATE users SET $up_m_way=($up_m_way+$to_sp_2),nrs=(nrs+$to_sp_2),refs_r_2=(refs_r_2+$to_sp_2) WHERE uid='".$mydm['sp_uid_2']."' LIMIT 1") or die('cant update sp balance 2'); }
if($to_sp_3>0){ mysqli_query($db,"UPDATE users SET $up_m_way=($up_m_way+$to_sp_3),nrs=(nrs+$to_sp_3),refs_r_3=(refs_r_3+$to_sp_3) WHERE uid='".$mydm['sp_uid_3']."' LIMIT 1") or die('cant update sp balance 3'); }


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=1,sum='$to_sp_1',sp_uid='".$mydm['sp_uid_1']."',info='���������� �������',refback='$refback'") or die('cant insert refs_profit 1'); }
if($to_sp_2>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=2,sum='$to_sp_2',sp_uid='".$mydm['sp_uid_2']."',info='���������� �������'") or die('cant insert refs_profit 2'); }
if($to_sp_3>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=3,sum='$to_sp_3',sp_uid='".$mydm['sp_uid_3']."',info='���������� �������'") or die('cant insert refs_profit 3'); }


// ____________________ ������������ �������� ��������� ____________________


if($mydm['up_m']==0){


$where='';
$count_if='';


if($mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){
$where="sp_uid_1='".$mydm['sp_uid_1']."'";
$count_if='COUNT(IF(up_m!=0 AND sp_uid_1=\''.$mydm['sp_uid_1'].'\',1,null)) AS refs_a_1';
}


if($mydm['sp_uid_2']>0 && $mydm['sp_ban_2']==0){
if(!empty($where)){ $where.=' OR '; }
$where.="sp_uid_2='".$mydm['sp_uid_2']."'";
if(!empty($count_if)){ $count_if.=','; }
$count_if.='COUNT(IF(up_m!=0 AND sp_uid_2=\''.$mydm['sp_uid_2'].'\',1,null)) AS refs_a_2';
}


if($mydm['sp_uid_3']>0 && $mydm['sp_ban_3']==0){
if(!empty($where)){ $where.=' OR '; }
$where.="sp_uid_3='".$mydm['sp_uid_3']."'";
if(!empty($count_if)){ $count_if.=','; }
$count_if.='COUNT(IF(up_m!=0 AND sp_uid_3=\''.$mydm['sp_uid_3'].'\',1,null)) AS refs_a_3';
}


if(!empty($where) && !empty($count_if)){
$s_a_q=mysqli_query($db,"SELECT $count_if FROM users WHERE $where") or die('cant get refs_a');
$s_a_m=mysqli_fetch_assoc($s_a_q);
}


if(!empty($s_a_m['refs_a_1'])){ mysqli_query($db,"UPDATE users SET refs_a_1='".$s_a_m['refs_a_1']."' WHERE uid='".$mydm['sp_uid_1']."' LIMIT 1"); }
if(!empty($s_a_m['refs_a_2'])){ mysqli_query($db,"UPDATE users SET refs_a_2='".$s_a_m['refs_a_2']."' WHERE uid='".$mydm['sp_uid_2']."' LIMIT 1"); }
if(!empty($s_a_m['refs_a_3'])){ mysqli_query($db,"UPDATE users SET refs_a_3='".$s_a_m['refs_a_3']."' WHERE uid='".$mydm['sp_uid_3']."' LIMIT 1"); }


}


// ____________________ ��� ��������� �� �������� ��������� ____________________


$top_sp_a_t='';


$s_q=mysqli_query($db,"SELECT uid,avatar,login,refs_a_1 FROM users WHERE ban=0 ORDER BY refs_a_1 DESC LIMIT ".$top_sp_a_c) or die ('cant select refs_a_1');
while($s_m=mysqli_fetch_assoc($s_q)){
$top_sp_a_t.='$top_sp_a[]=array("'.$s_m['uid'].'","'.$s_m['avatar'].'","'.$s_m['login'].'","'.$s_m['refs_a_1'].'");';
}


// ____________________ ��� ������������� �� ����������� ____________________


$top_up_m_t='';


$s_q=mysqli_query($db,"SELECT uid,avatar,login,up_m FROM users WHERE ban=0 ORDER BY up_m DESC LIMIT ".$top_up_m_c) or die ('cant select top_up_m');
while($s_m=mysqli_fetch_assoc($s_q)){
$top_up_m_t.='$top_up_m[]=array("'.$s_m['uid'].'","'.$s_m['avatar'].'","'.$s_m['login'].'","'.$s_m['up_m'].'");';
}


mysqli_query($db,"UPDATE data SET top_sp_a='$top_sp_a_t',top_up_m='$top_up_m_t' LIMIT 1") or die('cant update data top_sp_a top_up_m');


$message_success=1;
$mydm=array(); // ��������, ��� ��� �� ��� �������


}
}


}


$p_q=mysqli_query($db,"SELECT * FROM users WHERE uid='".$m[0]."' LIMIT 1") or die('cant select user');
$p=mysqli_fetch_assoc($p_q);
if(empty($p['uid'])){ exit; }


// ____________________ ������������ ������ �� ������� ____________________


if(!empty($message_success) && !empty($_POST['balance'])){
if($p['balance']>900000){
mysqli_query($db,"UPDATE users SET balance=900000 WHERE uid='".$m[0]."' LIMIT 1") or die ('cant update balance');
$p_q=mysqli_query($db,"SELECT * FROM users WHERE uid='".$m[0]."' LIMIT 1") or die('cant select user');
$p=mysqli_fetch_assoc($p_q);
if(empty($p['uid'])){ exit; }
}
if($p['balance']<0){
mysqli_query($db,"UPDATE users SET balance=0 WHERE uid='".$m[0]."' LIMIT 1") or die ('cant update balance');
$p_q=mysqli_query($db,"SELECT * FROM users WHERE uid='".$m[0]."' LIMIT 1") or die('cant select user');
$p=mysqli_fetch_assoc($p_q);
if(empty($p['uid'])){ exit; }
}
}


// ____________________ ������������ ������ �� ����� ____________________


if(!empty($message_success) && !empty($_POST['money'])){
if($p['money']>900000){
mysqli_query($db,"UPDATE users SET money=900000 WHERE uid='".$m[0]."' LIMIT 1") or die ('cant update money');
$p_q=mysqli_query($db,"SELECT * FROM users WHERE uid='".$m[0]."' LIMIT 1") or die('cant select user');
$p=mysqli_fetch_assoc($p_q);
if(empty($p['uid'])){ exit; }
}
if($p['money']<0){
mysqli_query($db,"UPDATE users SET money=0 WHERE uid='".$m[0]."' LIMIT 1") or die ('cant update money');
$p_q=mysqli_query($db,"SELECT * FROM users WHERE uid='".$m[0]."' LIMIT 1") or die('cant select user');
$p=mysqli_fetch_assoc($p_q);
if(empty($p['uid'])){ exit; }
}
}


if(!empty($message_success)){
if($message_success==1){ $message_success='������'; }
echo '<script type="text/javascript">
document.getElementById("a_message").innerHTML=\'<div class="a_message_success">'.$message_success.'</div>\';
setTimeout("document.getElementById(\'a_message\').innerHTML=\'\';",5000);
</script>';
}


if(!empty($message_error)){
echo '<script type="text/javascript">
document.getElementById("a_message").innerHTML=\'<div class="a_message_error">'.$message_error.'</div>\';
setTimeout("document.getElementById(\'a_message\').innerHTML=\'\';",5000);
</script>';
}


echo '<div class="a_profile_login">'.$p['login'].' #'.$p['uid'].'</div>


<img class="a_profile_avatar" src="'.$p['avatar'].'">


<form id="form_ban" style="display:none;" method="POST">
<input id="ban_mode" type="hidden" name="ban_mode" value="0">
<input id="ban_id" type="hidden" name="ban_id" value="0">
<input type="hidden" name="a_time" value="'.$time.'">
</form>


<div class="a_profile_url_from">������: '.$p['url_from'].'</div>


<table align="center" cellpadding="0px" cellspacing="0px">';


if($p['ban']==0){ echo '<tr><td class="a_profile_i_b_0">�� �������:</td><td class="a_profile_v_b_0"><div onclick="ban(1,'.$p['uid'].');">��������</div></td></tr>'; }
else{ echo '<tr><td class="a_profile_i_b_1">�������:</td><td class="a_profile_v_b_1"><div onclick="ban(0,'.$p['uid'].');">���������</div></td></tr>'; }


echo '<tr><td>&nbsp;</td><td></td></tr>';


if(empty($p['mail'])){
echo '<tr><td class="a_profile_i">�������:</td><td class="a_profile_v">';
if(!empty($profile_soc[$p['soc_type']])){ echo '<a target="_blank" href="'.$profile_soc[$p['soc_type']].$p['soc_id'].'">'.$profile_soc[$p['soc_type']].$p['soc_id'].'</a>'; }
else{ echo '<span>'.$p['soc_type'].'</span>'; }
}
else{ echo '<tr><td class="a_profile_i">�����:</td><td class="a_profile_v">'.$p['mail']; }


echo '</td>
</tr>
<tr><td class="a_profile_i">���� �����������:</td><td class="a_profile_v">'.$p['date_word'].'</td></tr>
<tr><td class="a_profile_i">IP �����������:</td><td class="a_profile_v">'.$p['ip'].'</td></tr>
<tr><td class="a_profile_i">���� �����:</td><td class="a_profile_v">'.$p['date_2_word'].'</td></tr>
<tr><td class="a_profile_i">IP �����:</td><td class="a_profile_v">'.$p['ip_came'].'</td></tr>
<tr><td class="a_profile_i">������ �� �������:</td><td class="a_profile_v">'.$p['balance'].'</td></tr>
<tr><td class="a_profile_i">������ �� �����:</td><td class="a_profile_v">'.$p['money'].'</td></tr>
<tr><td class="a_profile_i">��������� � ��������:</td><td class="a_profile_v">'.$p['up_m'].'</td></tr>
<tr><td class="a_profile_i">��������� � ������:</td><td class="a_profile_v">'.$p['up_w'].'</td></tr>
<tr><td class="a_profile_i">���������:</td><td class="a_profile_v">'.$p['w_s'].'</td></tr>
<tr><td class="a_profile_i">���� ���������� � ��������:</td><td class="a_profile_v">';
if(empty($p['up_m_time'])){ echo '���'; }
else{ echo date('d.m.y H:i:s',$p['up_m_time']); }
echo '</td></tr>
<tr><td class="a_profile_i">���� �������:</td><td class="a_profile_v">';
if(empty($p['w_time'])){ echo '���'; }
else{ echo date('d.m.y H:i:s',$p['w_time']); }
echo '</td></tr>
<tr><td class="a_profile_i">�������������:</td><td class="a_profile_v">';
if(empty($p['mults'])){ echo '���'; }
else{ echo $p['mults']; }
echo '</td></tr>';


$f_sp=array();
$sp=array();
$f_n=0;


for($n=1;$n<20;$n++){
if(!empty($p['sp_uid_'.$n])){ $f_sp[]=$p['sp_uid_'.$n]; $f_n++; }
}


$f_sp=implode(',',$f_sp);


if(!empty($f_sp)){
$s_q=mysqli_query($db,"SELECT uid,avatar,login,ban FROM users WHERE uid IN ($f_sp) LIMIT ".$f_n) or die ('cant select sp');
while($s_m=mysqli_fetch_assoc($s_q)){
$sp[$s_m['uid']]=$s_m;
}
}


echo '<tr><td>&nbsp;</td><td></td></tr>';


if(!empty($sp)){


for($n=1;$n<20;$n++){


if(!empty($p['sp_uid_'.$n]) && !empty($sp[$p['sp_uid_'.$n]])){
$profile_link=md5($p['sp_uid_'.$n].$profile_hash);
$profile_link=$p['sp_uid_'.$n].'_'.substr($profile_link,0,4);
$banned='';
echo '<tr><td class="a_profile_i">������� '.$n.':</td><td class="a_profile_sp_v">#'.$p['sp_uid_'.$n].'<a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$sp[$p['sp_uid_'.$n]]['avatar'].'">'.$sp[$p['sp_uid_'.$n]]['login'].'</a></td></tr>';
if($sp[$p['sp_uid_'.$n]]['ban']==0){ echo '<tr><td class="a_profile_i_b_0">�� �������:</td><td class="a_profile_v_b_0"><div onclick="ban(1,'.$p['sp_uid_'.$n].');">��������</div></td></tr>'; }
else{ echo '<tr><td class="a_profile_i_b_1">�������:</td><td class="a_profile_v_b_1"><div onclick="ban(0,'.$p['sp_uid_'.$n].');">���������</div></td></tr>'; }
}
if(!empty($p['sp_uid_'.$n]) && empty($sp[$p['sp_uid_'.$n]])){
echo '<tr><td class="a_profile_i">������� '.$n.':</td><td class="a_profile_sp_no_f">�� ������ � ����</td></tr>';
}


}


}
else{


echo '<tr><td class="a_profile_i" align="right">���������</td><td class="a_profile_sp_no_f">���</td></tr>';


}


echo '</table>';


echo '<table class="a_profile_r_t" align="center" cellpadding="5px" cellspacing="1px">
<tr><td class="a_profile_r_i">�������</td><td class="a_profile_r_v">1</td><td class="a_profile_r_v">2</td><td class="a_profile_r_v">3</td></tr>
<tr><td class="a_profile_r_i">���������</td><td class="a_profile_r_v">'.$p['refs_c_1'].'</td><td class="a_profile_r_v">'.$p['refs_c_2'].'</td><td class="a_profile_r_v">'.$p['refs_c_3'].'</td></tr>
<tr><td class="a_profile_r_i">��������</td><td class="a_profile_r_v">'.$p['refs_a_1'].'</td><td class="a_profile_r_v">'.$p['refs_a_2'].'</td><td class="a_profile_r_v">'.$p['refs_a_3'].'</td></tr>
<tr><td class="a_profile_r_i">�����</td><td class="a_profile_r_v">'.$p['refs_r_1'].'</td><td class="a_profile_r_v">'.$p['refs_r_2'].'</td><td class="a_profile_r_v">'.$p['refs_r_3'].'</td></tr>
</table>


<table class="a_profile_rb_t" align="center" cellpadding="0px" cellspacing="0px">
<tr><td class="a_profile_rb_i">������ ��������� � ����������:</td><td class="a_profile_rb_v">'.$p['rb_up_m'].' ���.</td></tr>
<tr><td class="a_profile_rb_i">������ ��������� � ����������:</td><td class="a_profile_rb_v">'.$p['rb_other'].' ���.</td></tr>
<tr><td class="a_profile_rb_i">������ �� �������� � ����������:</td><td class="a_profile_rb_v">'.$p['to_rb_up_m'].' ���.</td></tr>
<tr><td class="a_profile_rb_i">������ �� �������� � ����������:</td><td class="a_profile_rb_v">'.$p['to_rb_other'].' ���.</td></tr>
</table>


<form id="form_up" method="POST">
<table width="300px" align="center" cellpadding="0px" cellspacing="0px">
<tr><td colspan="3"><div class="a_profile_a_title">��������� ����������� �����</div></td></tr>
<tr>
<td width="80px"><input class="a_profile_up_sum" type="text" placeholder="�����" name="up_sum" autocomplete="off" oninput="this.value=this.value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');"></td>
<td width="120px"><input class="a_profile_up_batch" type="text" placeholder="����������" name="up_batch" autocomplete="off" oninput="this.value=this.value.replace(/[^0-9]/g,\'\').replace(/^0([0-9]+)/,\'$1\');"><input type="hidden" name="a_time" value="'.$time.'"></td>
<td><select class="a_profile_up_type" name="up_type"><option value="1">Payeer</option><option value="2">Free-Kassa</option></select></td>
</tr>
<tr>
<td colspan="3">
<div class="a_profile_up_button" onclick="if(confirm(\'����� ��������� ?\')){ document.getElementById(\'form_up\').submit(); }">���������</div>
</td>
</tr>
</table>
</form>


<br>


<table width="300px" align="center" cellpadding="0px" cellspacing="0px">
<tr><td colspan="2"><div class="a_profile_a_title">��������� ��� ������ ������ �� �������</div></td></tr>
<tr><td><form id="form_balance" method="POST"><input autocomplete="off" class="a_profile_b_input" type="text" placeholder="������: '.$p['balance'].'" name="balance" oninput="this.value=this.value.replace(/[^0-9\-]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{4}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');"><input type="hidden" name="a_time" value="'.$time.'"></form></td>
<td><div class="a_profile_b_button" onclick="document.getElementById(\'form_balance\').submit();">��������</div></td>
</tr>
</table>


<br><table width="300px" align="center" cellpadding="0px" cellspacing="0px">
<tr><td colspan="2"><div class="a_profile_a_title">��������� ��� ������ ������ �� �����</div></td></tr>
<tr><td><form id="form_money" method="POST"><input autocomplete="off" class="a_profile_b_input" type="text" placeholder="������: '.$p['money'].'" name="money" oninput="this.value=this.value.replace(/[^0-9\-]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{4}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');"><input type="hidden" name="a_time" value="'.$time.'"></form></td>
<td><div class="a_profile_b_button" onclick="document.getElementById(\'form_money\').submit();">��������</div></td>
</tr>
</table>


<br>


<table width="300px" align="center" cellpadding="0px" cellspacing="0px">
<tr><td colspan="2">
<div class="a_profile_a_title">�������� ��������</div>
<div class="a_profile_a_info">��� �������� �������� ������ ����� d</div>
</td></tr>
<tr><td><form id="form_payeer" method="POST"><input autocomplete="off" class="a_profile_p_input" type="text" placeholder="Payeer" name="payeer" value="'.$p['p_payeer'].'"><input type="hidden" name="a_time" value="'.$time.'"></form></td>
<td><div class="a_profile_p_button" onclick="document.getElementById(\'form_payeer\').submit();">��������</div></td></tr>
<tr><td><form id="form_qiwi" method="POST"><input autocomplete="off" class="a_profile_p_input" type="text" placeholder="Qiwi" name="qiwi" value="'.$p['p_qiwi'].'"><input type="hidden" name="a_time" value="'.$time.'"></form></td>
<td><div class="a_profile_p_button" onclick="document.getElementById(\'form_qiwi\').submit();">��������</div></td></tr>
<tr><td><form id="form_yandex" method="POST"><input autocomplete="off" class="a_profile_p_input" type="text" placeholder="������.������" name="yandex" value="'.$p['p_yandex'].'"><input type="hidden" name="a_time" value="'.$time.'"></form></td>
<td><div class="a_profile_p_button" onclick="document.getElementById(\'form_yandex\').submit();">��������</div></td></tr>
</table>


<br>


<table width="300px" align="center" cellpadding="0px" cellspacing="0px">
<tr><td><div class="a_profile_a_title">����������� �����������</div></td></tr>
<tr>
<td>
<div class="a_profile_message"><form id="form_message" method="POST"><textarea name="message" placeholder="����� ���������. ����� ������� - ������� � ���������.">'.$p['message'].'</textarea><input type="hidden" name="a_time" value="'.$time.'"></form></div>
<div class="a_profile_message_button" onclick="document.getElementById(\'form_message\').submit();">��������� ���������</div>
</td>
</tr>
</table>


<br>
<br>';


?>
