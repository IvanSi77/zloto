<?php


$np_sort_a=array();
$np_sort_a[]=array('������','amount DESC');
$np_sort_a[]=array('���������','active DESC');
$np_sort_a[]=array('�� �����','sum DESC');
$np_sort_a[]=array('������','url_from ASC');


if(isset($_GET['sort'])){
$pre=preg_replace('#[^0-9]+#','',$_GET['sort']);
$pre=preg_replace('#^[0]+#','',$pre);
$pre=number_format($pre,0,'','');
if(!empty($np_sort_a[$pre])){
$np_sort_n=$pre;
$np_sort=$np_sort_a[$pre][1];
}
}


if(!isset($np_sort_n)){ $np_sort_n=0; $np_sort=$np_sort_a[0][1]; }


$np_pp=100;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM users WHERE bot=0 GROUP BY url_from") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="a_np_def" href="/?page=a_top_traffic&str=1&sort='.$np_sort_n.'#a_np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="a_np_def" href="/?page=a_top_traffic&str=1&sort='.$np_sort_n.'#a_np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="a_np_now" href="/?page=a_top_traffic&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="a_np_def" href="/?page=a_top_traffic&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="a_np_def" href="/?page=a_top_traffic&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="a_np_def" href="/?page=a_top_traffic&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


echo '<div class="a_sort_common"><span class="a_sort_word">����������� ��: </span>';


for($n=0;$n<sizeof($np_sort_a);$n++){
$np_link_a='';
if($n==$np_sort_n){ $np_link_a='_2'; }
echo '<a class="a_sort_a'.$np_link_a.'" href="/?page=a_top_traffic&sort='.$n.'">'.$np_sort_a[$n][0].'</a>';
}


echo '</div>


<br>';


if(!empty($np_links)){ echo '<a name="a_np_a" class="a_np_a"></a><div class="a_np_div">'.$np_links.'</div><br>'; }


echo '<table align="center" class="a_top_traffic_s_table" cellpadding="5px" cellspacing="0px">
<tr class="a_top_traffic_s_title"><td>������</td><td>���������</td><td>�� �����</td><td>������</td></tr>';


$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT  COUNT(*) as amount,COUNT(IF(up_m>0,1,NULL)) as active,SUM(up_m) as sum,url_from FROM users WHERE bot=0 GROUP BY url_from ORDER BY $np_sort LIMIT $np_start,$np_pp");
while($s_m=mysqli_fetch_assoc($s_q)){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
echo '<tr class="a_top_traffic_s_tr_'.$row_tr_n.'">
<td class="a_top_traffic_s_amount">'.$s_m['amount'].'</td>
<td class="a_top_traffic_s_active">'.$s_m['active'].'</td>
<td class="a_top_traffic_s_sum">'.$s_m['sum'].'</td>
<td class="a_top_traffic_s_url_from">'.$s_m['url_from'].'</td>
</tr>';
}


echo '</table>';


if(!empty($np_links)){ echo '<br><div class="a_np_div">'.$np_links.'</div><br>'; }


?>
