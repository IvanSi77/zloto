<?php


$search_type=array();
$search_type['uid']=array(1,'UID ������������');
$search_type['login']=array(0,'������ ������������');
$search_type['sum']=array(1,'�����');
$search_type['batch']=array(1,'����������');


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


// ____________________ ����� ____________________


if(!empty($_POST['a_up_m_s_type']) && isset($_POST['a_up_m_s_text'])){
$a_up_m_s_type=preg_replace("#[^a-z\_\-0-9]+#mi",'',$_POST['a_up_m_s_type']);
if(!empty($search_type[$a_up_m_s_type])){
$_SESSION['a_up_m_s_type']=$a_up_m_s_type;
$a_up_m_s_text=substr($_POST['a_up_m_s_text'],0,40);
$_SESSION['a_up_m_s_text']=preg_replace("#[^0-9\.\+\ \-\;\&\#a-zA-Z�����������������������������������������Ũ�������������������������߯���]+#mi",'',$a_up_m_s_text);
}
}


}


$np_sort_a=array();
$np_sort_a[]=array('�������','id DESC');
$np_sort_a[]=array('uid','uid ASC');
$np_sort_a[]=array('��������','login ASC');
$np_sort_a[]=array('�����','sum DESC');
$np_sort_a[]=array('�������','refback DESC');
$np_sort_a[]=array('����������','batch ASC');
$np_sort_a[]=array('�������','type ASC');


if(isset($_GET['sort'])){
$pre=preg_replace('#[^0-9]+#','',$_GET['sort']);
$pre=preg_replace('#^[0]+#','',$pre);
$pre=number_format($pre,0,'','');
if(!empty($np_sort_a[$pre])){
$np_sort_n=$pre;
$np_sort=$np_sort_a[$pre][1];
}
}


if(!isset($np_sort_n)){ $np_sort_n=0; $np_sort=$np_sort_a[0][1]; }


// ____________________ ��� ������ ____________________


$where='';


if(!empty($_SESSION['a_up_m_s_type']) && !empty($_SESSION['a_up_m_s_text'])){
$a_up_m_s_type=$_SESSION['a_up_m_s_type'];
$a_up_m_s_text=$_SESSION['a_up_m_s_text'];
if($search_type[$a_up_m_s_type][0]==0){
$where="WHERE $a_up_m_s_type LIKE '%".$a_up_m_s_text."%'";
}
if($search_type[$a_up_m_s_type][0]==1){
$where="WHERE $a_up_m_s_type='$a_up_m_s_text'";
}
}


$np_pp=10;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM balance_up_m $where") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="a_np_def" href="/?page=a_up_m&str=1&sort='.$np_sort_n.'#a_np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="a_np_def" href="/?page=a_up_m&str=1&sort='.$np_sort_n.'#a_np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="a_np_now" href="/?page=a_up_m&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="a_np_def" href="/?page=a_up_m&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="a_np_def" href="/?page=a_up_m&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="a_np_def" href="/?page=a_up_m&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


echo '<div class="a_sort_common"><a class="a_sort_a" href="/?page=a_up_w">� ������</a> <span class="a_sort_word">����������� ��: </span>';


for($n=0;$n<sizeof($np_sort_a);$n++){
$np_link_a='';
if($n==$np_sort_n){ $np_link_a='_2'; }
echo '<a class="a_sort_a'.$np_link_a.'" href="/?page=a_up_m&sort='.$n.'">'.$np_sort_a[$n][0].'</a>';
}


echo '</div>


<br>


<form id="form_search" method="POST">
<table align="center" cellpadding="2px" cellspacing="0px">
<tr>';
if(!empty($_SESSION['a_up_m_s_text'])){
echo '<td><div class="a_users_search_button" onclick="document.getElementById(\'a_up_m_s_text\').value=\'\'; document.getElementById(\'form_search\').submit();">��������</div></td>';
}
echo '<td class="a_users_search_word">����� ��: </td>
<td>
<select class="a_users_search_select" name="a_up_m_s_type">';
foreach($search_type as $s_t_i=>$s_t_v){
if(!empty($_SESSION['a_up_m_s_type']) && $s_t_i==$_SESSION['a_up_m_s_type']){
echo '<option value="'.$s_t_i.'" selected>'.$s_t_v[1].'</option>';
}
else{ echo '<option value="'.$s_t_i.'">'.$s_t_v[1].'</option>'; }
}
echo '</select>
</td>
<td><input id="a_up_m_s_text" autocomplete="off" class="a_users_search_input" type="text" placeholder="������� �����" name="a_up_m_s_text" maxlength="40" value="'.$_SESSION['a_up_m_s_text'].'"><input type="hidden" name="a_time" value="'.$time.'"></td>
<td><div class="a_users_search_button" onclick="document.getElementById(\'form_search\').submit();">�����</div></td></tr>
</table>
</form>


<br>';


if(!empty($np_links)){ echo '<a name="a_np_a" class="a_np_a"></a><div class="a_np_div">'.$np_links.'</div><br>'; }


echo '<table class="a_up_s_table" cellpadding="5px" cellspacing="0px">
<tr class="a_up_s_title"><td>#</td><td>����</td><td>UID</td><td></td><td>������������</td><td title="����� ����������, ������� ������, �����, ������">����</td><td>�������</td><td>������</td><td>����������</td><td>������</td></tr>';


$up_a=array();
$uids=array();
$la=array();


$s_q=mysqli_query($db,"SELECT * FROM balance_up_m $where ORDER BY $np_sort LIMIT $np_start,$np_pp");
while($s_m=mysqli_fetch_assoc($s_q)){
$up_a[]=$s_m;
if(!in_array($s_m['uid'],$uids)){ $uids[]=$s_m['uid']; }
}


if(!empty($uids)){
$suids=implode(',',$uids);
$laq=mysqli_query($db,"SELECT uid,avatar FROM users WHERE uid IN ($suids) LIMIT ".sizeof($uids)) or die ('cant select avatar');
while($lam=mysqli_fetch_row($laq)){
$la[$lam[0]]=$lam[1];
}
}


$row_tr_n=0;


foreach($up_a as $s_m){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<tr class="a_up_s_tr_'.$row_tr_n.'">
<td class="a_up_s_id">'.$s_m['id'].'</td>
<td class="a_up_s_date">'.$s_m['date_word'].'</td>
<td class="a_up_s_uid">'.$s_m['uid'].'</td>
<td class="a_up_s_avatar"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$la[$s_m['uid']].'"></a></td>
<td class="a_up_s_login"><a target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a></td>
<td class="a_up_s_spba"><div class="a_up_s_sum">'.$s_m['sum'].'</div><div class="a_up_s_bonus_p">'.($s_m['bonus_p']+0).'%</div><div class="a_up_s_bonus_s">'.$s_m['bonus_s'].'</div><div class="a_up_s_admin_s">'.$s_m['admin_s'].'</div></td>
<td class="a_up_s_refs">'.$s_m['to_sp_1'].'<br>'.$s_m['to_sp_2'].'<br>'.$s_m['to_sp_3'].'</td>
<td class="a_up_s_refback">'.$s_m['refback'].'</td>
<td class="a_up_s_batch">'.$s_m['batch'].'</td>
<td class="a_up_s_type"><div class="a_up_s_type_'.$s_m['type'].'"></div></td>
</tr>';
}


echo '</table>';


if(!empty($np_links)){ echo '<br><div class="a_np_div">'.$np_links.'</div><br>'; }


?>
