<?php


$search_type=array();
$search_type['uid']=array(1,'UID ������������');
$search_type['login']=array(0,'������ ������������');
$search_type['num']=array(1,'������ �������');
$search_type['ip']=array(0,'IP �����');


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


// ____________________ ����� ____________________


if(!empty($_POST['a_serf_c_s_type']) && isset($_POST['a_serf_c_s_text'])){
$a_serf_c_s_type=preg_replace("#[^a-z\_\-0-9]+#mi",'',$_POST['a_serf_c_s_type']);
if(!empty($search_type[$a_serf_c_s_type])){
$_SESSION['a_serf_c_s_type']=$a_serf_c_s_type;
$a_serf_c_s_text=substr($_POST['a_serf_c_s_text'],0,40);
$_SESSION['a_serf_c_s_text']=preg_replace("#[^0-9\.\+\ \-\;\&\#a-zA-Z�����������������������������������������Ũ�������������������������߯���]+#mi",'',$a_serf_c_s_text);
}
}


// ____________________ ��� � ������ ____________________


if(isset($_POST['ban_mode']) && strlen($_POST['ban_mode'])==1 && ($_POST['ban_mode']==0 || $_POST['ban_mode']==1) && !empty($_POST['ban_id'])){
$ban_mode=$_POST['ban_mode'];
$ban_id=preg_replace("#[^0-9]+#",'',$_POST['ban_id']);
$ban_id=number_format($ban_id,0,'','')+0;
if(!empty($ban_id) && is_numeric($ban_id) && strlen($ban_id)<11){
mysqli_query($db,"UPDATE users SET sp_ban_1=$ban_mode WHERE sp_uid_1=$ban_id") or die ('cant update ban level 1');
mysqli_query($db,"UPDATE users SET sp_ban_2=$ban_mode WHERE sp_uid_2=$ban_id") or die ('cant update ban level 2');
mysqli_query($db,"UPDATE users SET sp_ban_3=$ban_mode WHERE sp_uid_3=$ban_id") or die ('cant update ban level 3');
mysqli_query($db,"UPDATE users SET ban=$ban_mode WHERE uid=$ban_id LIMIT 1") or die ('cant update ban user');
if($ban_mode==0){ $message_success='������������ �������� �� ���� �������'; }
else{ $message_success='������������ ������� �� ���� �������'; }
}
}


// ____________________ ������ ������� Ѩ������  ____________________


if(!empty($_POST['free_uid'])){
$free_uid=preg_replace('#[^0-9]+#','',$_POST['free_uid']);
$free_uid=number_format($free_uid,0,'','');
if(empty($free_uid) || !is_numeric($free_uid) || strlen($free_uid)>10){ exit; }
mysqli_query($db,"UPDATE users SET serf_ban=0 WHERE uid=$free_uid LIMIT 1") or die('cant free_uid');
$message_success='������ ������� ����';
}


// ____________________ ��������� ������� Ѩ������  ____________________


if(!empty($_POST['sban_uid']) && !empty($_POST['sban_time'])){
$sban_uid=preg_replace('#[^0-9]+#','',$_POST['sban_uid']);
$sban_uid=number_format($sban_uid,0,'','');
if(empty($sban_uid) || !is_numeric($sban_uid) || strlen($sban_uid)>10){ exit; }
$sban_time=preg_replace('#[^0-9]+#','',$_POST['sban_time']);
$sban_time=number_format($sban_time,0,'','');
$sban_time+=$time;
if(empty($sban_time) || !is_numeric($sban_time) || strlen($sban_time)>10){ exit; }
mysqli_query($db,"UPDATE users SET serf_ban=$sban_time WHERE uid=$sban_uid LIMIT 1") or die('cant sban_uid');
$message_success='Ѹ����� ��������';
}


}


$np_sort_a=array();
$np_sort_a[]=array('���� �����','id DESC');
$np_sort_a[]=array('���� �������� �����','date_2 DESC');
$np_sort_a[]=array('uid','uid ASC');
$np_sort_a[]=array('ip','ip ASC');
$np_sort_a[]=array('��������','login ASC');
$np_sort_a[]=array('������ �������','num ASC');
$np_sort_a[]=array('������ ������','status ASC');
$np_sort_a[]=array('�������� �����','status=1 DESC');
$np_sort_a[]=array('�������� �������','status DESC');


if(isset($_GET['sort'])){
$pre=preg_replace('#[^0-9]+#','',$_GET['sort']);
$pre=preg_replace('#^[0]+#','',$pre);
$pre=number_format($pre,0,'','');
if(!empty($np_sort_a[$pre])){
$np_sort_n=$pre;
$np_sort=$np_sort_a[$pre][1];
}
}


if(!isset($np_sort_n)){ $np_sort_n=0; $np_sort=$np_sort_a[0][1]; }


// ____________________ ��� ������ ____________________


$where='';


if(!empty($_SESSION['a_serf_c_s_type']) && !empty($_SESSION['a_serf_c_s_text'])){
$a_serf_c_s_type=$_SESSION['a_serf_c_s_type'];
$a_serf_c_s_text=$_SESSION['a_serf_c_s_text'];
if($search_type[$a_serf_c_s_type][0]==0){
$where="WHERE $a_serf_c_s_type LIKE '%".$a_serf_c_s_text."%'";
}
if($search_type[$a_serf_c_s_type][0]==1){
$where="WHERE $a_serf_c_s_type='$a_serf_c_s_text'";
}
}


$np_pp=10;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM serf_clicks $where") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="a_np_def" href="/?page=a_serf_c&str=1&sort='.$np_sort_n.'#a_np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="a_np_def" href="/?page=a_serf_c&str=1&sort='.$np_sort_n.'#a_np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="a_np_now" href="/?page=a_serf_c&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="a_np_def" href="/?page=a_serf_c&str='.($n+1).'&sort='.$np_sort_n.'#a_np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="a_np_def" href="/?page=a_serf_c&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="a_np_def" href="/?page=a_serf_c&str='.$n.'&sort='.$np_sort_n.'#a_np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


if(!empty($message_success)){
echo '<script type="text/javascript">
document.getElementById("a_message").innerHTML=\'<div class="a_message_success">'.$message_success.'</div>\';
setTimeout("document.getElementById(\'a_message\').innerHTML=\'\';",2000);
</script>';
}


echo '<form id="form_ban" style="display:none;" method="POST">
<input id="ban_mode" type="hidden" name="ban_mode" value="0">
<input id="ban_id" type="hidden" name="ban_id" value="0">
<input type="hidden" name="a_time" value="'.$time.'">
</form>';


echo '<form id="form_free" style="display:none;" method="POST">
<input id="free_uid" type="hidden" name="free_uid" value="0">
<input type="hidden" name="a_time" value="'.$time.'">
</form>';


echo '<form id="form_sban" style="display:none;" method="POST">
<input id="sban_uid" type="hidden" name="sban_uid" value="0">
<input id="sban_time" type="hidden" name="sban_time" value="0">
<input type="hidden" name="a_time" value="'.$time.'">
</form>';


echo '<div class="a_sort_common"><span class="a_sort_word">����������� ��: </span>';


for($n=0;$n<sizeof($np_sort_a);$n++){
$np_link_a='';
if($n==$np_sort_n){ $np_link_a='_2'; }
echo '<a class="a_sort_a'.$np_link_a.'" href="/?page=a_serf_c&sort='.$n.'">'.$np_sort_a[$n][0].'</a>';
}


echo '</div>


<br>


<form id="form_search" method="POST">
<table align="center" cellpadding="2px" cellspacing="0px">
<tr>';
if(!empty($_SESSION['a_serf_c_s_text'])){
echo '<td><div class="a_users_search_button" onclick="document.getElementById(\'a_serf_c_s_text\').value=\'\'; document.getElementById(\'form_search\').submit();">��������</div></td>';
}
echo '<td class="a_users_search_word">����� ��: </td>
<td>
<select class="a_users_search_select" name="a_serf_c_s_type">';
foreach($search_type as $s_t_i=>$s_t_v){
if(!empty($_SESSION['a_serf_c_s_type']) && $s_t_i==$_SESSION['a_serf_c_s_type']){
echo '<option value="'.$s_t_i.'" selected>'.$s_t_v[1].'</option>';
}
else{ echo '<option value="'.$s_t_i.'">'.$s_t_v[1].'</option>'; }
}
echo '</select>
</td>
<td><input id="a_serf_c_s_text" autocomplete="off" class="a_users_search_input" type="text" placeholder="������� �����" name="a_serf_c_s_text" maxlength="40" value="'.$_SESSION['a_serf_c_s_text'].'"><input type="hidden" name="a_time" value="'.$time.'"></td>
<td><div class="a_users_search_button" onclick="document.getElementById(\'form_search\').submit();">�����</div></td></tr>
</table>
</form>


<br>';


if(!empty($np_links)){ echo '<a name="a_np_a" class="a_np_a"></a><div class="a_np_div">'.$np_links.'</div><br>'; }


echo '<table class="a_serf_c_table" cellpadding="5px" cellspacing="0px">
<tr>
<td class="a_users_s_title" align="center"># � UID</td>
<td class="a_users_s_title">
���� �����
<br>���� ��������
</td>
<td class="a_users_s_title" align="center"></td>
<td class="a_users_s_title">
������������
<br>IP �����
</td>
<td class="a_users_s_title">
id �������
</td>
<td class="a_users_s_title">
������
</td>
<td class="a_users_s_title">
������ �������
</td>
</tr>';


$users_a=array();
$uids=array();


$s_q=mysqli_query($db,"SELECT * FROM serf_clicks $where ORDER BY $np_sort LIMIT $np_start,$np_pp");
while($s_m=mysqli_fetch_assoc($s_q)){
$users_a[]=$s_m;
$uids[]=$s_m['uid'];
}


if(!empty($uids)){
$suids=implode(',',$uids);
$laq=mysqli_query($db,"SELECT uid,ban,serf_ban FROM users WHERE uid IN ($suids) LIMIT ".sizeof($uids)) or die ('cant select');
while($lam=mysqli_fetch_row($laq)){
for($n=0;$n<sizeof($users_a);$n++){
if($users_a[$n]['uid']==$lam[0]){
$users_a[$n]['ban']=$lam[1];
$users_a[$n]['serf_ban']=$lam[2];
}
}
}
}


$row_tr_n=0;


foreach($users_a as $s_m){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$banned='';
if($s_m['ban']==1){ $banned='class="a_serf_c_login_banned"'; }
echo '<tr class="a_serf_c_tr_'.$row_tr_n.'">
<td class="a_users_s_uid">'.$s_m['id'].'<br>'.$s_m['uid'];
if($s_m['ban']==0){ echo '<div class="a_users_s_uid_ban" onclick="ban(1,'.$s_m['uid'].');">���</div>'; }
else{ echo '<div class="a_users_s_uid_noban" onclick="ban(0,'.$s_m['uid'].');">������</div>'; }
echo '</td>
<td class="a_users_s_date">'.date('d.m.y H:i:s',$s_m['date']).'<br>'.date('d.m.y H:i:s',$s_m['date_2']).'</td>
<td class="a_users_s_avatar"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>
<td class="a_serf_c_login"><a '.$banned.' target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a><br><div>'.$s_m['ip'].'</div></td>
<td class="a_serf_c_num">'.$s_m['num'].'</td>
<td class="a_serf_c_status">';
if($s_m['status']==0){ echo '<div class="a_serf_c_status_0">������</div>'; }
if($s_m['status']==1){ echo '<div class="a_serf_c_status_1">�����</div>'; }
if($s_m['status']==2){ echo '<div class="a_serf_c_status_2">�������</div>'; }
echo '</td>
<td class="a_serf_u_cant">';


if($s_m['serf_ban']>$time){
$dt=$s_m['serf_ban']-$time;
$dd=(int)($dt/86400);
$hh=(int)(($dt-$dd*86400)/3600);
$mm=(int)(($dt-$dd*86400-$hh*3600)/60);
$ss=(int)($dt-$dd*86400-$hh*3600-$mm*60);
echo '<div class="a_serf_u_bdate">�� '.date('d.m.y H:i:s',$s_m['serf_ban']).'</div>';
echo '<div class="a_serf_u_until">����� '.$dd.'� '.$hh.'� '.$mm.'�</div>';
echo '<div class="a_serf_u_free" onclick="a_serf_free('.$s_m['uid'].');">����� ������</div>';
}
else{
echo '<select id="sban_'.$s_m['uid'].'" class="a_serf_u_set_ban_select" name="serf_set_ban">
<option value="86400">�� 1 ����</option>
<option value="604800">�� 1 ������</option>
<option value="2592000">�� 1 �����</option>
<option value="31536000">�� 1 ���</option>
</select>
<div class="a_serf_u_set_ban_button" onclick="a_serf_set_ban('.$s_m['uid'].');">���������</div>';
}


echo '</td>
</tr>';
}


echo '</table>';


if(!empty($np_links)){ echo '<br><div class="a_np_div">'.$np_links.'</div><br>'; }


echo '<script type="text/javascript">


function a_serf_free(free_uid){
if(confirm("����� ������ ?")){
document.getElementById("free_uid").value=free_uid;
document.getElementById("form_free").submit();
}
}


function a_serf_set_ban(sban_uid){
if(confirm("��������� ������ ?")){
document.getElementById("sban_uid").value=sban_uid;
document.getElementById("sban_time").value=document.getElementById("sban_"+sban_uid).value;
document.getElementById("form_sban").submit();
}
}


</script>';


?>
