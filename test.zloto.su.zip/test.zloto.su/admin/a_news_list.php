<?php


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


if(!empty($_POST['did'])){
$did=preg_replace("#[^0-9]+#",'',$_POST['did']);
$did=number_format($did,0,'','');
if(empty($did) || !is_numeric($did) || strlen($did)>10){ exit; }
mysqli_query($db,"DELETE FROM news WHERE id='$did' LIMIT 1") or die ('cant delete');
mysqli_query($db,"OPTIMIZE TABLE news") or die('cant optimize news');


$s_q=mysqli_query($db,"SELECT COUNT(*) FROM news");
$s_m=mysqli_fetch_row($s_q);


mysqli_query($db,"UPDATE data SET news_c=".(0+$s_m[0])." LIMIT 1") or die('cant update news list');


$message_success=1;


}


}


$np_pp=10;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM news") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="a_np_def" href="/?page=a_news_list&str=1#a_np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="a_np_def" href="/?page=a_news_list&str=1#a_np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="a_np_now" href="/?page=a_news_list&str='.($n+1).'#a_np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="a_np_def" href="/?page=a_news_list&str='.($n+1).'#a_np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="a_np_def" href="/?page=a_news_list&str='.$n.'#a_np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="a_np_def" href="/?page=a_news_list&str='.$n.'#a_np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


if(!empty($message_success)){
echo '<script type="text/javascript">
document.getElementById("a_message").innerHTML=\'<div class="a_message_success">������</div>\';
setTimeout("document.getElementById(\'a_message\').innerHTML=\'\';",2000);
</script>';
}


echo '
<form id="a_news_create_form" target="_blank" action="/?page=a_news_edit" method="POST">
<input type="hidden" name="act" value="create">
<input type="hidden" name="a_time" value="'.$time.'">
</form>


<form id="a_news_edit_form" action="/?page=a_news_edit" method="POST">
<input type="hidden" name="act" value="edit">
<input id="edit_id" type="hidden" name="id" value="0">
</form>


<table class="a_news_list_create_table" cellpadding="0px" cellspacing="0px">
<tr>
<td width="30%" class="a_news_list_create_word">�����: '.$np_real.'</td>
<td><div class="a_news_list_create_button"><span onclick="if(confirm(\'����� �������� �������?\')){ document.getElementById(\'a_news_create_form\').submit(); }">�������� �������</span></div></td>
<td width="30%"></td>
</tr>
</table>
';


echo '</div><br>';


if(!empty($np_links)){ echo '<br><a name="a_np_a" class="a_np_a"></a><div class="a_np_div">'.$np_links.'</div><br>'; }


$s_q=mysqli_query($db,"SELECT * FROM news ORDER BY id DESC LIMIT $np_start,$np_pp") or die('cant select news');
while($s_m=mysqli_fetch_assoc($s_q)){


echo '<table class="news_table" cellpadding="0px" cellspacing="0px">
<tr>
<td class="news_title">'.$s_m['title'].'</td>
<td class="news_date">'.$s_m['date'].'</td>
<td class="a_news_list_edit"><div onclick="document.getElementById(\'edit_id\').value='.$s_m['id'].';document.getElementById(\'a_news_edit_form\').submit();">��������</div></td>
</tr>
<tr>
<td class="news_text" colspan="3">'.$s_m['text'];
if(!empty($s_m['text_2'])){
echo '<div class="news_to_full"><div><a href="/news/r'.$s_m['id'].'">������ �����</a></div></div>';
}
echo '</td></tr></table>';
}


if(!empty($np_links)){ echo '<br><div class="a_np_div">'.$np_links.'</div>'; }


?>
