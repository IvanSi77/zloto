<?php


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


// ____________________ �������� ������������ ____________________


if(!empty($_POST['act']) && $_POST['act']=='red'){
$sm_red_in='';
$s_q=mysqli_query($db,"SELECT MAX(id) FROM support WHERE to_uid='".$u_id."' AND hide='' AND type='' GROUP BY hash");
while($s_q=mysqli_fetch_row($s_q)){
$sm_red_in.=$s_q[0].',';
}
$sm_red_in=trim($sm_red_in,',');
if($sm_red_in!=''){ mysqli_query($db,"UPDATE support SET flag=1 WHERE id IN($sm_red_in)"); }
mysqli_query($db,"UPDATE users SET support_from='' WHERE uid='$u_id' LIMIT 1");
$sm_red_ok=1;
echo '<script type="text/javascript">if(document.getElementById("left_menu_support")!=null){ document.getElementById("left_menu_support").className="left_menu_def"; }</script>';
}


// ____________________ ����� �� ������ ____________________


if(!empty($_POST['act']) && $_POST['act']=='login' && !empty($_POST['login'])){


$sm_to_value=preg_replace("#[^0-9\ \-\;\&\#a-zA-Z�����������������������������������������Ũ�������������������������߯���]+#mi",'',$_POST['login']);
if(empty($sm_to_value) || strlen($sm_to_value)<1 || strlen($sm_to_value)>40){ $sm_s_e='������'; }
if(empty($sm_s_e)){


if(!is_numeric($sm_to_value)){
$s_q=mysqli_query($db,"SELECT uid,login FROM users WHERE login LIKE '%".$sm_to_value."%' LIMIT 1") or die('cant search');
}
else{
$s_q=mysqli_query($db,"SELECT uid,login FROM users WHERE uid='$sm_to_value' LIMIT 1") or die('cant search');
}


$s_m=mysqli_fetch_assoc($s_q);
if(empty($s_m['uid'])){ $sm_s_e=$sm_to_value.' �� ������'; }
if(!empty($s_m['uid']) && $s_m['uid']!=$u_id){ $sm_s_uid=$s_m['uid']; $sm_s_login=$s_m['login']; }
}


if(empty($sm_s_e) && $s_m['uid']==$u_id){ $sm_s_e='������ ������ ������ ����'; }


}


}


// ____________________ ����ר� ������ ��������� ____________________


if($u_id!=$admin_uid){
$s_q=mysqli_query($db,"SELECT COUNT(*) FROM support WHERE from_uid='$u_id' AND date>".($time-3600)." AND message!=''");
if($s_q===false){
    error_log('Zend-Loto support inbox count failed ('.mysqli_errno($db).'): '.mysqli_error($db));
    http_response_code(500);
    echo '�� ������� ��������� ���������. ��������� PHP-������.';
    exit;
}
$s_m=mysqli_fetch_row($s_q);
$_SESSION['support_mc']=0+$s_m[0];
}


echo '<div class="title">'.$title.'</div>


<link rel="stylesheet" href="/support/support.css">


<form id="red" method="POST" style="display:none;"><input type="hidden" name="act" value="red"><input type="hidden" name="a_time" value="'.$time.'"></form>


<div class="sm_top">


<table align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td>


<table align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td class="sm_menu"><div class="sm_find" onclick="sm_find();">����� ������������</div></td>
<td class="sm_red">';
if(empty($sm_red_ok)){ echo '<div onclick="document.getElementById(\'red\').submit();">�������� ������������</div>'; }
else{
echo '<div id="sm_red_1" onclick="document.getElementById(\'red\').submit();" style="display:none;">�������� ������������</div>
<span id="sm_red_2" style="display:inline-block;">��������</span>
<script type="text/javascript">setTimeout("document.getElementById(\'sm_red_2\').style.display=\'none\';document.getElementById(\'sm_red_1\').style.display=\'inline-block\';",2000)</script>';
}
echo '</td>
</tr>
</table>


<br>';


if(!empty($sm_s_e)){ echo '<div class="sm_error">'.$sm_s_e.'</div>'; }
if(!empty($sm_s_uid)){ echo '<div class="sm_success"><span>������������ UID: '.$sm_s_uid.' '.$sm_s_login.'</span> <a href="/support_dialog/'.$sm_s_uid.'">�������� ���</a></div>'; }


echo '<div id="sm_form_div" class="sm_form_div" style="display:none;">
<form id="sm_form" method="POST">
<table align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td><input class="sm_form_input" type="text" name="login" placeholder="UID ��� �����" maxlength="40" autocomplete="off"></td>
<td><div class="sm_form_button" onclick="document.getElementById(\'sm_form\').submit();">�����</div></td>
</tr>
</table>
<input type="hidden" name="act" value="login">
<input type="hidden" name="a_time" value="'.$time.'">
</form>
</div>


<br>';


// ____________________ ��������� ____________________


$np_pp=10;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM support WHERE (from_uid='".$u_id."' OR (to_uid='".$u_id."' AND hide='')) AND type='' GROUP BY hash");
if($np_q===false){
    error_log('Zend-Loto support inbox query failed ('.mysqli_errno($db).'): '.mysqli_error($db));
    http_response_code(500);
    echo '�� ������� ��������� ���������. ��������� PHP-������.';
    exit;
}
$np_m=mysqli_num_rows($np_q);
$np_real=0+$np_m;
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="np_def" href="/support/1#np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="np_def" href="/support/1#np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="np_now" href="/support/'.($n+1).'#np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="np_def" href="/support/'.($n+1).'#np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="np_def" href="/support/'.$n.'#np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="np_def" href="/support/'.$n.'#np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


if(!empty($np_links)){ echo '<a name="np_a" class="np_a"></a><div class="np_div">'.$np_links.'</div><br>'; }


function sm_time_ago($time,$ago_t){
$mdate=array('���','���','���','���','���','���','���','���','���','���','���','���');
$ago_w='';
$ago_date=$ago_t;
$ago_time=$time-$ago_t;
$n_date=date('j',$time);
$a_date=date('j',$ago_date);
if(($n_date-$a_date)==1 && $ago_time<172800){
$ago_w=date('����� � H:i',$ago_date);
}
if($n_date==$a_date && $ago_time<86400){
$ago_w=date('������� � H:i',$ago_date);
}
if($ago_w==''){
$ago_w=date('j ',$ago_date).$mdate[date('n',$ago_date)-1].' � '.date(' H:i',$ago_date);
}
return $ago_w;
}


$sm_message_in='';


$cq=mysqli_query($db,"SELECT MAX(id) as vbn FROM support WHERE (from_uid='".$u_id."' OR (to_uid='".$u_id."' AND hide='')) AND type='' GROUP BY hash ORDER by vbn DESC LIMIT $np_start,$np_pp") or die('cant max');
while($cm=mysqli_fetch_row($cq)){
$sm_message_in.=$cm[0].',';
}


$sm_message_in=trim($sm_message_in,',');
$sm_a=array();
$sm_who=array();


if($sm_message_in!=''){
$sm_q=mysqli_query($db,"SELECT * FROM support WHERE id IN ($sm_message_in) ORDER by id DESC") or die('cant max message');
while($sm_m=mysqli_fetch_assoc($sm_q)){
$sm_a[]=$sm_m;
$sm_who[$sm_m['from_uid']]=$sm_m['from_login'];
}


foreach($sm_a as $s_m){


$message=$s_m['message'];
$ddots='';


if(strlen($message)>100){ $ddots='...'; }


$message=str_replace('<br>',' ',$message);
$message=preg_replace('#\<img src="\/images\/smiles\/([^>]*)>#mi','#sm#\1@sm@',$message);
$message=preg_replace('#\<img[^>]*>#mi',' ���� ',$message);
$message=preg_replace('#\<[^>]*>#m','',$message);
$message=preg_replace('#\ +#mi',' ',$message);
$message=preg_replace('#^\ +#mi','',$message);
$message=preg_replace('#\ +$#mi','',$message);
$message=substr($message,0,100);
$message=str_replace('#sm#','<img src="/images/smiles/',$message);
$message=str_replace('@sm@','>',$message);
$message=preg_replace('#\<[^>]*$#mi','',$message);
$message=preg_replace('#\ +#mi',' ',$message);
$message=preg_replace('#^\ +#mi','',$message);
$message=preg_replace('#\ +$#mi','',$message);


if(empty($message)){ $message='���������'; }


$message.=$ddots;


if($s_m['from_uid']!=$u_id){ $sm_login=$s_m['from_login']; $sm_to=$s_m['from_uid']; $sm_to_avatar=$s_m['from_avatar']; }
else{ $sm_login=$s_m['to_login']; $sm_to=$s_m['to_uid']; $sm_to_avatar=$s_m['to_avatar']; }


echo '
<div class="sm_common" id="sm_uid_'.$sm_to.'">
<span class="sm_delete_span"><div class="sm_delete" onclick="sm_delete('.$sm_to.');"><div class="sm_tip">������� ������</div></div></span>
<a class="sm_alink" href="/support_dialog/'.$sm_to.'">';
$sm_tab=1;
if($s_m['from_uid']!=$u_id && $s_m['flag']==''){ $sm_tab=2; }
echo '
<table class="sm_table_'.$sm_tab.'" cellpadding="0px" cellspacing="0px">
<tr>
<td class="sm_avatar"><img src="'.$sm_to_avatar.'">
</td>
<td class="sm_who"><font>'.$sm_login.'</font><br><span>'.sm_time_ago($time,$s_m['date']).'</span></td>';
if($s_m['flag']==''){ $sm_m_c=1; }
else{ $sm_m_c=2; }
if($s_m['from_uid']==$u_id){
echo '<td class="sm_mini_'.$sm_m_c.'"><img class="sm_mini_avatar" src="/support/images/avatar.png"></td><td class="sm_message_1_'.$sm_m_c.'"><div class="sm_div_m">'.$message.'</div></td>';
}
else{
echo '<td class="sm_message_2"><div class="sm_div_m">'.$message.'</div></td>';
}
echo '</tr></table></a></div>';
}
}


if(!empty($np_links)){ echo '<br><div class="np_div">'.$np_links.'</div>'; }


if(empty($sm_a)){
echo '<div class="sm_no_message">��������� ���</div>';
}


echo '
</td>
</tr>
</table>


</div>


<script type="text/javascript">


function sm_find(){
if(document.getElementById("sm_form_div").style.display=="block"){ document.getElementById("sm_form_div").style.display="none"; }
else{ document.getElementById("sm_form_div").style.display="block"; }
}


function sm_getXmlHttp(){
var sm_xmlhttp;
try{ sm_xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); }
catch(e){
try{ sm_xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); }
catch(e){ sm_xmlhttp=false; }
}
if(!sm_xmlhttp && typeof XMLHttpRequest!="undefined"){
sm_xmlhttp=new XMLHttpRequest();
}
return sm_xmlhttp;
}


function sm_delete(sm_toid){
if(!confirm(\'������� ���� ��������� � ������ ����� ?\')){ return; }
myreq="dialog_delete="+sm_toid;
var sm=sm_getXmlHttp()
sm.onreadystatechange=function() {
if(sm.readyState==4){
if(sm.status==200) { eval(sm.responseText); }
else{ alert("������:\n"+req.statusText); }
}}
sm.open("POST","/support/support_ajax.php",true);
sm.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
sm.send(myreq);
}


</script>';


?>
