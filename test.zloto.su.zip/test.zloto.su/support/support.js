function sd_sound_toggle(){
if(sd_sound==1){ sd_sound=0; }
else{ sd_sound=1; }
document.cookie="sd_sound="+sd_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+sd_sound;
}


var sd_time_talk=4000;
var sd_time_common=2000;
var sd_time_message=2000;


function sd_smiles_show(){
if(document.getElementById("sd_div_smiles").style.display=='block'){
document.getElementById("sd_div_smiles").style.display='none';
}
else{
document.getElementById("sd_div_smiles").style.display='block';
}
}


// ____________________ ��������� ____________________


var message_stop_scroll=0;

function message_scroll(){
var message_scroll_div=document.getElementById("sd_message_cont");
message_scroll_div.scrollTop=message_scroll_div.scrollHeight;
}


function message_slow_scroll(){
var message_slow_scroll_div=document.getElementById("sd_message_cont");
if(message_stop_scroll==0){
message_slow_scroll_div.scrollTop+=2;
}
setTimeout("message_slow_scroll()",12);
}

setTimeout("message_scroll();message_slow_scroll()",12);


// ____________________ AJAX STANDARD ____________________


function sd_getXmlHttp(){
var sd_xmlhttp;
try{ sd_xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); }
catch(e){
try{ sd_xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
catch(E){ sd_xmlhttp=false; }
}
if(!sd_xmlhttp && typeof XMLHttpRequest!="undefined"){
sd_xmlhttp=new XMLHttpRequest();
}
return sd_xmlhttp;
}


// ____________________ ��������� ���� �������� ____________________


function sd_stop_send(){
clearTimeout(timeout_sd);
clearTimeout(timeout_common_can);
clearTimeout(timeout_message_can);
sd_common_can=0;
message_can=0;
}


// ____________________ ������������� ���� �������� ____________________


function sd_can_send(sd_send_mode){
if(sd_send_mode=="online"){
timeout_sd=setTimeout(update_sd_online,sd_time_talk);
sd_common_can=1;
message_can=1;
}
if(sd_send_mode=="common"){
timeout_sd=setTimeout(update_sd_online,sd_time_talk);
timeout_common_can=setTimeout("sd_common_can=1",sd_time_common);
message_can=1;
}
if(sd_send_mode=="message"){
timeout_sd=setTimeout(update_sd_online,sd_time_talk);
sd_common_can=1;
timeout_message_can=setTimeout("message_can=1;",sd_time_message);
}
}


// ____________________ ���������� ������� ____________________


function update_sd_online() {

var mysd="to="+dlto+"&last="+dlm;

sd_stop_send();

var sd_req=sd_getXmlHttp();
sd_req.onreadystatechange=function() {
if(sd_req.readyState==4){
if(sd_req.status==200){
try{ eval(sd_req.responseText); }
catch(e){}
}
sd_can_send("online");
}
}
sd_req.open("POST","/support/support_ajax.php",true);
sd_req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
sd_req.send(mysd);
}


// ____________________ ����� ____________________


var sd_common_can=1;

function sd_common(sd_common_value,sd_common_mode){

if(sd_common_can==1){
sd_stop_send();

if(sd_common_mode=="del"){
var my_common="to="+dlto+"&last="+dlm+"&d_id="+sd_common_value;
}
else if(sd_common_mode=="bell"){
var my_common="to="+dlto+"&last="+dlm+"&bell="+sd_common_value;
}
else if(sd_common_mode=="show"){
var my_common="to="+dlto+"&last="+dlm+"&show="+sd_common_value;
}

var sd_common_req=sd_getXmlHttp();
sd_common_req.onreadystatechange=function() {
if(sd_common_req.readyState==4){
if(sd_common_req.status==200) {
try{ eval(sd_common_req.responseText); }
catch(e){}
}
sd_can_send("common");
}
}
sd_common_req.open("POST","/support/support_ajax.php",true);
sd_common_req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
sd_common_req.send(my_common);
}
}

timeout_common_can=setTimeout("sd_common_can=1",100);


// ____________________ ���� �������� ��������� ____________________


function sd_mdn(sd_mdn_num){
if(document.getElementById("sd_m_"+sd_mdn_num)!=null){
document.getElementById("sd_m_"+sd_mdn_num).remove();
if(sd_sound==1){ document.getElementById("sd_sound_delete").play(); }
}
}


// ____________________ �������� ��������� ____________________


var message_can=1;

function message_send(){

if(message_can==1){

if(document.getElementById("sd_text").value==""){
return;
}

sd_stop_send();

var mymessage="message="+document.getElementById("sd_text").innerHTML;
mymessage=mymessage.replace(/\&/g,"%26");
mymessage=mymessage.replace(/\+/g,"%2B");
mymessage=mymessage.replace(/\\/g,"^backslash^");
mymessage+="&to="+dlto+"&last="+dlm;


document.getElementById("sd_text").innerHTML="";

var sd_message=sd_getXmlHttp();
sd_message.onreadystatechange=function() {
if(sd_message.readyState==4){
if(sd_message.status==200) {
try{ eval(sd_message.responseText); }
catch(e){}
}
sd_can_send("message");
}
}
sd_message.open("POST","/support/support_ajax.php",true);
sd_message.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
sd_message.send(mymessage);
}
}


timeout_message_can=setTimeout("message_can=1",100);

timeout_sd=setTimeout(update_sd_online,sd_time_talk);


// ____________________ ����� � ����� ____________________


function placeCaretAtEnd() {
sd_txt=document.getElementById("sd_text");
sd_txt.focus();
if (typeof window.getSelection != "undefined" && typeof document.createRange != "undefined") {
var range = document.createRange();
range.selectNodeContents(sd_txt);
range.collapse(false);
var sel = window.getSelection();
sel.removeAllRanges();
sel.addRange(range);
} else if (typeof document.body.createTextRange != "undefined") {
var textRange = document.body.createTextRange();
textRange.moveToElementText(sd_txt);
textRange.collapse(false);
textRange.select();
}
}


// ____________________ ������ ____________________


function my_smile(set_smile) {
document.getElementById("sd_text").innerHTML+='&nbsp;<img class="sd_m_s" src="/images/smiles/'+set_smile+'.gif">&nbsp;';
placeCaretAtEnd();
}


// ____________________ ��������� ____________________


var sd_spec_bell_can=1;


function sd_spec_bell(){
if(sd_spec_bell_can==1){
sd_spec_bell_can=0;
if(sd_sound==1){ document.getElementById("sd_sound_bell").play(); }
setTimeout('sd_spec_bell_can=1;',3000);
}
}


// ____________________ ������� ���� ____________________


function sd_mtob(tbphoto){
var sd_big_p=tbphoto.src;
if(!sd_big_p.match(/_m\.gif$/g)){
sd_big_p=sd_big_p.replace(/_m/g,"");
}
document.getElementById("sd_big_photo_td").innerHTML='<img src="'+sd_big_p+'">';
document.getElementById("sd_big_photo").style.display="block";
}


// ____________________ �������� ���� ____________________


var sd_photo_ajax=new XMLHttpRequest();


sd_photo_ajax.upload.addEventListener('progress',function(e){
if(e.lengthComputable){
var sd_photo_upload_pr=(e.loaded/e.total*100);
document.getElementById("sd_photo_progress").innerHTML=parseInt(sd_photo_upload_pr);
if(sd_photo_upload_pr==100){
}
}
},false);


function sd_photo_ajax_send(){


document.getElementById("sd_photo_progress").style.display="block";
var sd_photo_ajax_form=new FormData();
for(var n=0;n<document.getElementById("sd_photo_upload").files.length;n++){
if(n>=sd_photo_c){ alert("������ ������ "+sd_photo_c); break; }
sd_photo_ajax_form.append('photo[]',document.getElementById("sd_photo_upload").files[n]);
}
sd_photo_ajax.onreadystatechange=function(){
if(sd_photo_ajax.readyState==4){
document.getElementById("sd_photo_progress").style.display="none";
document.getElementById("sd_photo_upload").value="";
if(sd_photo_ajax.status==200){
try{ eval(sd_photo_ajax.responseText); }
catch(e){}
}
}
}
sd_photo_ajax.open("POST","/support/support_photo.php",true);
sd_photo_ajax.send(sd_photo_ajax_form);
}
