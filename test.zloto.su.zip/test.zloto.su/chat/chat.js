function chat_sound_toggle(){
if(chat_sound==1){ chat_sound=0; }
else{ chat_sound=1; }
document.cookie="chat_sound="+chat_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+chat_sound;
}


var chat_time_talk=2000;
var chat_time_common=2000;
var chat_time_message=2000;


var chat_not_my_win=setTimeout("",100);
var chat_my_win=setTimeout("",100);


var chat_remember_message_t=setTimeout("chat_remember_message_f();",1000);
var chat_text_now='';


function chat_remember_message_f(){
clearTimeout(chat_remember_message_t);
chat_text_now=document.getElementById("chat_text").innerHTML;
if(chat_text_now!=""){
chat_text_now=chat_text_now.replace(/;+/g,'#8zDbA');
document.cookie="chat_message="+chat_text_now+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
}
chat_remember_message_t=setTimeout("chat_remember_message_f();",1000);
}


var matches=document.cookie.match(new RegExp("(?:^|; )chat_message=([^;]*)"));
var chat_cookie_message=matches ? decodeURIComponent(matches[1]) : '';


if(chat_cookie_message!=''){
chat_cookie_message=chat_cookie_message.replace(/#8zDbA+/g,';');
document.getElementById("chat_text").innerHTML=chat_cookie_message;
}


function chat_smiles_show(){
if(document.getElementById("chat_div_smiles").style.display=="none"){
document.getElementById("chat_div_smiles").style.display="block";
}
else{
document.getElementById("chat_div_smiles").style.display="none";
}
}


// ____________________ ��������� ____________________


var message_stop_scroll=0;


function message_scroll(){
var message_scroll_div=document.getElementById("chat_message_cont");
message_scroll_div.scrollTop=message_scroll_div.scrollHeight;
}


function message_slow_scroll(){
var message_slow_scroll_div=document.getElementById("chat_message_cont");
if(message_stop_scroll==0){
message_slow_scroll_div.scrollTop+=1;
}
setTimeout("message_slow_scroll()",12);
}


setTimeout("message_scroll();message_slow_scroll()",12);


// ____________________ ������ ��������� ____________________



function message_old(){

clearTimeout(timeout_old_message);
timeout_old_message=setTimeout("message_old();",10000);

var message_old_div=document.getElementById("chat_message_cont");
var now_scroll=message_old_div.scrollTop;
message_old_div.scrollTop+=1;
if(message_old_div.scrollTop!=now_scroll){
message_old_div.scrollTop-=1;
return;
}
var message_old_t=document.getElementById("chat_message_cont");
var message_count=0;
if(message_old_t){
var message_ts=message_old_t.getElementsByTagName("table");
var message_len=message_ts.length;
for(var i=0;i<message_len;i++){
if(message_ts[i]!=null){
if(message_ts[i].className=="chat_m_t") {
message_count++;
}
}
}
}
var message_to_dell=message_count-message_max;
if(message_to_dell>0){
for(var n=0;n<message_to_dell;n++){
var message_tns=message_old_t.getElementsByTagName("table");
var message_len=message_tns.length;
for(var i=0;i<message_len;i++){
if(message_tns[i]!=null){
if(message_tns[i].className=="chat_m_t") {
message_tns[i].remove();
break;
}
}
}
}
}
}


timeout_old_message=setTimeout("message_old();",60000);


// ____________________ AJAX STANDARD ____________________


function chat_getXmlHttp(){
var chat_xmlhttp;
try{ chat_xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); }
catch(e){
try{ chat_xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");}
catch(e){ chat_xmlhttp=false; }
}
if(!chat_xmlhttp && typeof XMLHttpRequest!="undefined"){
chat_xmlhttp=new XMLHttpRequest();
}
return chat_xmlhttp;
}


// ____________________ ��������� ���� �������� ____________________


function chat_stop_send(){
clearTimeout(timeout_chat);
clearTimeout(timeout_common_can);
clearTimeout(timeout_message_can);
chat_common_can=0;
message_can=0;
}


// ____________________ ������������� ���� �������� ____________________


function chat_can_send(chat_send_mode){
if(chat_send_mode=="online"){
timeout_chat=setTimeout(update_chat_online,chat_time_talk);
chat_common_can=1;
message_can=1;
}
if(chat_send_mode=="common"){
timeout_chat=setTimeout(update_chat_online,chat_time_talk);
timeout_common_can=setTimeout("chat_common_can=1",chat_time_common);
message_can=1;
}
if(chat_send_mode=="message"){
placeCaretAtEnd();
timeout_chat=setTimeout(update_chat_online,chat_time_talk);
chat_common_can=1;
timeout_message_can=setTimeout("message_can=1;",chat_time_message);
}
}


// ____________________ ���������� ���� � ������� ____________________


function update_chat_online() {


var mychat="online=1";


chat_stop_send();


var chat_req=chat_getXmlHttp();
chat_req.onreadystatechange=function() {
if(chat_req.readyState==4){
if(chat_req.status==200){

try{ eval(chat_req.responseText); }
catch(e){}

chat_can_send("online");

}
else{

chat_can_send("online");

}
}
}
chat_req.open("POST","/chat/chat_ajax.php",true);
chat_req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
chat_req.send(mychat);
}


// ____________________ ����� ����������� ������������ �������� ������������� ____________________


var chat_common_can=1;


function chat_common(chat_common_value,chat_common_mode){


if(chat_common_can==1){
chat_stop_send();

if(chat_common_mode=="noban"){
var my_common="noban="+chat_common_value;
}
else if(chat_common_mode=="del"){
var my_common="d_id="+chat_common_value;
}
else if(chat_common_mode=="moder"){
var my_common="moder="+chat_common_value;
}
else if(chat_common_mode=="bell"){
var my_common="bell="+chat_common_value;
}
else{
var my_common="ban="+chat_common_value+"&ban_time="+chat_common_mode;
}

var chat_common_req=chat_getXmlHttp();
chat_common_req.onreadystatechange=function() {
if(chat_common_req.readyState==4){
if(chat_common_req.status==200) {


try{ eval(chat_common_req.responseText); }
catch(e){}


chat_can_send("common");

}
else{

chat_can_send("common");

}
}
}
chat_common_req.open("POST","/chat/chat_ajax.php",true);
chat_common_req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
chat_common_req.send(my_common);
}
}

timeout_common_can=setTimeout("chat_common_can=1",100);


// ____________________ ���� �������� ��������� ____________________


function chat_mdn(chat_mdn_num){
if(document.getElementById("chat_m_"+chat_mdn_num)!=null){
document.getElementById("chat_m_"+chat_mdn_num).remove();
if(chat_sound==1){ document.getElementById("chat_sound_delete").play(); }
}
}


// ____________________ ������ ��������� ____________________


function tlsto(tlsto_login){
if(chat_lsto==""){
chat_lsto=tlsto_login;
document.getElementById("chat_ls_span").style.display="inline-block";
}
else if(chat_lsto==tlsto_login){
chat_lsto="";
document.getElementById("chat_ls_span").style.display="none";
}
}


// ____________________ �������� ��������� ____________________


var message_can=1;
var chat_lsto="";


function message_send(){


if(message_can==1){


if(document.getElementById("chat_text").value==""){
return;
}


chat_stop_send();


var mymessage="message="+document.getElementById("chat_text").innerHTML;
mymessage=mymessage.replace(/\&/g,"%26");
mymessage=mymessage.replace(/\+/g,"%2B");
mymessage=mymessage.replace(/\\/g,"^backslash^");
mymessage+="&lsto="+chat_lsto;


chat_lsto="";
document.getElementById("chat_text").innerHTML="";
document.getElementById("chat_ls_span").style.display="none";

var chat_message=chat_getXmlHttp();
chat_message.onreadystatechange=function() {
if(chat_message.readyState==4){
if(chat_message.status==200) {


try{ eval(chat_message.responseText);}
catch(e){}


chat_can_send("message");
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/^\<div\>\<br\>\<\/div\>/g,'');
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/^\<div\>\<br\>\<\/div\>/g,'');
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/\<div\>\<br\>\<\/div\>$/g,'');
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/\<div\>\<br\>\<\/div\>$/g,'');
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/^\<br\>/g,'');
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/^\<br\>/g,'');
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/\<br\>$/g,'');
document.getElementById('chat_text').innerHTML=document.getElementById('chat_text').innerHTML.replace(/\<br\>$/g,'');
}
else{


chat_can_send("message");


}
}
}
chat_message.open("POST","/chat/chat_ajax.php",true);
chat_message.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
chat_message.send(mymessage);
}
}


timeout_message_can=setTimeout("message_can=1",100);


timeout_chat=setTimeout("update_chat_online();",chat_time_talk);


// ____________________ ����� � ����� ____________________


function placeCaretAtEnd() {
chat_txt=document.getElementById("chat_text");
chat_txt.focus();
if (typeof window.getSelection != "undefined" && typeof document.createRange != "undefined") {
var range = document.createRange();
range.selectNodeContents(chat_txt);
range.collapse(false);
var sel = window.getSelection();
sel.removeAllRanges();
sel.addRange(range);
} else if (typeof document.body.createTextRange != "undefined") {
var textRange = document.body.createTextRange();
textRange.moveToElementText(chat_txt);
textRange.collapse(false);
textRange.select();
}
}


// ____________________ ������ ____________________


function chat_smile(set_smile) {
document.getElementById("chat_text").innerHTML+='&nbsp;<img class="chat_m_s" src="/images/smiles/'+set_smile+'.gif">&nbsp;';
placeCaretAtEnd();
}


// ____________________ ��������� � ������������ ____________________


function chat_to(talk_to_who){
document.getElementById("chat_text").innerHTML+=talk_to_who+",&nbsp;";
}


// ____________________ ��������� ____________________


var chat_spec_bell_can=1;


function chat_spec_bell_reset(){
setTimeout('document.getElementById("chat_spec_bell_table").style.marginLeft="0px";',400);
setTimeout('document.getElementById("chat_spec_bell_table").style.marginTop="0px";',400);
setTimeout('chat_spec_bell_can=1;',3000);
}


function chat_spec_bell(){
if(chat_spec_bell_can==1){
chat_spec_bell_can=0;

if(chat_sound==1){ document.getElementById("chat_sound_bell").play(); }

for(var sp=1;sp<30;sp++){

var chat_spec_bell_rand=Math.floor(Math.random()*(15-5));

setTimeout('document.getElementById("chat_spec_bell_table").style.marginLeft='+chat_spec_bell_rand+'+"px";',12*sp);

var chat_spec_bell_rand=Math.floor(Math.random()*(15-5));

setTimeout('document.getElementById("chat_spec_bell_table").style.marginTop='+chat_spec_bell_rand+'+"px";',12*sp);
if(sp==29){
chat_spec_bell_reset();
}
}

}
}


// ____________________ ������� ____________________


var chat_show_banned=1;


function chat_banned_message(tbm_ajax){
if(chat_show_banned==1){
chat_show_banned=0;
if(chat_sound==1){ document.getElementById("chat_sound_banned").play(); }
document.getElementById("chat_banned_message").innerHTML=tbm_ajax;
document.getElementById("chat_banned_message").style.display="block";
clearTimeout(timeout_you_banned);
timeout_you_banned=setTimeout("document.getElementById(\"chat_banned_message\").style.display=\"none\";chat_show_banned=1;",5000);
}
}


timeout_you_banned=setTimeout("chat_show_banned=1",100);


// ____________________ ������� ���� ____________________


function chat_mtob(tbphoto){
var chat_big_p=tbphoto.src;
if(!chat_big_p.match(/_m\.gif$/g)){
chat_big_p=chat_big_p.replace(/_m/g,"");
}
document.getElementById("chat_big_photo_td").innerHTML='<img src="'+chat_big_p+'">';
document.getElementById("chat_big_photo").style.display="block";
}


// ____________________ ������� ____________________


var chat_rate_can=1;


function chat_rate() {


if(chat_rate_can==0){
if(document.getElementById("chat_rate_div").style.display=="block"){ document.getElementById("chat_rate_div").style.display="none"; }
else{ document.getElementById("chat_rate_div").style.display="block"; }
return;
}


if(chat_rate_can==1){
var mychat="rate=1";

chat_rate_can=0;
var chat_req=chat_getXmlHttp();
chat_req.onreadystatechange=function() {
if(chat_req.readyState==4){
if(chat_req.status==200){


try{ eval(chat_req.responseText); }
catch(e){}

timeout_chat=setTimeout("chat_rate_can=1",2000);
}
else{
timeout_chat=setTimeout("chat_rate_can=1",2000);
}
}
}
chat_req.open("POST","/chat/chat_ajax.php",true);
chat_req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
chat_req.send(mychat);
}
}


timeout_chat=setTimeout("chat_rate_can=1",100);


// ____________________ �������� ���� ____________________


var chat_photo_ajax=new XMLHttpRequest();


chat_photo_ajax.upload.addEventListener('progress',function(e){
if(e.lengthComputable){
var chat_photo_upload_pr=(e.loaded/e.total*100);
document.getElementById("chat_photo_progress").innerHTML=parseInt(chat_photo_upload_pr);
if(chat_photo_upload_pr==100){
}
}
},false);


function chat_photo_ajax_send(){


document.getElementById("chat_photo_progress").style.display="block";
var chat_photo_ajax_form=new FormData();
for(var n=0;n<document.getElementById("chat_photo_upload").files.length;n++){
if(n>=chat_photo_c){ alert("������ ������ "+chat_photo_c); break; }
chat_photo_ajax_form.append('photo[]',document.getElementById("chat_photo_upload").files[n]);
}
chat_photo_ajax.onreadystatechange=function(){
if(chat_photo_ajax.readyState==4){
document.getElementById("chat_photo_progress").style.display="none";
document.getElementById("chat_photo_upload").value="";
if(chat_photo_ajax.status==200){
try{ eval(chat_photo_ajax.responseText); }
catch(e){}
}
}
}
chat_photo_ajax.open("POST","/chat/chat_photo.php",true);
chat_photo_ajax.send(chat_photo_ajax_form);
}
