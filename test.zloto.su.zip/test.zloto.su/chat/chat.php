<?php


// ____________________ ������ ____________________
// ���� ��� ������ �� �������, �� ��������� �������
// � �������� ��������� �����, ���������� �����, �����, ���ר��������, ����. ������ ������


$chat_smiles=array(
'hi','highfive','handshake',
'nod','shake','yes','no',
'smile','wink','giggle','laugh','rofl','cwl',
'happy','mmm','surprised','clap','party','festiveparty','holidayspirit','santa','santamooning','xmastree','gift','cake',
'sad','cry','dull','envy','facepalm','hungover','lalala','lipssealed','puke','sarcastic','sweat','tmi','whew','worry',
'wonder','donttalktome','fubar','talktothehand','wtf','angry','punch',
'yawn','sleepy','angel','wasntme','blush','bandit','call','cool','smoke','muscle','wait',
'think','idea','movember','nerdy',
'makeup','kiss','inlove','heart','hug',
'headphones','bhangra','skipping','dance','hollest',
'sun','rainbow','rain','tumbleweed',
'coffee','drink','champagne','beer','drunk',
'bug','cat','dog','donkey','heidy','monkey','penguin','snail',
'flower','goodluck','island',
'bike','computerrage','ontheloo','bow','man','gottarun','stop','shopping',
'waiting','holdon','letsmeet',
'bell','bomb','camera','car','cash','computer','phone','mail','star','whatsgoingon',
1,2,3,4,5,6,7,8,
9,10,11,12,13,14,15,16,
17,18,19,20,21,22,23,24,
25,26,27,28,29,30,31,32,
33,34,35,36,37,38,39,40,
41,42,43,44,45,46,47,48,
49,50,51,52,53,54,55,56,
57,58,59,60,61,62,63,64,
65,66,67,68,69,70,71,72,
73,74,75,76,77,78,79,80,
81,82,83,84,85,86,87,88,
89,90,91,92,93,94,95,96,
97,98,99,100,101,102,103,104,
105,106,107,108
);


if(!isset($_COOKIE['chat_sound']) || $_COOKIE['chat_sound']==1){ $sound=1; }else{ $sound=0; }
echo '<div class="title">'.$title.'<span id="sound" class="sound_'.$sound.'" onclick="chat_sound_toggle();"></span></div>
<script type="text/javascript">var chat_sound='.$sound.';</script>


<link href="/chat/chat.css" rel="stylesheet" type="text/css">';


if(!empty($mobile)){
echo '<style>
.chat_messages {
height:200px;
}
.chat_who_online {
height:190px;
}
.chat_big_photo td {
height:320px;
}
.chat_big_photo img {
max-height:300px;
}
.chat_my_win {
margin-top:186px;
}
</style>';
}


// ____________________ ��������� ������ ____________________


if($chat_game==1){


if($d['chat_eweek']<$time){
$chat_dn=date('w',$time);
$chat_at=0;
if($chat_dn==0){ $chat_at=86400; }
if($chat_dn>1){ $chat_at=-86400*($chat_dn-1); }
$chat_eweek=strtotime(date('d.m.Y',$time))+$chat_at;
$chat_eweek=preg_replace("#[^0-9]+#",'',$chat_eweek);
$chat_eweek=604800+number_format($chat_eweek,0,'','');
if(empty($chat_eweek) || !is_numeric($chat_eweek) || strlen($chat_eweek)!=10){
echo '������! �� ���� ���������� ����� ������������� ��������� ��������.';
exit;
}


$n=0;
$chat_last_week='';
$s_q=mysqli_query($db,"SELECT login,chat_words_w,uid,avatar FROM users ORDER BY chat_words_w DESC LIMIT 10");
while($s_m=mysqli_fetch_assoc($s_q)){
$n++;
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$chat_last_week.='<table class="chat_rate_list_table" cellpadding="0px" cellspacing="0px">';
$chat_last_week.='<tr><td class="chat_rate_num"><div>'.$n.'</div></td>';
$chat_last_week.='<td class="chat_rate_avatar"><img src="'.$s_m['avatar'].'"></td>';
$chat_last_week.='<td class="chat_rate_user"><div title="'.$s_m['uid'].'">'.$s_m['login'].'</div></td>';
$chat_last_week.='<td class="chat_rate_words"><div>'.$s_m['chat_words_w'].'</div></td></tr>';
$chat_last_week.='</table>';
}


mysqli_query($db,"UPDATE users SET chat_words_w=0") or die('cant chat_words_w=0');
mysqli_query($db,'UPDATE data SET chat_eweek="'.$chat_eweek.'",chat_last_week="'.str_replace('"','\"',$chat_last_week).'" WHERE chat_eweek="'.$d['chat_eweek'].'" LIMIT 1') or die('cant update chat_eweek');
$d['chat_eweek']=$chat_eweek;
$d['chat_last_week']=$chat_last_week;
}


if(empty($d['chat_eweek']) || !is_numeric($d['chat_eweek']) || strlen($d['chat_eweek'])!=10){
echo '������! �������� ����� chat_eweek.';
exit;
}


$_SESSION['chat_eweek']=$d['chat_eweek'];


}


// ____________________ ���������� ������� ____________________


$chatq=mysqli_query($db,"SELECT last_time FROM chat_online WHERE uid='$u_id'");
if(mysqli_num_rows($chatq)>0){ mysqli_query($db,"UPDATE chat_online SET last_time='".($chat_last_time+$time)."',status='".$mydm['chat_am']."',words='".$mydm['chat_words']."',avatar='".$mydm['avatar']."' WHERE uid='$u_id' LIMIT 1"); }
else{ mysqli_query($db,"INSERT INTO chat_online (last_time,login,status,words,uid,avatar) VALUES ('".($chat_last_time+$time)."','".$mydm['login']."','".$mydm['chat_am']."','".$mydm['chat_words']."','$u_id','".$mydm['avatar']."')"); }


mysqli_query($db,'DELETE FROM chat_online WHERE last_time<'.$time);


$chat_hash='';
$chat_who_online='';
$chat_online=0;


$cchatq=mysqli_query($db,"SELECT * FROM chat_online ORDER BY id ASC");
while($cchatm=mysqli_fetch_assoc($cchatq)){
if(!in_array($cchatm['uid'],$chat_hide_uid)){ $chat_online++; }
$chat_hash.=$cchatm['uid'].$cchatm['status'].$cchatm['words'].$cchatm['avatar'].$chat_online;
if($mydm['chat_am']=='' && in_array($cchatm['uid'],$chat_hide_uid)){ continue; }
$chat_who_online.='<table class="chat_o_t" cellpadding="0px" cellspacing="0px">
<tr>
<td class="chat_o_img">';
if($u_id!=$cchatm['uid']){
$chat_who_online.='<div class="chat_o_bell" onclick="chat_common(\''.$cchatm['uid'].'\',\'bell\');"></div>';
}
if($mydm['chat_am']!=''){
$chat_who_online.='<div class="chat_o_options">';
if($mydm['chat_am']=='a'){
$chat_who_online.='<span class="chat_o_set_moder" title="��������� / ����� ����������" onclick="chat_common(\''.$cchatm['uid'].'\',\'moder\');"></span>';
}
$chat_who_online.='<span class="chat_o_noban" title="���������" onclick="chat_common(\''.$cchatm['uid'].'\',\'noban\');"></span><span title="���" onclick="chat_common(\''.$cchatm['uid'].'\',3600);" class="chat_o_ban_t">���</span><span title="���" onclick="chat_common(\''.$cchatm['uid'].'\',86400);" class="chat_o_ban_t">���</span><span title="���" onclick="chat_common(\''.$cchatm['uid'].'\',2592000);" class="chat_o_ban_t">���</span>';
$chat_who_online.='</div>';
}


if($cchatm['status']=='a'){ $chat_who_online.='<div class="chat_o_admin"></div>'; }
if($cchatm['status']=='m'){ $chat_who_online.='<div class="chat_o_moder"></div>'; }


$chat_who_online.='<img src="'.$cchatm['avatar'].'"></td>
<td class="chat_o_who">';
$chat_o_login='<div>'.$cchatm['login'].'</div>';
foreach($chat_color_uid as $i=>$v){
if($i==$cchatm['uid']){
$chat_o_login='<div style="color:'.$v.'">'.$cchatm['login'].'</div>';
break;
}
}
$chat_who_online.=$chat_o_login;
if($chat_game==1){ $chat_who_online.='<span>'.$cchatm['words'].'</span>'; }
$chat_who_online.='</td>
</tr>
</table>';
}


$_SESSION['chat_hash']=md5($chat_hash);


$tux1=array(2,3,4,22,23,24,32,33,34,42,43,44,52,53,54,62,63,64,72,73,74,82,83,84,92,93,94);
$tux2=array(1,21,31,41,51,61,71,81,91);
$tuu=substr($chat_online,-2);
$tut='�������';
if(in_array($tuu,$tux1)){ $tut='��������'; }
elseif(in_array($tuu,$tux2)){ $tut='�������'; }


if($d['chat_online']!=$chat_online){
mysqli_query($db,"UPDATE data SET chat_online='$chat_online',chat_opt='$time' LIMIT 1") or die('cant update chat_online');
}


echo '<table align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td>


<div class="chat_desc">


<div class="chat_notice">
� ���� �������� ���, ��������, ������ �� ����� � ����������.
</div>';


if($chat_game==1){


echo '<div class="chat_game_info">
����������: <span id="chat_r">'.$mydm['chat_r'].'</span> ���. �������� �����: <span id="chat_words">'.$mydm['chat_words'].'</span> �� ������: <span id="chat_words_w">'.$mydm['chat_words_w'].'</span>
</div>';


}


echo '</div>';


echo '<table class="chat_top" cellpadding="0px" cellspacing="0px">
<tr>
<td class="chat_top_left">';
if($chat_game==1){ echo '<div class="chat_title">��������� ����� �� ����: <font id="erudit_word">'.$_SESSION['erudit_m'].'</font></div>'; }
else{ echo '<div class="chat_title">����� ���������� � ��� ���</div>'; }
echo '</td>
<td class="chat_online">������: <span id="chat_count_online">'.$chat_online.' '.$tut.'</span></td>
</tr>
</table>


<table class="chat_table" cellpadding="0px" cellspacing="0px">
<tr>
<td>


<div id="chat_banned_message" class="chat_banned_message" style="display:none;"></div>
<div id="chat_not_my_win" class="chat_not_my_win" style="display:none;"></div>
<div id="chat_my_win" class="chat_my_win" style="display:none;"></div>


<div id="chat_rate_div" class="chat_rate_div" style="display:none;">
<table class="chat_rate_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td><div class="chat_rate_title_1">������� �� �Ѩ �����</div></td>
<td><div class="chat_rate_title_2">������� �� ��� ������</div></td>
<td><div class="chat_rate_title_3">������� �� ������� ������</div></td>
</tr>
<tr>
<td><div id="chat_rate_total">&nbsp;</div></td>
<td><div id="chat_rate_week">&nbsp;</div></td>
<td>'.$d['chat_last_week'].'</td>
</tr>
</table>
</div>


<div id="chat_div_smiles" class="chat_div_smiles" style="display:none;">
<table class="chat_tab_smiles" align="center" cellspacing="1" cellpadding="2">';
$j=0;
for($n=0;$n<sizeof($chat_smiles);$n++){
$j++;
if($j==1){ echo '<tr>'; }
echo '<td onclick="chat_smile(\''.$chat_smiles[$n].'\');"><img src="/images/smiles/'.$chat_smiles[$n].'.gif"></td>';
if($j==6 || $n==sizeof($chat_smiles)){ echo '</tr>'; }
if($j==6){ $j=0; }
}
echo '</table>
</div>


<table id="chat_big_photo" onclick="this.style.display=\'none\';" class="chat_big_photo" cellpadding="0px" cellspacing="0px" style="display:none;">
<tr><td id="chat_big_photo_td">&nbsp;</td></tr>
</table>


<div id="chat_message_cont" class="chat_messages" onmouseover="message_stop_scroll=1;" onmouseout="message_stop_scroll=0;">';


$chat_last=0;


$s_q=mysqli_query($db,"SELECT * FROM chat_message ORDER BY id ASC");
while($s_m=mysqli_fetch_assoc($s_q)){
$chat_last=$s_m['id'];
if($s_m['type']=='' || ($s_m['type']=='ls' && ($s_m['to_uid']==$u_id || $s_m['uid']==$u_id))){
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<table id="chat_m_'.$s_m['id'].'" class="chat_m_t" cellpadding="0px" cellspacing="0px"><tr>';
if($u_id==$admin_uid){
echo '<td class="chat_m_img" rowspan="2"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>';
}
else{
echo '<td class="chat_m_img" rowspan="2"><img src="'.$s_m['avatar'].'"></td>';
}
echo '<td class="chat_m_who"><font onclick="chat_to(\'<b>'.$s_m['login'].'</b>\');">'.$s_m['login'].'</font>';
if($s_m['type']=='' && $s_m['uid']!=$u_id){
echo '<span onclick="tlsto(\''.$s_m['uid'].'\');" class="chat_m_who_ls">������</span>';
}
if($s_m['type']=='ls' && $s_m['to_uid']==$u_id){
echo '<span onclick="tlsto(\''.$s_m['uid'].'\');" class="chat_m_who_ls_u">��������</span>';
}
if($s_m['type']=='ls' && $s_m['uid']==$u_id){
echo '<span class="chat_m_who_ls_a">������</span>';
}
echo '</td>
<td class="chat_m_options">';
if($mydm['chat_am']!=''){
if($mydm['chat_am']=='a'){
echo '<span class="chat_m_set_moder" title="��������� / ����� ����������" onclick="chat_common(\''.$s_m['uid'].'\',\'moder\');"></span>';
}
echo '<span class="chat_m_noban" title="���������" onclick="chat_common(\''.$s_m['uid'].'\',\'noban\');"></span>';
echo '<span title="���" onclick="chat_common(\''.$s_m['uid'].'\',3600);" class="chat_m_ban_t">���</span>';
echo '<span title="���" onclick="chat_common(\''.$s_m['uid'].'\',86400);" class="chat_m_ban_t">���</span>';
echo '<span title="���" onclick="chat_common(\''.$s_m['uid'].'\',2592000);" class="chat_m_ban_t">���</span>';
echo '<span onclick="chat_common('.$s_m['id'].',\'del\');" class="chat_m_del"></span>';
}
if($mydm['chat_am']=='' && $s_m['uid']==$u_id){
echo '<span onclick="chat_common('.$s_m['id'].',\'del\');" class="chat_m_del"></span>';
}
$s_m['message']=str_replace('<img src="/images/smiles','<img class="chat_m_s" src="/images/smiles',$s_m['message']);
echo '</td>
<td class="chat_m_date" title="'.date('d.m.Y',$s_m['date']).'">'.date('H:i:s',$s_m['date']).'</td>
</tr><tr><td colspan="3" class="chat_m">'.$s_m['message'].'</td></tr></table>';
}
if($s_m['type']=='ban' || $s_m['type']=='noban' || $s_m['type']=='moder'){
echo '<table id="chat_m_'.$s_m['id'].'" class="chat_m_t" cellpadding="0px" cellspacing="0px">
<tr><td class="chat_m_common">'.$s_m['message'].'</td>
<td class="chat_m_common_del">';
if($mydm['chat_am']!=''){
echo '<span onclick="chat_common('.$s_m['id'].',\'del\');" class="chat_m_del"></span>';
}
echo '</td>
<td class="chat_m_date" title="'.date('d.m.Y',$s_m['date']).'">'.date('H:i:s',$s_m['date']).'</td></tr></table>';
}
}


$_SESSION['chat_last']=$chat_last;


echo '
</div>
</td>
<td valign="top"><div id="chat_who_online" class="chat_who_online">'.$chat_who_online.'</div></td>
</tr>
</table>


<table class="chat_bottom" cellpadding="0px" cellspacing="0px">
<tr>
<td class="chat_avatar"><img src="'.$mydm['avatar'].'"></td>
<td class="chat_text_td" valign="top">
<div id="chat_text" class="chat_text" contenteditable="true" oninput="if(this.innerHTML.length>'.$chat_message_c.'){ this.innerHTML=this.innerHTML.replace(/\<span[^\>]*\>/g,\'\').replace(/\<\/span\>/g,\'\'); this.innerHTML=this.innerHTML.substring(0,'.($chat_message_c-10).'); placeCaretAtEnd(); } if(event.keyCode==13){ message_send(); }"></div>
</td>
<td class="chat_app">
<span class="chat_smile" onclick="chat_smiles_show();"></span>';


if($chat_game==1){ echo '&nbsp;&nbsp;&nbsp; <span class="chat_rate_button" onclick="chat_rate();">�������</span>'; }


if($u_id==$admin_uid){ $chat_photo_c=10; $chat_photo_show=1; }


if($u_id!=$admin_uid && !empty($chat_photo_m)){
$chat_photo_show=1;
$chat_photo_onclick='';
if(floor(($time-$mydm['date'])/86400)<$chat_photo_d){
$chat_photo_onclick="��������� ���� ����� ��� ����������������� �� $chat_photo_d � ����� ���� �����.\r\n�������� ��� ����: ".($chat_photo_d-floor(($time-$mydm['date'])/86400))."\r\n";
}
if($chat_photo_m>=1 && $mydm['up_m']<$chat_photo_m){
$chat_photo_onclick.="��������� ���� ����� ��� �������� � �������� �� ����� $chat_photo_m ���.\r\n�������� ��������� ��: ".($chat_photo_m-$mydm['up_m'])." ���.";
}
}


if($chat_photo_show==1){
if(empty($chat_photo_onclick)){
echo '<br>
<span class="chat_photo">
<div id="chat_photo_progress" style="display:none;"></div>
<input id="chat_photo_upload" name="photo[]" onChange="chat_photo_ajax_send();" value="" type="file" multiple="true" accept=".jpg,.png,.gif">
</span>
<script type="text/javascript">var chat_photo_c='.$chat_photo_c.';</script>';
}
else{
echo '<br><span class="chat_photo" onclick="alert(`'.$chat_photo_onclick.'`);"></span>';
}
}


echo '</td>
</tr>
<tr>
<td>&nbsp;</td>
<td><span class="chat_send" onclick="message_send();">���������</span>
<span id="chat_ls_span" onclick="chat_lsto=\'\';this.style.display=\'none\';" class="chat_nols" style="display:none">�������� ������</span>
</td>
</tr>
</table>


</td>
</tr>
</table>


<br>
<br>


<script type="text/javascript" src="/chat/chat.js"></script>
<script type="text/javascript">var message_max='.$chat_message_h.';</script>


<audio id="chat_sound_message" preload>
<source src="/chat/sound/message.mp3" type="audio/mpeg">
</audio>


<audio id="chat_sound_bell" preload>
<source src="/chat/sound/bell.mp3" type="audio/mpeg">
</audio>


<audio id="chat_sound_delete" preload>
<source src="/chat/sound/delete.mp3" type="audio/mpeg">
</audio>


<audio id="chat_sound_banned" preload>
<source src="/chat/sound/banned.mp3" type="audio/mpeg">
</audio>


<audio id="chat_sound_erudit" preload>
<source src="/chat/sound/erudit.mp3" type="audio/mpeg">
</audio>';


?>
