<?php


require_once('../config.php');


if(empty($u_id)){ exit; }


// ____________________ ��� ���� ____________________


if($chat_game==1){


$table=array(
'�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�',
'�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�',
'�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�','�'=>'�'
);


}


// ____________________ ������ �� ������ ��������� ____________________


if(!empty($_POST['message']) || !empty($_POST['rate']) || !empty($_POST['ban']) || !empty($_POST['noban']) || !empty($_POST['moder']) || !empty($_POST['delete']) || !empty($_POST['bell'])){
if(!empty($_SESSION['chat_mt']) && $_SESSION['chat_mt']>$time-2){ exit; }
$_SESSION['chat_mt']=$time;
}


// ____________________ ������ ��������� ������ ____________________


if($chat_game==1 && isset($_SESSION['chat_eweek']) && $_SESSION['chat_eweek']<$time){
echo 'location.href=location.href;';
exit;
}


// ____________________ ����� �������� ____________________


if(!empty($_POST['rate'])){
$n=0;
$chat_total_words='';
$s_q=mysqli_query($db,"SELECT login,chat_words,uid,avatar FROM users ORDER BY chat_words DESC LIMIT 10");
while($s_m=mysqli_fetch_assoc($s_q)){
$n++;
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$chat_total_words.='<table class="chat_rate_list_table" cellpadding="0px" cellspacing="0px">';
$chat_total_words.='<tr><td class="chat_rate_num"><div>'.$n.'</div></td>';
$chat_total_words.='<td class="chat_rate_avatar"><img src="'.$s_m['avatar'].'"></td>';
if($u_id==$admin_uid){
$chat_total_words.='<td class="chat_rate_user"><a target="_blank" href="/profile/'.$profile_link.'"><div>'.$s_m['login'].'</div></a></td>';
}
else{
$chat_total_words.='<td class="chat_rate_user"><div>'.$s_m['login'].'</div></td>';
}
$chat_total_words.='<td class="chat_rate_words"><div>'.$s_m['chat_words'].'</div></td></tr>';
$chat_total_words.='</table>';
}


$n=0;
$chat_this_week='';


$s_q=mysqli_query($db,"SELECT login,chat_words_w,uid,avatar FROM users ORDER BY chat_words_w DESC LIMIT 10");
while($s_m=mysqli_fetch_assoc($s_q)){
$n++;
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$chat_this_week.='<table class="chat_rate_list_table" cellpadding="0px" cellspacing="0px">';
$chat_this_week.='<tr><td class="chat_rate_num"><div>'.$n.'</div></td>';
$chat_this_week.='<td class="chat_rate_avatar"><img src="'.$s_m['avatar'].'"></td>';
if($u_id==$admin_uid){
$chat_this_week.='<td class="chat_rate_user"><a target="_blank" href="/profile/'.$profile_link.'"><div>'.$s_m['login'].'</div></a></td>';
}
else{
$chat_this_week.='<td class="chat_rate_user"><div>'.$s_m['login'].'</div></td>';
}
$chat_this_week.='<td class="chat_rate_words"><div>'.$s_m['chat_words_w'].'</div></td></tr>';
$chat_this_week.='</table>';
}


echo 'document.getElementById("chat_rate_div").style.display="block";';
echo 'document.getElementById("chat_rate_total").innerHTML=\''.$chat_total_words.'\';';
echo 'document.getElementById("chat_rate_week").innerHTML=\''.$chat_this_week.'\';';


exit;
}


// ____________________ �������� �� ������������ ____________________


$iam_banned=0;


if($mydm['chat_ban']>$time){ $iam_banned=1; }


// ____________________ ������� �������� �� ������� ____________________


if($iam_banned==1 && empty($_POST['online'])){
$dt=$mydm['chat_ban']-$time;
$dd=(int)($dt/86400); $hh=(int)(($dt-$dd*86400)/3600); $mm=(int)(($dt-$dd*86400-$hh*3600)/60); $ss=(int)($dt-$dd*86400-$hh*3600-$mm*60);
$dd.='� '; $hh.='� '; $mm.='� '; $ss.='�';
if($dd=='0� '){ $dd=''; } if($dd=='' && $hh=='0� '){ $hh=''; } if($dd=='' && $hh=='' && $mm=='0� '){ $mm=''; }
echo 'chat_banned_message("��� ��� ���������� �����: '.$dd.$hh.$mm.$ss.'");';
}


// ____________________ ������ ������, ���� �� ������ ��� � ����������� ____________________


if($u_id!=$admin_uid && !empty($_POST['message']) && floor(($time-$mydm['date'])/86400)<$chat_message_d){
$iam_banned=1;
$_POST['message']='';
echo 'alert("������ ����� ��� ����������������� �� '.$chat_message_d.' � ����� ���� �����.\r\n�������� ��� ����: '.($chat_message_d-floor(($time-$mydm['date'])/86400)).'");';
}


// ____________________ ������ ������, ���� �� �������� ____________________


if($u_id!=$admin_uid && !empty($_POST['message']) && $mydm['up_m']<$chat_message_up_m){
$iam_banned=1;
$_POST['message']='';
echo 'alert("������ ����� ��� �������� � �������� �� ����� '.$chat_message_up_m.' ���.\r\n�������� ��������� ��: '.($chat_message_up_m-$mydm['up_m']).' ���.");';
}


// ____________________ ����������� ____________________


if($iam_banned!=1 && !empty($_POST['ban']) && !empty($_POST['ban_time']) && ($mydm['chat_am']=='a' || $mydm['chat_am']=='m')){


$act_ban_time=preg_replace('#[^0-9]+#','',$_POST['ban_time']);
$act_ban_time=number_format($act_ban_time,0,'','');
if(empty($act_ban_time) || !is_numeric($act_ban_time) || strlen($act_ban_time)>10 || ($act_ban_time!=3600 && $act_ban_time!=86400 && $act_ban_time!=2592000)){ exit; }


$act_ban_uid=preg_replace("#[^0-9]+#",'',$_POST['ban']);
$act_ban_uid=number_format($act_ban_uid,0,'','');
if(empty($act_ban_uid) || !is_numeric($act_ban_uid) || strlen($act_ban_uid)>11 || $u_id==$act_ban_uid){ exit; }


$s_q=mysqli_query($db,"SELECT login,chat_am FROM users WHERE uid='$act_ban_uid' LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(empty($s_m['login']) || !isset($s_m['chat_am'])){ exit; }


if(($mydm['chat_am']=='a' && $s_m['chat_am']!='a') || ($mydm['chat_am']=='m' && $s_m['chat_am']=='')){
$act_ban_time+=$time;
mysqli_query($db,"UPDATE users SET chat_ban='$act_ban_time' WHERE uid='$act_ban_uid' LIMIT 1");
$act_ban_message='<font class="chat_m_banned">'.$s_m['login'].'<br>��� �� '.date('d.m.y H:i:s',$act_ban_time).'</font>';
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','ban','$act_ban_message')");
}
}


// ____________________ ������������ ____________________


if($iam_banned!=1 && !empty($_POST['noban']) && ($mydm['chat_am']=='a' || $mydm['chat_am']=='m')){


$act_no_ban_uid=preg_replace("#[^0-9]+#",'',$_POST['noban']);
$act_no_ban_uid=number_format($act_no_ban_uid,0,'','');
if(empty($act_no_ban_uid) || !is_numeric($act_no_ban_uid) || strlen($act_no_ban_uid)>11 || $u_id==$act_no_ban_uid){ exit; }


$s_q=mysqli_query($db,"SELECT login,chat_am,chat_ban FROM users WHERE uid='$act_no_ban_uid' LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(empty($s_m['login']) || !isset($s_m['chat_am'])){ exit; }


if($s_m['chat_ban']<$time){ exit; }


if(($mydm['chat_am']=='a' && $s_m['chat_am']!='a') || ($mydm['chat_am']=='m' && $s_m['chat_am']=='')){
mysqli_query($db,"UPDATE users SET chat_ban=0 WHERE uid='$act_no_ban_uid' LIMIT 1");
$act_no_ban_message='<font class="chat_m_nobanned">'.$s_m['login'].'<br>��� ����</font>';
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','noban','$act_no_ban_message')");
}
}


// ____________________ ������������� ____________________


if($iam_banned!=1 && !empty($_POST['moder']) && $mydm['chat_am']=='a'){


$act_moder_uid=preg_replace("#[^0-9]+#",'',$_POST['moder']);
$act_moder_uid=number_format($act_moder_uid,0,'','');
if(empty($act_moder_uid) || !is_numeric($act_moder_uid) || strlen($act_moder_uid)>10){ exit; }


$s_q=mysqli_query($db,"SELECT login,chat_am FROM users WHERE uid='$act_moder_uid' LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(empty($s_m['login']) || !isset($s_m['chat_am'])){ exit; }


if($s_m['chat_am']=='a'){ exit; }


if($s_m['chat_am']==''){
mysqli_query($db,"UPDATE users SET chat_am='m' WHERE uid='$act_moder_uid' LIMIT 1");
mysqli_query($db,"UPDATE chat_online SET status='m' WHERE uid='$act_moder_uid' LIMIT 1");
$act_moder_message='<font class="chat_m_ismoder">'.$s_m['login'].'<br>��������� ����������</font>';
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,to_uid,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','moder','$act_moder_uid','$act_moder_message')");
}
if($s_m['chat_am']=='m'){
mysqli_query($db,"UPDATE users SET chat_am='' WHERE uid='$act_moder_uid' LIMIT 1");
mysqli_query($db,"UPDATE chat_online SET status='' WHERE ui='$act_moder_uid' LIMIT 1");
$act_moder_message='<font class="chat_m_isnomoder">'.$s_m['login'].'<br>������ � ��������� ����������</font>';
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,to_uid,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','moder','$act_moder_uid','$act_moder_message')");
}
}


// ____________________ �������� ��������� ____________________


if($iam_banned!=1 && !empty($_POST['d_id'])){


$act_d_id=preg_replace('#[^0-9]+#','',$_POST['d_id']);
$act_d_id=number_format($act_d_id,0,'','');


if(empty($act_d_id) || !is_numeric($act_d_id) || strlen($act_d_id)>10){ exit; }


if($mydm['chat_am']=='a' || $mydm['chat_am']=='m'){
mysqli_query($db,'DELETE FROM chat_message WHERE id='.$act_d_id.' LIMIT 1');
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','del','$act_d_id')");
}


if($mydm['chat_am']==''){
$s_q=mysqli_query($db,"SELECT id FROM chat_message WHERE id='$act_d_id' AND uid='".$mydm['uid']."' LIMIT 1");
$s_m=mysqli_fetch_row($s_q);
if(!empty($s_m[0])){
mysqli_query($db,'DELETE FROM chat_message WHERE id='.$act_d_id.' LIMIT 1');
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','del','$act_d_id')");
}
}
}


// ____________________ ��������� ____________________


if($iam_banned!=1 && !empty($_POST['bell'])){


$act_bell_to_uid=preg_replace("#[^0-9]+#",'',$_POST['bell']);
$act_bell_to_uid=number_format($act_bell_to_uid,0,'','');
if(empty($act_bell_to_uid) || !is_numeric($act_bell_to_uid) || strlen($act_bell_to_uid)>10){ exit; }


if($u_id==$act_bell_to_uid){ exit; }


$s_q=mysqli_query($db,"SELECT login FROM users WHERE uid='$act_bell_to_uid' LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(empty($s_m['login'])){ exit; }


$act_bell_to_message='<font class="chat_m_mybell">�� ��������� '.$s_m['login'].'</font>';
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,to_uid,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','bell','$act_bell_to_uid','$act_bell_to_message')");
}


// ____________________ ������ ��������� ____________________


if($iam_banned!=1 && !empty($_POST['message'])){


$message=$_POST['message'];
$message=mb_convert_encoding($message,'HTML-ENTITIES','UTF-8');
$message=iconv('utf-8','windows-1251//IGNORE',$message);


$m_decode=array(
'&#1072;'=>'�','&#1073;'=>'�','&#1074;'=>'�','&#1075;'=>'�','&#1076;'=>'�','&#1077;'=>'�','&#1105;'=>'�','&#1078;'=>'�','&#1079;'=>'�','&#1080;'=>'�','&#1081;'=>'�',
'&#1082;'=>'�','&#1083;'=>'�','&#1084;'=>'�','&#1085;'=>'�','&#1086;'=>'�','&#1087;'=>'�','&#1088;'=>'�','&#1089;'=>'�','&#1090;'=>'�','&#1091;'=>'�','&#1092;'=>'�',
'&#1093;'=>'�','&#1094;'=>'�','&#1095;'=>'�','&#1096;'=>'�','&#1097;'=>'�','&#1098;'=>'�','&#1099;'=>'�','&#1100;'=>'�','&#1101;'=>'�','&#1102;'=>'�','&#1103;'=>'�',
'&#1110;'=>'�','&#1111;'=>'�','&#1108;'=>'�','&#1169;'=>'�',
'&#1040;'=>'�','&#1041;'=>'�','&#1042;'=>'�','&#1043;'=>'�','&#1044;'=>'�','&#1045;'=>'�','&#1025;'=>'�','&#1046;'=>'�','&#1047;'=>'�','&#1048;'=>'�','&#1049;'=>'�',
'&#1050;'=>'�','&#1051;'=>'�','&#1052;'=>'�','&#1053;'=>'�','&#1054;'=>'�','&#1055;'=>'�','&#1056;'=>'�','&#1057;'=>'�','&#1058;'=>'�','&#1059;'=>'�','&#1060;'=>'�',
'&#1061;'=>'�','&#1062;'=>'�','&#1063;'=>'�','&#1064;'=>'�','&#1065;'=>'�','&#1066;'=>'�','&#1067;'=>'�','&#1068;'=>'�','&#1069;'=>'�','&#1070;'=>'�','&#1071;'=>'�',
'&#1031;'=>'�','&#1030;'=>'�','&#1028;'=>'�','&#1168;'=>'�'
);


$message=str_replace(array_keys($m_decode),array_values($m_decode),$message);
$message=preg_replace('#(\ *)?/(\ *)?\>#mi','>',$message);
$message=preg_replace('#\<div([^>]*)>#mi','<br>',$message);
$message=str_replace('<div><br>','<div>',$message);
$message=str_replace('<div>','<br>',$message);
$message=str_replace('</div>','<br>',$message);
$message=str_replace('<p>','<br>',$message);
$message=str_replace('</p>','<br>',$message);
$message=str_replace(array('`',"'",'�','�'),'&apos;',$message);
$message=str_replace(array('�','�','�','�'),'&quot;',$message);
$message=str_replace("\t",' ',$message);
$message=str_replace('&nbsp;',' ',$message);
$message=str_replace('^backslash^','&#92;',$message);
$message=str_replace('\\','&#92;',$message);


$message=preg_replace('#\<img class="chat_m_s" src="/images/smiles/([0-9a-zA-Z\.\_\-]{5,20})"[ /]{0,3}>#mi','#@#img1\1#imgend',$message);


$chat_photo_cant=0;
if($u_id!=$admin_uid){
if($chat_photo_m==0){ $chat_photo_cant=1; }
if(floor(($time-$mydm['date'])/86400)<$chat_photo_d){ $chat_photo_cant=1; }
if($chat_photo_m>=1 && $mydm['up_m']<$chat_photo_m){ $chat_photo_cant=1; }
}


if($chat_photo_cant==0){
// ����������� ���� �� ��������� ����������
$message=preg_replace('#\<img src="/chat/photo/([0-9]{10}\_[0-9]{1,10}\_[0-9]{1,10}\.[a-z]{3})"[ /]{0,3}>#mi','#@#img2\1#imgend',$message);
// ����������� ���� �����������
$message=preg_replace('#\<img class="chat_m_photo_m" src="/chat/photo/([0-9]{10}\_[0-9]{1,10}\_[0-9]{1,10}\_m\.[a-z]{3})"[ /]{0,3}>#mi','#@#img3\1#imgend',$message);
// ���� � ������ ������
$message=preg_replace('#\<img(((?!src).)+)src="https([0-9a-zA-Z�������������������������������������Ũ��������������������������\.\#\?\/\:\=\-\_\&\~]*)"[^>]*>#mi','#@#img4\3#imgend',$message);
$message=preg_replace('#\<img(((?!src).)+)src="http([0-9a-zA-Z�������������������������������������Ũ��������������������������\.\#\?\/\:\=\-\_\&\~]*)"[^>]*>#mi','#@#img5\3#imgend',$message);
}


// ���������� ������
$message=preg_replace('#(https?)#msi',' \1',$message);


$message=str_replace('<br>','#@#br',$message);
$message=str_replace('<br />','#@#br',$message);
$message=str_replace('<b>','#@#bb1',$message);
$message=str_replace('</b>','#@#bb2',$message);


// ��������� �����
$message=preg_replace('#\<[^>$]*(>|$)#mi',' ',$message);


$message=str_replace('<','&lt;',$message);
$message=str_replace('>','&gt;',$message);
$message=str_replace("\r",'',$message);
$message=str_replace("\n",'#@#br',$message);


// �������� ������ ������� �������
$message=str_replace('"','&quot;',$message);


$message=preg_replace('#[^0-9\ \/\_\.\,\:\;\|\~\?\!\-\+\=\*\^\%\#\$\&\@\�\(\)\{\}\[\]a-zA-Z�����������������������������������������Ũ�������������������������߯���]+#mi','',$message);


$message=str_replace('#@#br','<br>',$message);


$message=str_replace('#@#bb1','<b>',$message);
$message=str_replace('#@#bb2','</b>',$message);


// �������� �������������� ����
$message=preg_replace('#\<img[^>$]*(>|$)#mi','',$message);


// ���� �� ������
$message=preg_replace('#https(\:\/\/\S+\.\S+\.(jpg|gif|png|jpeg|bmp))[^\ \<\>\"\\\']*#msi','#@#img4\1#imgend',$message);
$message=preg_replace('#http(\:\/\/\S+\.\S+\.(jpg|gif|png|jpeg|bmp))[^\ \<\>\"\\\']*#msi','#@#img5\1#imgend',$message);


// ������� ������
if($u_id!=$admin_uid){
if($chat_simple_link==0){ $message=preg_replace('#(https?)\:\/\/[^\ \<\,]*#mi','',$message); }
if($chat_simple_link==2){ $message=preg_replace('#(https?)\:\/\/[^\ \<\,]*#mi','<a target="_blank" class="chat_m_link" href="\0">\0</a>',$message); }
}
else{
$message=preg_replace('#(https?)\:\/\/[^\ \<\,]*#mi','<a target="_blank" class="chat_m_link" href="\0">\0</a>',$message);
}


// FTP ������
$message=preg_replace('#(ftp):\/\/[^\ <]*#mi','',$message);


$message=preg_replace('#\#\@\#img1(((?!\#imgend).)+)\#imgend#mi','<img src="/images/smiles/\1">',$message);
$message=preg_replace('#\#\@\#img2(((?!\#imgend).)+)\#imgend#mi','<img src="/chat/photo/\1">',$message);
$message=preg_replace('#\#\@\#img3(((?!\#imgend).)+)\#imgend#mi','<img onclick="chat_mtob(this);" class="chat_m_photo_m" src="/chat/photo/\1">',$message);


if($u_id!=$admin_uid){


if($chat_img_link==0){ $message=preg_replace('#\#\@\#img(4|5)(((?!\#imgend).)+)\#imgend#mi',' ',$message); }


if($chat_img_link==1){
$message=preg_replace('#\#\@\#img4(((?!\#imgend).)+)\#imgend#mi',' https\1 ',$message);
$message=preg_replace('#\#\@\#img5(((?!\#imgend).)+)\#imgend#mi',' http\1 ',$message);
}


if($chat_img_link==2){
$message=preg_replace('#\#\@\#img4(((?!\#imgend).)+)\#imgend#mi',' <a target="_blank" class="chat_m_link" href="https\1">https\1</a> ',$message);
$message=preg_replace('#\#\@\#img5(((?!\#imgend).)+)\#imgend#mi',' <a target="_blank" class="chat_m_link" href="http\1">http\1</a> ',$message);
}


if($chat_img_link==3){
$message=preg_replace('#\#\@\#img4(((?!\#imgend).)+)\#imgend#mi',' <img onclick="chat_mtob(this);" class="chat_m_photo_m" src="https\1"> ',$message);
$message=preg_replace('#\#\@\#img5(((?!\#imgend).)+)\#imgend#mi',' <img onclick="chat_mtob(this);" class="chat_m_photo_m" src="http\1"> ',$message);
}


if($chat_img_link==4){
$message=preg_replace('#\#\@\#img4(((?!\#imgend).)+)\#imgend#mi',' <a target="_blank" href="https\1"><img class="chat_m_photo_m" src="https\1"></a> ',$message);
$message=preg_replace('#\#\@\#img5(((?!\#imgend).)+)\#imgend#mi',' <a target="_blank" href="http\1"><img class="chat_m_photo_m" src="http\1"></a> ',$message);
}


}
else{
$message=preg_replace('#\#\@\#img4(((?!\#imgend).)+)\#imgend#mi',' <img onclick="chat_mtob(this);" class="chat_m_photo_m" src="https\1"> ',$message);
$message=preg_replace('#\#\@\#img5(((?!\#imgend).)+)\#imgend#mi',' <img onclick="chat_mtob(this);" class="chat_m_photo_m" src="http\1"> ',$message);
}


$message=preg_replace('#(\<br>)+#mi','<br>',$message);
$message=preg_replace('#^(\<br>)+#mi','',$message);
$message=preg_replace('#(\<br>)+$#mi','',$message);
$message=preg_replace('#^\ +#mi','',$message);
$message=preg_replace('#\ +$#mi','',$message);
$message=preg_replace('#\ +#mi',' ',$message);
$message=preg_replace('#&nbsp;#mi','',$message);


$message=trim($message);
$message=substr($message,0,$chat_message_c);


$message=preg_replace('#\<a(((?!a>).)+)$#mi','',$message);
$message=preg_replace('#\<b[^r](((?!b>).)+)$#mi','',$message);


// �������� �������� ����� ����� �������
$message=preg_replace('#\<[^>]*$#mi','',$message);


$t_type='';
$t_to_uid='';


if(!empty($_POST['lsto'])){
$t_to_uid_p=preg_replace("#[^0-9]+#",'',$_POST['lsto']);
$t_to_uid_p=number_format($t_to_uid_p,0,'','');
if(empty($t_to_uid_p) || !is_numeric($t_to_uid_p) || strlen($t_to_uid_p)>10){ exit; }
if($u_id!=$t_to_uid_p){ $t_to_uid=$t_to_uid_p; $t_type='ls'; }
}


// ____________________ ������ ____________________


if($chat_game==1 && strlen($message)>2 && strlen($message)<32 && $t_type==''){


$check_message=str_replace(array_values($table),array_keys($table),$message);
$check_message=str_replace('�','�',$check_message);
$check_message=strtolower($check_message);
$pre_erudit_w=str_replace(array_values($table),array_keys($table),$_SESSION['erudit_w']);
$pre_erudit_w=str_replace('�','�',$pre_erudit_w);
$pre_erudit_w=strtolower($pre_erudit_w);


if(!empty($_SESSION['erudit_w']) && $check_message==$pre_erudit_w){


$nomessage=1;
$mydm['chat_words']++;
$mydm['chat_words_w']++;
$mydm['chat_r']+=$chat_word_sum;
$mydm['chat_r']=number_format($mydm['chat_r'],4,'.','');
$mydm[$chat_game_path]+=$chat_word_sum;
$mydm[$chat_game_path]=number_format($mydm[$chat_game_path],4,'.','');
echo 'if(chat_sound==1){ document.getElementById("chat_sound_erudit").play(); }';
echo 'document.getElementById("my_'.$chat_game_path.'").innerHTML="'.$mydm[$chat_game_path].'";';
echo 'document.getElementById("chat_r").innerHTML="'.$mydm['chat_r'].'";';
echo 'document.getElementById("chat_words").innerHTML="'.$mydm['chat_words'].'";';
echo 'document.getElementById("chat_words_w").innerHTML="'.$mydm['chat_words_w'].'";';
echo 'document.getElementById("chat_my_win").innerHTML="<b></b>�� �������� �����: <span>'.$_SESSION['erudit_w'].'</span>";';
echo 'document.getElementById("chat_my_win").style.display="block";';
echo 'clearTimeout(chat_my_win);';
echo 'chat_my_win=setTimeout(\'document.getElementById("chat_my_win").style.display="none";\',4000);';


mysqli_query($db,"UPDATE users SET chat_words=chat_words+1,chat_words_w=chat_words_w+1,chat_r=(chat_r+$chat_word_sum),$chat_game_path=($chat_game_path+$chat_word_sum) WHERE uid='$u_id' LIMIT 1");
mysqli_query($db,"UPDATE data SET chat_r=(chat_r+$chat_word_sum) LIMIT 1");


mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,message) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','erudit','".$_SESSION['erudit_w']."')");
echo 'document.cookie="chat_message=;path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";';


$_SESSION['erudit_w']=''; // ������� �����, ����� ��������� ��������� �����


}
}


// ____________________ ������� ��������� ____________________


if(strlen($message)>0 && empty($nomessage)){
mysqli_query($db,"INSERT INTO chat_message (date,date_word,uid,login,type,to_uid,message,avatar) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$u_id','".$mydm['login']."','$t_type','$t_to_uid','$message','".$mydm['avatar']."')");
echo 'document.cookie="chat_message=;path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";';
}


}


// ____________________ ������ ����� ____________________


$imchat=mysqli_query($db,"SELECT last_time FROM chat_online WHERE uid='$u_id'");
if(mysqli_num_rows($imchat)>0){
mysqli_query($db,"UPDATE chat_online SET last_time='".($chat_last_time+$time)."',status='".$mydm['chat_am']."',words='".$mydm['chat_words']."' WHERE uid='$u_id' LIMIT 1");
}
else{ mysqli_query($db,"INSERT INTO chat_online (last_time,login,status,words,uid,avatar) VALUES ('".($chat_last_time+$time)."','".$mydm['login']."','".$mydm['chat_am']."','".$mydm['chat_words']."','$u_id','".$mydm['avatar']."')"); }
mysqli_query($db,'DELETE FROM chat_online WHERE last_time<'.$time);


$chat_hash='';
$chat_who_online='';
$chat_online=0;


$cchatq=mysqli_query($db,"SELECT * FROM chat_online ORDER BY id ASC");
while($cchatm=mysqli_fetch_assoc($cchatq)){
if(!in_array($cchatm['uid'],$chat_hide_uid)){ $chat_online++; }
$chat_hash.=$cchatm['uid'].$cchatm['status'].$cchatm['words'].$cchatm['avatar'].$chat_online;
if($mydm['chat_am']=='' && in_array($cchatm['uid'],$chat_hide_uid)){ continue; }
$chat_who_online.='<table class="chat_o_t" cellpadding="0px" cellspacing="0px">';
$chat_who_online.='<tr>';
$chat_who_online.='<td class="chat_o_img">';
if($u_id!=$cchatm['uid']){
$chat_who_online.='<div class="chat_o_bell" onclick="chat_common(\\\''.$cchatm['uid'].'\\\',\\\'bell\\\');"></div>';
}
if($mydm['chat_am']!=''){
$chat_who_online.='<div class="chat_o_options">';
if($mydm['chat_am']=='a'){
$chat_who_online.='<span class="chat_o_set_moder" title="��������� / ����� ����������" onclick="chat_common(\\\''.$cchatm['uid'].'\\\',\\\'moder\\\');"></span>';
}
$chat_who_online.='<span class="chat_o_noban" title="���������" onclick="chat_common(\\\''.$cchatm['uid'].'\\\',\\\'noban\\\');"></span><span title="���" onclick="chat_common(\\\''.$cchatm['uid'].'\\\',3600);" class="chat_o_ban_t">���</span><span title="���" onclick="chat_common(\\\''.$cchatm['uid'].'\\\',86400);" class="chat_o_ban_t">���</span><span title="���" onclick="chat_common(\\\''.$cchatm['uid'].'\\\',2592000);" class="chat_o_ban_t">���</span>';
$chat_who_online.='</div>';
}


if($cchatm['status']=='a'){ $chat_who_online.='<div class="chat_o_admin"></div>'; }
if($cchatm['status']=='m'){ $chat_who_online.='<div class="chat_o_moder"></div>'; }


$chat_who_online.='<img src="'.$cchatm['avatar'].'"></td>';
$chat_who_online.='<td class="chat_o_who">';
$chat_o_login='<div>'.$cchatm['login'].'</div>';
foreach($chat_color_uid as $i=>$v){
if($i==$cchatm['uid']){
$chat_o_login='<div style="color:'.$v.'">'.$cchatm['login'].'</div>';
break;
}
}
$chat_who_online.=$chat_o_login;
if($chat_game==1){ $chat_who_online.='<span>'.$cchatm['words'].'</span>'; }
$chat_who_online.='</td>';
$chat_who_online.='</tr>';
$chat_who_online.='</table>';
}


if(md5($chat_hash)!=$_SESSION['chat_hash']){
$tux1=array(2,3,4,22,23,24,32,33,34,42,43,44,52,53,54,62,63,64,72,73,74,82,83,84,92,93,94);
$tux2=array(1,21,31,41,51,61,71,81,91);
$tuu=substr($chat_online,-2);
$tut='�������';
if(in_array($tuu,$tux1)){ $tut='��������'; }
elseif(in_array($tuu,$tux2)){ $tut='�������'; }


echo 'document.getElementById("chat_count_online").innerHTML=\''.$chat_online.' '.$tut.'\';';
echo 'document.getElementById("chat_who_online").innerHTML=\''.$chat_who_online.'\';';


$_SESSION['chat_hash']=md5($chat_hash);
}


// ____________________ ��������� ____________________


if(empty($_SESSION['chat_last'])){ $chat_last=0; }
else{ $chat_last=$_SESSION['chat_last']; }


$chat_message='';


$s_q=mysqli_query($db,"SELECT * FROM chat_message WHERE id>'$chat_last' ORDER BY id ASC");
while($s_m=mysqli_fetch_assoc($s_q)){
$chat_last=$s_m['id'];
if($s_m['type']=='' || ($s_m['type']=='ls' && ($s_m['to_uid']==$u_id || $s_m['uid']==$u_id))){
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$chat_message.='<table id="chat_m_'.$s_m['id'].'" class="chat_m_t" cellpadding="0px" cellspacing="0px"><tr>';
if($u_id==$admin_uid){
$chat_message.='<td class="chat_m_img" rowspan="2"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>';
}
else{
$chat_message.='<td class="chat_m_img" rowspan="2"><img src="'.$s_m['avatar'].'"></td>';
}
$chat_message.='<td class="chat_m_who"><font onclick="chat_to(\\\'<b>'.$s_m['login'].'</b>\\\');">'.$s_m['login'].'</font>';
if($s_m['type']=='' && $s_m['uid']!=$u_id){
$chat_message.='<span onclick="tlsto(\\\''.$s_m['uid'].'\\\');" class="chat_m_who_ls">������</span>';
}
if($s_m['type']=='ls' && $s_m['to_uid']==$u_id){
$chat_message.='<span onclick="tlsto(\\\''.$s_m['uid'].'\\\');" class="chat_m_who_ls_u">��������</span>';
}
if($s_m['type']=='ls' && $s_m['uid']==$u_id){
$chat_message.='<span class="chat_m_who_ls_a">������</span>';
}
$chat_message.='</td>';
$chat_message.='<td class="chat_m_options">';
if($mydm['chat_am']!=''){
if($mydm['chat_am']=='a'){
$chat_message.='<span class="chat_m_set_moder" title="��������� / ����� ����������" onclick="chat_common(\\\''.$s_m['uid'].'\\\',\\\'moder\\\');"></span>';
}
$chat_message.='<span class="chat_m_noban" title="���������" onclick="chat_common(\\\''.$s_m['uid'].'\\\',\\\'noban\\\');"></span>';
$chat_message.='<span title="���" onclick="chat_common(\\\''.$s_m['uid'].'\\\',3600);" class="chat_m_ban_t">���</span>';
$chat_message.='<span title="���" onclick="chat_common(\\\''.$s_m['uid'].'\\\',86400);" class="chat_m_ban_t">���</span>';
$chat_message.='<span title="���" onclick="chat_common(\\\''.$s_m['uid'].'\\\',2592000);" class="chat_m_ban_t">���</span>';
$chat_message.='<span onclick="chat_common('.$s_m['id'].',\\\'del\\\');" class="chat_m_del"></span>';
}
if($mydm['chat_am']=='' && $s_m['uid']==$u_id){
$chat_message.='<span onclick="chat_common('.$s_m['id'].',\\\'del\\\');" class="chat_m_del"></span>';
}
$chat_message.='</td>';
$chat_message.='<td class="chat_m_date" title="'.date('d.m.Y',$s_m['date']).'">'.date('H:i:s',$s_m['date']).'</td>';
$s_m['message']=str_replace('<img src="/images/smiles','<img class="chat_m_s" src="/images/smiles',$s_m['message']);
$chat_message.='</tr><tr><td colspan="3" class="chat_m">'.$s_m['message'].'</td></tr></table>';
}
if($s_m['type']=='ban' || $s_m['type']=='noban' || $s_m['type']=='moder' || ($s_m['type']=='bell' && ($s_m['to_uid']==$u_id || $s_m['uid']==$u_id)) || $s_m['type']=='erudit'){


if($s_m['type']=='erudit' && $u_id!=$s_m['uid']){
echo 'document.getElementById("chat_not_my_win").innerHTML="<b></b>�����: <span>'.$s_m['message'].'</span> �������: <font>'.$s_m['login'].'</font>";';
echo 'document.getElementById("chat_not_my_win").style.display="block";';
echo 'clearTimeout(chat_not_my_win);';
echo 'chat_not_my_win=setTimeout(\'document.getElementById("chat_not_my_win").style.display="none";\',5000);';
}


if($s_m['type']=='erudit'){ continue; }


if($s_m['type']=='moder' && $s_m['to_uid']==$u_id){
echo 'location.reload();';
exit;
}


if($s_m['type']=='bell' && $s_m['to_uid']==$u_id){
echo 'chat_spec_bell();';
$s_m['message']='<font class="chat_m_tomebell">��������� �� '.$s_m['login'].'</font>';
$nomessage=1;
}


if($s_m['type']=='bell' && $s_m['uid']==$u_id){
echo 'chat_spec_bell();';
$nomessage=1;
}


$chat_message.='<table id="chat_m_'.$s_m['id'].'" class="chat_m_t" cellpadding="0px" cellspacing="0px">';
$chat_message.='<tr><td class="chat_m_common">'.$s_m['message'].'</td><td class="chat_m_common_del">';
if($mydm['chat_am']!='' && $s_m['type']!='erudit'){
$chat_message.='<span onclick="chat_common('.$s_m['id'].',\\\'del\\\');" class="chat_m_del"></span>';
}
$chat_message.='</td><td class="chat_m_date" title="'.date('d.m.Y',$s_m['date']).'">'.date('H:i:s',$s_m['date']).'</td></tr></table>';
}
if($s_m['type']=='del'){
echo 'chat_mdn('.$s_m['message'].');';
}
}


if(!empty($chat_message)){
echo 'document.getElementById("chat_message_cont").insertAdjacentHTML("beforeEnd",\''.$chat_message.'\');';
if(empty($nomessage)){
echo 'if(chat_sound==1){ document.getElementById("chat_sound_message").play(); }';
}
}


if($chat_last!=$_SESSION['chat_last']){
$_SESSION['chat_last']=$chat_last;
}


// ____________________ ��������� ����� ____________________


if($chat_game==1){


if(empty($_SESSION['erudit_w']) || empty($_SESSION['erudit_t']) || empty($_SESSION['erudit_m'])){
$s_q=mysqli_query($db,"SELECT word FROM chat_erudit JOIN (SELECT RAND()*(SELECT MAX(id) FROM chat_erudit) AS max_id) AS m WHERE id>=m.max_id ORDER BY id ASC LIMIT 1;");
$s_m=$s_q!==false ? mysqli_fetch_assoc($s_q) : array();
$word=isset($s_m['word']) ? str_replace(array_values($table),array_keys($table),trim($s_m['word'])) : '';
$word=strtolower($word);
$valid_word=preg_match('#^[�-��]{3,30}$#',$word) && count(array_unique(str_split($word)))>1;
if(!$valid_word){
    $word_pool=@file(__DIR__.'/slova.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if(!is_array($word_pool)){ $word_pool=array(); }
    $valid_words=array();
    foreach($word_pool as $candidate){
        $candidate=strtolower(str_replace(array_values($table),array_keys($table),trim($candidate)));
        if(preg_match('#^[�-��]{3,30}$#',$candidate) && count(array_unique(str_split($candidate)))>1){ $valid_words[]=$candidate; }
    }
    if(empty($valid_words)){ $valid_words=array('�����','������','����','�����','����','����','�����','������'); }
    $word=$valid_words[array_rand($valid_words)];
}
$s_m['word']=$word;

$chat_erudit_m=str_split($s_m['word']);
shuffle($chat_erudit_m);
if(implode('', $chat_erudit_m)===$s_m['word']){
    $chat_erudit_m=array_merge(array_slice($chat_erudit_m,1),array_slice($chat_erudit_m,0,1));
}

$_SESSION['erudit_w']=$s_m['word'];
$_SESSION['erudit_m']=implode($chat_erudit_m);
$_SESSION['erudit_t']=$time;
}


if(empty($_SESSION['erudit_w']) || strlen($_SESSION['erudit_w'])<3 || strlen($_SESSION['erudit_w'])>30){ echo 'alert("����� ������ �������� �� 3 - 30 ����. �����: '.$_SESSION['erudit_w'].'");'; exit; }
if(empty($_SESSION['erudit_t'])){ echo 'alert("������! ����� ��� ����� �� �������");'; exit; }
if(empty($_SESSION['erudit_m']) || strlen($_SESSION['erudit_m'])<3 || strlen($_SESSION['erudit_m'])>30){ echo 'alert("���� ����� ������ �������� �� 3 - 30 ����. ����: '.$_SESSION['erudit_m'].'");'; exit; }


}


// ____________________ ����� ���� ____________________


if($chat_game==1){


$show_n=0;


$past=$time-$_SESSION['erudit_t'];
if($past>$chat_let_t){
$show_n=1;
$left=$past-$chat_let_t;
if($left>0){
$show_n+=floor($left/$chat_let_p);
}
}


$word=$_SESSION['erudit_w'];
$mix=array();


$chat_erudit_m=array();
for($n=0;$n<strlen($_SESSION['erudit_m']);$n++){ $mix[]=$_SESSION['erudit_m'][$n]; }


if(strlen($word)<$show_n){
$show_n=strlen($word);
}


for($n=0;$n<$show_n;$n++){
for($i=0;$i<sizeof($mix);$i++){
if($mix[$i]==$word[$n]){
$mix[$i]='';
break;
}
}
}


$show_text='<span>'.substr($word,0,$show_n).'</span>'.implode($mix);


echo 'document.getElementById("erudit_word").innerHTML="'.$show_text.'";';


}


// ____________________ ������ ____________________


if(!empty($_POST['message'])){
$s_q=mysqli_query($db,"SELECT id FROM chat_message WHERE type='' ORDER BY id DESC LIMIT $chat_message_h,1");
$s_m=mysqli_fetch_row($s_q);
if(!empty($s_m[0])){ mysqli_query($db,"DELETE FROM chat_message WHERE type='' AND id<".($s_m[0]+1)); }
mysqli_query($db,"DELETE FROM chat_message WHERE type!='' AND type!='ls' AND date<".($time-60));
mysqli_query($db,"DELETE FROM chat_message WHERE type='ls' AND date<".($time-172800));
}


?>
