<?php
// Fill these values in ISPmanager before enabling the site.
// Keep this file private; direct HTTP access is denied by .htaccess.
return [
    'db_host' => 'localhost',
    'db_name' => 'vh687286_testzloto',
    'db_user' => 'vh687286_test',
    'db_password' => 'eJ7sG0nC9d',
    'admin_password' => '3RgftQwvbQghdol0l',
];
