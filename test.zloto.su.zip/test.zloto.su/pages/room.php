<?php


if(empty($lottery_m)){ echo '������ ��������'; exit; }


if(empty($_GET['num'])){ exit; }
$num=preg_replace("#[^0-9]+#i",'',$_GET['num'])+0;
if(empty($num) || strlen($num)>2 || empty($room[$num])){
exit;
}


if(empty($room[$num]['m'])){ echo '������� ���������'; exit; }


echo '<audio id="win_sound" preload>
<source src="/assets/room/room_win.mp3" type="audio/mpeg">
</audio>';


if(!isset($_COOKIE['room_sound']) || $_COOKIE['room_sound']==1){ $sound=1; }else{ $sound=0; }
echo '<div class="room_info">"'.$room[$num]['title'].'". ���������� '.(100-$room[$num]['to_admin']-$room[$num]['r_1']-$room[$num]['r_2']-$room[$num]['r_3']).'% �����. <font>������ �� '.$room[$num]['min'].' �� '.$room[$num]['max'].' ���.</font>
<span id="sound" class="sound_'.$sound.'" onclick="room_sound_toggle();"></span></div>
<script type="text/javascript">var room_sound='.$sound.';</script>';


if(empty($mode_gd) || ($mode_gd!=1 && $mode_gd!=2 && $mode_gd!=3 && $mode_gd!=4)){ $mode_gd=1; }
if(empty($_COOKIE['mg']) || ($_COOKIE['mg']!=1 && $_COOKIE['mg']!=2 && $_COOKIE['mg']!=3 && $_COOKIE['mg']!=4)){ $_COOKIE['mg']=$mode_gd; }


echo '<div class="room_mode_game">
<select id="mode_game" name="mode_game" onChange="document.cookie=\'mg=\'+this.value+\';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT\';">';
foreach($mode_game as $i=>$v){
if($_COOKIE['mg']==$i){ echo '<option value="'.$i.'" selected>'.$v.'</option>'; }
else{ echo '<option value="'.$i.'">'.$v.'</option>'; }
}
echo '</select>
</div>';


echo '<div id="message" class="room_message"></div>


<div id="winner" class="room_show_winner" style="display:none;">';
if($mobile==0){ echo '<div class="room_show_winner_title">����������: <span id="sw_login"></span> � ������ <span id="sw_percent"></span>%</div>'; }
else{ echo '<div class="room_show_winner_title">����������:<br> <span id="sw_login"></span> � ������ <span id="sw_percent"></span>%</div>'; }
echo '
<table class="room_show_winner_table" cellpadding="0px" cellspacing="0px">
<tr>
<td><img id="sw_avatar" src=""></td>
<td>
<div class="room_show_winner_sum_full">�������: <span id="sw_summ_full"></span> ���</div>
<div class="room_show_winner_sum_bet">������: <span id="sw_sum_bet"></span> ���</div>
<div class="room_show_winner_sum_real">�������: <span id="sw_sum_real"></span> ���</div>
</td>
</tr>
</table>
</div>


<div id="choose_winner_div" class="room_choose_winner" style="display:none;">
<div class="room_choose_winner_title">�������� ����������</div>
<div class="room_choose_winner_div">
<div class="room_choose_winner_bricket"></div>
<div id="choose_winner_list" class="room_choose_winner_window" style="left:0;"></div>
</div>
</div>


<div id="bet_table" style="display:block;">
<table class="room_bet_table" width="100%" cellpadding="0px" cellspacing="0px">
<tr>
<td class="room_bet_td">
<span class="room_bet_sum_word">�����</span>
<input id="bet_sum" class="room_bet_sum_input" type="text" autocomplete="off" value="'.$room[$num]['min'].'" name="bet_sum" oninput="this.value=this.value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\');">
<span class="room_bet_button" onclick="bet_ajax_send();">������</span>
</td>';


if($mobile==1){ echo '</tr><tr>'; }


echo '
<td class="room_bet_r_td">
<div class="room_bet_r_div">
<div id="bank_time" style="display:none;">
<div class="room_bet_r_bank">����: <span id="bank"></span> ���.</div>
<div class="room_bet_r_timer">�� �����: <span id="tcount" class=""></span></div>
</div>
<div id="wait" class="room_bet_r_wait"><img src="/images/pages/room/room_waiting.gif">'.$room[$num]['text'].'</div>
</div>
</td>
</tr>
</table>
</div>


<div id="vusers" class="room_u_div" style="width:100%;overflow:auto;">
<table class="room_u_table" cellpadding="5" cellspacing="0">
<tr><td class="room_u_wait">�������� �������...</span></td></tr>
</table>
</div>


<table width="100%" cellpadding="0px" cellspacing="0px">
<tr>
<td valign="top">


<div class="room_w_word">���������� ���������� ���</div>


<table class="room_w_table" cellpadding="5" cellspacing="0">
<tr>';
if($mobile==0){ echo '<td class="room_w_title_1" style="text-align:center;width:70px;">#</td>'; }
echo '
<td class="room_w_title" width="50px"></td>
<td class="room_w_title" width="200px">������������</td>
<td class="room_w_title" width="150px">�������</td>
<td class="room_w_title" width="150px">����</td>
<td class="room_w_title" width="150px">������</td>
</tr>
</table>


<div id="winners_div" style="height:600px;overflow:hidden;">
<table class="room_w_table" cellpadding="5" cellspacing="0">
<tbody id="winners_insert">';


$last_id=0;
$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT * FROM room_winners WHERE num='$num' ORDER BY id DESC LIMIT 10") or die('cant winners');
while($s_m=mysqli_fetch_assoc($s_q)){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
if($last_id==0){ $last_id=$s_m['id']; }
echo '<tr class="room_w_tr_'.$row_tr_n.'">';
if($mobile==0){ echo '<td class="room_w_text_2" style="text-align:center;width:70px;">'.$s_m['id'].'</td>'; }
if($u_id==$admin_uid){
echo '<td class="room_w_avatar" width="50px"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'" /></a></td>
<td class="room_w_text_1" width="200px"><a target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a></td>';
}
else{
echo '<td class="room_w_avatar" width="50px"><img src="'.$s_m['avatar'].'" /></td>
<td class="room_w_text_1" width="200px">'.$s_m['login'].'</td>';
}
echo '<td class="room_w_text_2" width="150px">'.$s_m['sum_full'].' �.</td>
<td class="room_w_text_1" width="150px">'.$s_m['percent'].'%</td>
<td class="room_w_text_2" width="150px">'.$s_m['sum_bet'].' �.</td>
</tr>';
}


echo '</tbody></table></div>


</td></tr></table>


</div>


<script type="text/javascript">


"use strict";


var my_uid='.$u_id.';


function room_sound_toggle(){
if(room_sound==1){ room_sound=0; }
else{ room_sound=1; }
document.cookie="room_sound="+room_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+room_sound;
}


function vu_resize(){
document.getElementById("vusers").style.width="100%";
document.getElementById("vusers").style.width=document.getElementById("vusers").offsetWidth-40+"px";
}


vu_resize();


function show_message(message_text){
clearTimeout(message_time);
document.getElementById("message").innerHTML=message_text;
message_time=setTimeout(\'document.getElementById("message").innerHTML="";\',3000);
}


var winners_tr_n=1;
var winners_list=new Array();
var winners_can=1;


function winners_scroll(){
if(winners_list.length>0 && winners_can==1){
if(winners_tr_n==1){ winners_tr_n=0; }else{ winners_tr_n++; }
var winners_text=winners_list.shift();
winners_text=winners_text.replace(/room\_w\_tr\_n/,"room_w_tr_"+winners_tr_n);
document.getElementById("winners_insert").insertAdjacentHTML("afterBegin",winners_text);
document.getElementById("winners_div").scrollTop+=60;
winners_can=2;
}
if(winners_can>1){ winners_can++; }
if(winners_can>200){ winners_can=1; }
document.getElementById("winners_div").scrollTop-=1;
requestAnimationFrame(winners_scroll);
}


winners_scroll();


var bet_ajax=new XMLHttpRequest();
var message_time;
var bet_can=0;


function bet_ajax_send(){


if(bet_can==1){ return; }
bet_can=1;


var bet_ajax_vars="bet_sum="+document.getElementById("bet_sum").value;


bet_ajax.onreadystatechange=function(){
if(bet_ajax.readyState==4){
if(bet_ajax.status==200){
try{ eval(bet_ajax.responseText); }
catch(e){}
}
setTimeout("bet_can=0;",1500);
}
}
bet_ajax.open("POST","/ajax/room_bet.php?num='.$num.'",true);
bet_ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
bet_ajax.send(bet_ajax_vars);


}


function resize_img(){
var imgs=document.getElementById("vusers").getElementsByTagName("img");
var imgs_len=imgs.length;
for(var i=0;i<imgs_len;i++){
if(imgs[i]!=null){
if(imgs[i].height!=imgs[i].width){
imgs[i].height=imgs[i].width;
}
}
}
// �� ������, ���� �������� �� ������ ����������, �� ��������
setTimeout("resize_img();",5000);
}


var up_ajax=new XMLHttpRequest();
var up_def=1;


function up_ajax_send(){
up_ajax.onreadystatechange=function(){
if(up_ajax.readyState==4){
clearTimeout(up_time);
if(up_ajax.status==200){
try{ eval(up_ajax.responseText); }
catch(e){}
}
if(up_def==1){
up_time=setTimeout("up_ajax_send();",2000);
}
}
}
up_ajax.open("POST","/ajax/room_up.php?num='.$num.'",true);
up_ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
up_ajax.send();
}


var vusers_hash="";


var started_time=new Date().getTime().toString().substr(0,10);
var now_time=0;
var elapsed_time=0;
var timer_hash_1=0;
var timer_1=0;
var timer_hash_2=0;
var timer_2=0;
var timer_show=0;


function timer_f(){
if(timer_hash_1!=timer_hash_2){
timer_hash_1=timer_hash_2;
timer_1=timer_2;
started_time=new Date().getTime().toString().substr(0,10);
}
now_time=new Date().getTime().toString().substr(0,10);
elapsed_time=now_time-started_time;
timer_show=timer_1-elapsed_time;
if(timer_show==-1){ timer_show=0; }
if(timer_show>=0){


// ������ ��� ������ ������


if(timer_show>59){
var t_ns=timer_show;
var t_ps=parseInt(timer_show/60);
t_ns-=t_ps*60;
var t_nm=t_ps;
var t_pm=parseInt(t_ps/60);
t_nm-=t_pm*60;
var t_nh=t_pm;
if(t_nh<10){ t_nh="0"+t_nh; }
if(t_nm<10){ t_nm="0"+t_nm; }
if(t_ns<10){ t_ns="0"+t_ns; }
timer_show=t_nh+":"+t_nm+":"+t_ns;
if(t_nh=="00"){ timer_show=t_nm+":"+t_ns; }
}


if(document.getElementById("tcount").innerHTML!=timer_show){
document.getElementById("tcount").innerHTML=timer_show;
}


if((timer_show==0 || timer_show>9) && document.getElementById("tcount").className=="room_bet_r_timer_blink"){ document.getElementById("tcount").className=""; }
if((timer_show>0 && timer_show<10) && document.getElementById("tcount").className==""){ document.getElementById("tcount").className="room_bet_r_timer_blink"; }
}
}


setInterval("timer_f();",100);


var last_id='.$last_id.';


var sw_last_id,sw_uid,sw_login,sw_percent,sw_avatar,sw_sum_full,sw_sum_real,sw_sum_bet,sw_avatars,sw_profile_link;
var sw_pre_list=[];
var sw_list=[];
var sw_ins_list="";


var sw_left=0;
var sw_target=0;
var sw_speed=0;
var sw_inc=0;
var sw_right=3200;
var sw_max=0;


var sw_mode=0;
var sw_balance=0;
var sw_money=0;


var balance_coin_time;
var money_coin_time;


var mobile='.$mobile.';


function set_list(){
document.getElementById("choose_winner_list").innerHTML="";
for(var b=0;b<sw_pre_list.length;b++){
for(var h=0;h<sw_pre_list[b][0];h++){
sw_list.push("<img src="+sw_pre_list[b][1]+">");
}
}
sw_list.sort(function() { return 0.5-Math.random(); } );
sw_list[60]="<img src="+sw_avatar+">";
for(var b=0;b<sw_list.length;b++){
sw_ins_list+=sw_list[b];
}
document.getElementById("choose_winner_list").innerHTML=sw_ins_list;
sw_pre_list=[];
sw_list=[];
sw_ins_list="";
}


function show_winner(){
document.getElementById("choose_winner_div").style.display="none";
document.getElementById("winner").style.display="block";
if(sw_uid==my_uid){


var myb=document.getElementById("my_balance").innerHTML.replace(/[^0-9\.]*/g,"");
myb=Number(myb)+Number(sw_balance);
myb=myb.toFixed(4);
document.getElementById("my_balance").innerHTML=myb;


var mym=document.getElementById("my_money").innerHTML.replace(/[^0-9\.]*/g,"");
mym=Number(mym)+Number(sw_money);
mym=mym.toFixed(4);
document.getElementById("my_money").innerHTML=mym;


if(sw_mode==3 || sw_mode==4){
document.getElementById("balance_coin").style.display="block";
clearTimeout(balance_coin_time);
balance_coin_time=setTimeout(\'document.getElementById("balance_coin").style.display="none";\',3000);
}


if(sw_mode==1 || sw_mode==2 || sw_mode==4){
document.getElementById("money_coin").style.display="block";
clearTimeout(money_coin_time);
money_coin_time=setTimeout(\'document.getElementById("money_coin").style.display="none";\',3000);
}


if(room_sound==1){ document.getElementById("win_sound").play(); }


}
}


function reset_bets(){
document.getElementById("winner").style.display="none";
document.getElementById("bank_time").style.display="none";
document.getElementById("wait").style.display="block";
document.getElementById("vusers").innerHTML=\'<table class="room_u_table" cellpadding="5" cellspacing="0"><tr><td class="room_u_wait">�������� �������...</td></tr></table>\';
document.getElementById("message").style.display="block";
document.getElementById("bet_table").style.display="block";


if(last_id!=sw_last_id){
last_id=sw_last_id;
var text=\'<tr class="room_w_tr_n">\';
if(mobile==0){
text+=\'<td class="room_w_text_2" style="text-align:center;">\'+sw_last_id+\'</td>\';
}
var sw_1="",sw_2="";
if(sw_profile_link!=""){
sw_1=\'<a target="_blank" href="/profile/\'+sw_profile_link+\'">\';
sw_2=\'</a>\';
}
text+=\'<td class="room_w_avatar" width="50px">\'+sw_1+\'<img src="\'+sw_avatar+\'">\'+sw_2+\'</td><td class="room_w_text_1" width="200px">\'+sw_1+sw_login+sw_2+\'</td>\';
text+=\'<td class="room_w_text_2" width="150px">\'+sw_sum_full+\' �.</td><td class="room_w_text_1" width="150px">\'+sw_percent+\'%</td><td class="room_w_text_2" width="150px">\'+sw_sum_bet+\' �.</td></tr>\';
winners_list.push(text);
}


up_def=1;
up_time=setTimeout("up_ajax_send();",500);
}


function scroll_users(){
if(sw_left>sw_target){
document.getElementById("choose_winner_list").style.left=-sw_target+"px";
setTimeout("show_winner()",1000);
setTimeout("reset_bets();",5000);
return;
}
requestAnimationFrame(scroll_users);
if(sw_left<sw_right){
sw_speed+=0.1*sw_inc;
if(sw_speed>sw_max){ sw_speed=sw_max; }
}
else{
sw_speed=-(sw_left-sw_target)/sw_target*50*sw_inc+0.2;
}
sw_left+=sw_speed;
document.getElementById("choose_winner_list").style.left=-sw_left+"px";
}


var up_time=setTimeout("up_ajax_send();",500);


</script>';


?>
