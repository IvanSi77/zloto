<?php


if(!empty($u_id) && $mydm['news']!=$d['news_n']){
mysqli_query($db,"UPDATE users SET news='".$d['news_n']."' WHERE uid='$u_id' LIMIT 1") or die('cant update my news count');
echo '<script type="text/javascript">if(document.getElementById("left_menu_news")!=null){ document.getElementById("left_menu_news").className="left_menu_def"; }</script>';
}


echo '<div class="title">'.$title.'</div>';


$np_pp=5;
$np_ss=10;


$where='';


if(!empty($_GET['id'])){
$news_id=preg_replace("#[^0-9]+#",'',$_GET['id']);
$news_id=number_format($news_id,0,'','');
if(empty($news_id) || !is_numeric($news_id) || strlen($news_id)>10){
$news_id=0;
}
$where='WHERE id='.$news_id;
$np_start=0;
$np_pp=1;
}
else{


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM news") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="np_def" href="/news/1#np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="np_def" href="/news/1#np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="np_now" href="/news/'.($n+1).'#np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="np_def" href="/news/'.($n+1).'#np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="np_def" href="/news/'.$n.'#np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="np_def" href="/news/'.$n.'#np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


}


if(!empty($np_links)){ echo '<a name="np_a" class="np_a"></a><div class="np_div">'.$np_links.'</div><br>'; }


$s_q=mysqli_query($db,"SELECT * FROM news $where ORDER BY id DESC LIMIT $np_start,$np_pp") or die('cant select news');
while($s_m=mysqli_fetch_assoc($s_q)){


echo '<table class="news_table" cellpadding="0px" cellspacing="0px">
<tr>
<td class="news_title">'.$s_m['title'].'</td>
<td class="news_date">'.$s_m['date'].'</td>
</tr>
<tr>
<td class="news_text" colspan="2">';
if(empty($_GET['id'])){ echo $s_m['text']; }
else{ echo $s_m['text_2']; }
if(empty($_GET['id']) && !empty($s_m['text_2'])){
echo '<div class="news_to_full"><div><a href="/news/r'.$s_m['id'].'">������ �����</a></div></div>';
}
echo '</td></tr></table>';


}


if(!empty($np_links)){ echo '<br><div class="np_div">'.$np_links.'</div>'; }


?>
