<?php


echo '<div class="title">'.$title.'</div>
<div class="contacts_text">'.$site_contacts.'</div>';


?>
