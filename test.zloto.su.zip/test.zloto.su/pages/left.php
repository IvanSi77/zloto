<?php


// ____________________ �������� � ������ ____________________


if(!empty($u_id)){
if($mobile==0){
echo '<img id="my_avatar" class="left_cab_avatar" src="'.$mydm['avatar'].'">
<div class="left_cab">
<div class="left_cab_login"><span>'.$mydm['login'].'</span> <a href="/exit"></a></div>
<table align="center" class="left_cab_bm_table" cellpadding="0px" cellspacing="0px">
<tr><td class="left_cab_balance">�� �������:</td><td class="left_cab_balance_right"><span id="my_balance" class="left_cab_balance_amount">'.$mydm['balance'].'</span> �<span class="left_cab_balance_coin"><span id="balance_coin" style="display:none;"></span></span></td></tr>
<tr><td class="left_cab_money">�� �����:</td><td class="left_cab_money_right"><span id="my_money" class="left_cab_money_amount">'.$mydm['money'].'</span> �<span class="left_cab_money_coin"><span id="money_coin" style="display:none;"></span></span></td></tr>
</table>
</div>';
}
else{
echo '<div class="left_cab_login_m"><img id="my_avatar" src="'.$mydm['avatar'].'"><span>'.$mydm['login'].'</span> <a href="/exit"></a></div>
<div class="left_cab_bm_div_m">
<table align="center" class="left_cab_bm_table_m" cellpadding="0px" cellspacing="0px">
<tr>
<td class="left_cab_balance_m"></td><td class="left_cab_balance_right_m"><span id="my_balance" class="left_cab_balance_amount_m">'.$mydm['balance'].'</span><span class="left_cab_balance_coin_m"><span id="balance_coin" style="display:none;"></span></span></td>
<td class="left_cab_money_m"></td><td class="left_cab_money_right_m"><span id="my_money" class="left_cab_money_amount_m">'.$mydm['money'].'</span><span class="left_cab_money_coin_m"><span id="money_coin" style="display:none;"></span></span></td>
</tr>
</table>
</div>';
}
}


// ____________________ ������� ____________________


if($u_id==$admin_uid){
echo '<a class="left_menu_admin" href="/?page=a_stat"><img src="/images/pages/left/left_menu_admin.png">������� ';
if(!empty($d['w_need'])){ echo '(�������)'; }
echo '</a>';
}


if(!empty($mobile)){
echo '<span class="left_menu_menu" onclick="left_menu();"><img src="/images/pages/left/left_menu_menu.png"><span id="left_menu_title">�������� ����</span></span>
<div id="left_menu_common" style="display:none;">';
}


// ____________________ ���� ____________________


if(empty($u_id)){ echo '<a class="left_menu_login" href="/login/"><img src="/images/pages/left/left_menu_cab.png">���� / �����������</a>'; }


// ____________________ ���� ����������� ____________________


if(!empty($u_id)){


echo '
<a class="left_menu_def" href="/cab/"><img src="/images/pages/left/left_menu_cab.png">������ �������</a>
<a class="left_menu_def" href="/up/"><img src="/images/pages/left/left_menu_up.png">��������� ������</a>
<a class="left_menu_def" href="/w/"><img src="/images/pages/left/left_menu_w.png">������� ������</a>
<a class="left_menu_def" href="/deps/"><img src="/images/pages/left/left_menu_deps.png">������������</a>';
echo '<a class="left_menu_def" href="/refs/"><img src="/images/pages/left/left_menu_refs.png">�������� ';
if(empty($mobile)){ echo '<span>'.$mydm['refs_c_3'].'</span><span>'.$mydm['refs_c_2'].'</span><span>'.$mydm['refs_c_1'].'</span>'; }
else{ echo '<span>'.$mydm['refs_c_1'].'</span><span>'.$mydm['refs_c_2'].'</span><span>'.$mydm['refs_c_3'].'</span>'; }
echo '</a>';


// ____________________ ������ ____________________


function bonus_gift($t_seconds){
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='00�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='00�'){ $t_m=''; }
$t_w=$t_d.$t_h.$t_m;
if($t_seconds<60){ $t_w.=$t_s; }
$t_w=preg_replace('#^0#','',$t_w);
return $t_w;
}


if($bonus_gift_1_m==1){
if($time-$mydm['bonus_gift_1_time']>$bonus_gift_1_time){ echo '<a id="bonus_gift_1_menu" class="left_menu_def" href="/bonus_gift_1/"><img src="/images/pages/left/left_menu_bonus_gift_1.png">�������� �����</a>'; }
else{ echo '<a id="bonus_gift_1_menu" class="left_menu_def" href="/bonus_gift_1/"><img src="/images/pages/left/left_menu_bonus_gift_1.png">�����: '.bonus_gift($bonus_gift_1_time-($time-$mydm['bonus_gift_1_time'])).'</a>';
}
}


if($bonus_gift_2_m==1){
if($time-$mydm['bonus_gift_2_time']>$bonus_gift_2_time){ echo '<a id="bonus_gift_2_menu" class="left_menu_def" href="/bonus_gift_2/"><img src="/images/pages/left/left_menu_bonus_gift_2.png">�������� �����</a>'; }
else{ echo '<a id="bonus_gift_2_menu" class="left_menu_def" href="/bonus_gift_2/"><img src="/images/pages/left/left_menu_bonus_gift_2.png">�����: '.bonus_gift($bonus_gift_2_time-($time-$mydm['bonus_gift_2_time'])).'</a>';
}
}


if($bonus_gift_3_m==1){
if($time-$mydm['bonus_gift_3_time']>$bonus_gift_3_time){ echo '<a id="bonus_gift_3_menu" class="left_menu_def" href="/bonus_gift_3/"><img src="/images/pages/left/left_menu_bonus_gift_3.png">�������� �����</a>'; }
else{ echo '<a id="bonus_gift_3_menu" class="left_menu_def" href="/bonus_gift_3/"><img src="/images/pages/left/left_menu_bonus_gift_3.png">�����: '.bonus_gift($bonus_gift_3_time-($time-$mydm['bonus_gift_3_time'])).'</a>';
}
}


// ____________________ ���� ____________________


echo '<a class="left_menu_def" href="/branch/"><img src="/images/pages/left/left_menu_game.png">��������� ����</a>
<a class="left_menu_def" href="/bubbles/"><img src="/images/pages/left/left_menu_game.png">������</a>';


// ____________________ Ѩ����� ____________________


$s_q=mysqli_query($db,"SELECT COUNT(*) FROM serf_list WHERE $serf_menu_clicks pause=0 AND modering=0 AND uid!=$u_id AND balance>=(cost+admin+to_sp_1+to_sp_2+to_sp_3)");
$s_m=mysqli_fetch_row($s_q);
$serf_works=0+$s_m[0];
if($u_id!=$admin_uid || ($u_id==$admin_uid && empty($d['serf_need']))){ echo '<a class="left_menu_def" href="/serf_main/"><img src="/images/pages/left/left_menu_serf.png">Ѹ����� <span>'.$serf_works.'</span></a>'; }
if($u_id==$admin_uid && !empty($d['serf_need'])){ echo '<a id="left_menu_serf" class="left_menu_def left_menu_blink" href="/serf_main/"><img src="/images/pages/left/left_menu_serf.png">Ѹ����� <span>'.$serf_works.'</span></a>'; }


// ____________________ ������� ____________________


echo '<a class="left_menu_def" href="/" onclick="view(\'ads_menu\');return false;"><img src="/images/pages/left/left_menu_ads.png">�������</a>
<div id="ads_menu" style="display:none;">';
if(!empty($ads_chain_1_m)){ echo '<a class="left_menu_def" href="/ads_chain_1/"><img src="/images/pages/left/left_menu_ads_2.png">��������� �������</a>'; }
if(!empty($ads_context_1_m)){ echo '<a class="left_menu_def" href="/ads_context_1/"><img src="/images/pages/left/left_menu_ads_2.png">����������� �������</a>'; }
if(!empty($ads_banner_1_m)){ echo '<a class="left_menu_def" href="/ads_banner_1/"><img src="/images/pages/left/left_menu_ads_2.png">������ � �������</a>'; }
if(!empty($ads_banner_2_m)){ echo '<a class="left_menu_def" href="/ads_banner_2/"><img src="/images/pages/left/left_menu_ads_2.png">������ � ��������</a>'; }
if(!empty($ads_banner_3_m)){ echo '<a class="left_menu_def" href="/ads_banner_3/"><img src="/images/pages/left/left_menu_ads_2.png">������ ��� ����</a>'; }
if(!empty($ads_banner_4_m)){ echo '<a class="left_menu_def" href="/ads_banner_4/"><img src="/images/pages/left/left_menu_ads_2.png">������ �����</a>'; }
echo '</div>';


// ____________________ ��������� ____________________


echo '<a class="left_menu_def" href="/promocode/"><img src="/images/pages/left/left_menu_promocode.png">���������</a>';


// ____________________ ��� ____________________


if($d['chat_opt']+1<$time){
mysqli_query($db,'DELETE FROM chat_online WHERE last_time<'.$time);
$chat_h='';
if(!empty($chat_hide_uid)){ $chat_h='WHERE uid NOT IN('.implode(',', $chat_hide_uid).')'; }
$s_q=mysqli_query($db,'SELECT COUNT(*) FROM chat_online '.$chat_h);
$s_m=mysqli_fetch_row($s_q);
$chat_pre_online=0+$s_m[0];
$chat_update_online='';
if(is_numeric($chat_pre_online) && $d['chat_online']!=$chat_pre_online){ $d['chat_online']=$chat_pre_online; $chat_update_online=',chat_online=\''.$chat_pre_online.'\''; }
mysqli_query($db,"UPDATE data SET chat_opt='$time'$chat_update_online LIMIT 1");
mysqli_query($db,"OPTIMIZE TABLE data,chat_message,chat_online") or die('cant optimize chat');
}
echo '<a class="left_menu_def" href="/chat/"><img src="/images/pages/left/left_menu_chat.png">��� <span>'.$d['chat_online'].'</span></a>';


}


// ____________________ ����� ���� ____________________


if(!empty($contest_bet_m)){ echo '<a class="left_menu_def" href="/contest_bet/"><img src="/images/pages/left/left_menu_contest.png">������� ������</a>'; }
if(!empty($contest_ref_m)){ echo '<a class="left_menu_def" href="/contest_ref/"><img src="/images/pages/left/left_menu_contest.png">������� ���������</a>'; }
if(!empty($contest_up_m)){ echo '<a class="left_menu_def" href="/contest_up/"><img src="/images/pages/left/left_menu_contest.png">������� ����������</a>'; }


// ____________________ ������ ____________________


if($u_id==$admin_uid && !empty($d['reviews_need'])){ echo '<a id="left_menu_reviews" class="left_menu_def left_menu_blink" href="/reviews/"><img src="/images/pages/left/left_menu_reviews.png">������ <span id="left_menu_reviews_amount">'.$d['reviews_c'].'</span></a>'; }
else{ echo '<a class="left_menu_def" href="/reviews/"><img src="/images/pages/left/left_menu_reviews.png">������ <span id="left_menu_reviews_amount">'.$d['reviews_c'].'</span></a>'; }


// ____________________ ������� ____________________


if(!empty($u_id) && $mydm['news']!=$d['news_n']){ echo '<a id="left_menu_news" class="left_menu_def left_menu_blink" href="/news/"><img src="/images/pages/left/left_menu_news.png">������� <span>'.$d['news_c'].'</span></a>'; }
else{ echo '<a class="left_menu_def" href="/news/"><img src="/images/pages/left/left_menu_news.png">������� <span>'.$d['news_c'].'</span></a>'; }


echo '<a class="left_menu_def" href="/faq/"><img src="/images/pages/left/left_menu_faq.png">������ - �����</a>
<a class="left_menu_def" href="/rules/"><img src="/images/pages/left/left_menu_rules.png">������� �������</a>';


// ____________________ ��������� ____________________


if(!empty($u_id)){


if(empty($mydm['support_from'])){
if($u_id==$admin_uid){ echo '<a class="left_menu_def" href="/support/"><img src="/images/pages/left/left_menu_contacts.png">���������</a>';}
else{ echo '<a class="left_menu_def" href="/support_dialog/"><img src="/images/pages/left/left_menu_contacts.png">���������</a>'; }
}
else{
if($u_id==$admin_uid){ echo '<a id="left_menu_support" class="left_menu_def left_menu_blink" href="/support/"><img src="/images/pages/left/left_menu_contacts.png">���������</a>'; }
else{ echo '<a id="left_menu_support"  class="left_menu_def left_menu_blink" href="/support_dialog/"><img src="/images/pages/left/left_menu_contacts.png">���������</a>'; }
}


}
else{
echo '<a class="left_menu_def" href="/contacts/"><img src="/images/pages/left/left_menu_contacts.png">��������</a>';
}


// ____________________ ��������� ������ ____________________


if($mobile==0){ echo '<a class="left_menu_def" href="/?mobile=1"><img src="/images/pages/left/left_menu_mobile.png">��������� ������</a>'; }
else{ echo '<a class="left_menu_def" href="/?mobile=0"><img src="/images/pages/left/left_menu_mobile.png">������� ������</a>'; }


if(!empty($mobile)){ echo '</div>'; }


// ____________________ ������ ____________________


if($mobile==0){
if(!empty($vk_group_link)){ echo '<a class="left_menu_vk" href="'.$vk_group_link.'" target="_blank"><img src="/images/pages/left/left_menu_vk.png">�� ���������</a>'; }
if(!empty($ok_group_link)){ echo '<a class="left_menu_ok" href="'.$ok_group_link.'" target="_blank"><img src="/images/pages/left/left_menu_ok.png">� ��������������</a>'; }
if(!empty($fb_group_link)){ echo '<a class="left_menu_fb" href="'.$fb_group_link.'" target="_blank"><img src="/images/pages/left/left_menu_fb.png">� FACEBOOK</a>'; }
}


// ____________________ ����������� ������� ____________________


if($mobile==0 && !empty($ads_context_1_m)){


$ads_value=str_replace('<','$ads_context_1_last[]=array(',$d['ads_context_1_last']);
$ads_context_1_last=array();
eval($ads_value);
echo '<div class="left_context_1">';
for($n=0;$n<$ads_context_1_i;$n++){
if(!empty($ads_context_1_last[$n])){
if($ads_context_1_style_s==0){ $ads_context_1_last[$n][1]=0; }
echo '<a class="left_context_1_a_'.$ads_context_1_last[$n][1].'" target="_blank" href="/?ads=context_1&id='.$ads_context_1_last[$n][0].'">'.$ads_context_1_last[$n][2].'</a>';
}
else{
echo '<a class="left_context_1_a_0" target="_blank" href="/ads_context_1/">����� ��������</a>';
}
}
echo '</div>';


}


// ____________________ ������ ____________________


if($mobile==0 && !empty($ads_banner_3_m)){


$ads_value=str_replace('<','$ads_banner_3_last[]=array(',$d['ads_banner_3_last']);
$ads_banner_3_last=array();
eval($ads_value);
for($n=0;$n<sizeof($ads_banner_3_last);$n++){
if($ads_banner_3_last[$n][1]<$time){ array_splice($ads_banner_3_last,$n,1); $n--; }
}
shuffle($ads_banner_3_last);
echo '<div class="left_banner_3">';
for($n=0;$n<$ads_banner_3_c;$n++){
if(!empty($ads_banner_3_last[$n])){ echo '<a target="_blank" href="'.$serf_site.'/?ads=banner_3&id='.$ads_banner_3_last[$n][0].'"><img src="'.$ads_banner_3_last[$n][2].'"></a>'; }
else{ echo '<a target="_blank" href="'.$serf_site.'/ads_banner_3/"><img src="'.$serf_site.'/images/cabinet/ads_is_banner/200300.gif"></a>'; }
}
echo '</div>';


}


?>
