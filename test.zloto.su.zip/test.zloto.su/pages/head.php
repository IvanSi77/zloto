<?php


echo '<!DOCTYPE html>
<html>
<head>
<title>'.$title.'</title>
<meta charset="windows-1251" />
<meta property="og:image" content="/images/cabinet/refs/refs_share_logo.png" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="'.$site_description.'"/>
<meta name="keywords" content="'.$site_keywords.'" />
<link rel="shortcut icon" href="/images/favicon.png" type="image/x-icon" />
<link href="/css/style.css" rel="stylesheet" type="text/css">
<link href="/css/pages.css" rel="stylesheet" type="text/css">
<link href="/css/cabinet.css" rel="stylesheet" type="text/css">
<link href="/css/admin.css" rel="stylesheet" type="text/css">';
if($mobile==1){
echo '<link id="mobile" href="/css/mobile.css" rel="stylesheet" type="text/css">';
}
echo '
<script type="text/javascript" src="/assets/common.js"></script>
</head>
<body>';


// ____________________ ��������� �� ������������� ____________________


if($u_id>0){
if(!empty($_POST['message']) && !empty($mydm['message'])){
mysqli_query($db,"UPDATE users SET message='' WHERE uid='$u_id' LIMIT 1");
$mydm['message']='';
}
if(!empty($mydm['message'])){
echo '<form id="form_message" style="display:none;" method="POST"><input type="hidden" name="message" value="1"></form>';
if($mobile==0){ echo '<div id="message" class="message">'; }
else{ echo '<div id="message" class="message" style="position:absolute;">'; }
echo ' <div class="message_common">
<table align="center" cellpadding="0px" cellspacing="2px">
<tr><td class="message_title"><div>��������� �� �������������</div></td></td></tr>
<tr><td class="message_text"><div>'.$mydm['message'].'</div></td></tr>
<tr><td class="message_close"><div onclick="document.getElementById(\'form_message\').submit();">�������</div></td></tr>
</table>
</div>
</div>';
}
}


// ____________________ ����������� ���� ____________________


if($u_id>0 && $hello_m==1){
if(!empty($_POST['hello']) && !empty($mydm['hello'])){
mysqli_query($db,"UPDATE users SET hello=0 WHERE uid='$u_id' LIMIT 1");
$mydm['hello']='';
}
if(!empty($mydm['hello'])){
echo '<form id="form_hello" style="display:none;" method="POST"><input type="hidden" name="hello" value="1"></form>';
if($mobile==0){ echo '<div id="hello" class="hello">'; }
else{ echo '<div id="hello" class="hello" style="position:absolute;">'; }
echo '<div class="hello_common" style="width:'.$hello_width.'px;height:'.$hello_height.'px;margin-top:-'.($hello_height/2).'px;">
<table align="center" cellpadding="0px" cellspacing="2px" style="width:'.$hello_width.'px;height:'.$hello_height.'px;">
<tr><td class="hello_title"><div>'.$hello_title.'</div></td></td></tr>
<tr><td class="hello_text"><div>'.$hello_text.'</div></td></tr>
<tr><td class="hello_close"><div onclick="document.getElementById(\'form_hello\').submit();">�������</div></td></tr>
</table>
</div>
</div>';
}
}


// ____________________ ����������� � ������� � ����������� ____________________


if($u_id>0){
if($mydm['nrc']!=0 && $mydm['h_nrc']!=1){
$upcs='nrc=0';
$nrc_v=substr($mydm['nrc'],-2);
$nrc_1=array(2,3,4,22,23,24,32,33,34,42,43,44,52,53,54,62,63,64,72,73,74,82,83,84,92,93,94);
$nrc_2=array(1,21,31,41,51,61,71,81,91);
$nrc_w='�������';
if(in_array($nrc_v,$nrc_1)){ $nrc_w='��������'; }
elseif(in_array($nrc_v,$nrc_2)){ $nrc_w='�������'; }
$td_nrc='<td><div class="upper_nrc_div"><div class="upper_nrc_title">����� ��������</div><div class="upper_nrc_value">'.$mydm['nrc'].'<br>'.$nrc_w.'</div></div></td>';
}
if($mydm['nrs']!=0 && $mydm['h_nrs']!=1){
if(empty($upcs)){ $upcs='nrs=0'; }
else{ $upcs.=',nrs=0'; }
$td_nrs='<td><div class="upper_nrs_div"><div class="upper_nrs_title">�������������</div><div class="upper_nrs_value">'.$mydm['nrs'].'<br>���.</div></div></td>';
}
if(!empty($upcs)){
mysqli_query($db,"UPDATE users SET $upcs WHERE uid='$u_id' LIMIT 1") or die('cant update upcs');
echo '<div id="upper" class="upper" style="display:block;" onclick="this.style.display=\'none\';"><table align="center" cellpadding="0px" cellspacing="0px"><tr>'.$td_nrc.$td_nrs.'</tr></table></div>';
}
}


// ____________________ ������ �������� ____________________


echo '<div id="head_who_online" class="head_who_online" style="display:none;">
<div class="head_who_online_div">
<div class="head_who_online_close"><span onclick="view(\'head_who_online\');">�������</span></div><br>
'.$who_online.'
</div>
</div>';


echo '
<script>
function head_who(){
if(document.getElementById("head_who_online").style.display=="none"){ document.getElementById("head_who_online").style.display="block"; }
else{ document.getElementById("head_who_online").style.display="none"; }
}
</script>


<table class="head" cellpadding="0px" cellspacing="0px">
<tr>';


if($mobile==0){


echo '<td class="head_logo">
<a href="/"><div class="head_logo_0">'.$site_logo.'</div>
</a>
</td>
<td width="60px">
<div style="cursor:pointer;" onclick="head_who();">
<div class="head_who_online_ball">'.$who_count.'</div>
<div class="head_who_online_word">������</div>
</div>
</td>
<td width="700px">';


}
else{


echo '<td>';


}


$blink=array();


$s_q=mysqli_query($db,"SELECT * FROM room_status LIMIT 1") or die('cant room_status');
$s_m=mysqli_fetch_assoc($s_q);


foreach($s_m as $i=>$v){ $blink[$i]=0; }


if(!empty($_GET['num']) && isset($blink['room_'.$_GET['num']])){ $blink['room_'.$_GET['num']]=1; }


if($page=='ms'){ $blink['ms']=1; }
else{ $blink['ms']=0; }
if($page=='gizmo'){ $blink['gizmo']=1; }
else{ $blink['gizmo']=0; }


echo '<table align="center" cellpadding="2px" cellspacing="0px">
<tr>';
foreach($room as $i=>$v){
if(!empty($room[$i]['m'])){
echo '<td>
<a class="head_room_'.$blink['room_'.$i].'" href="/room/'.$i.'">
<div class="head_room_title">'.$room[$i]['title'].'</div>
<div id="head_room_'.$i.'">'.$s_m['room_'.$i].'</div>
</a>
</td>';
}
}
if($mobile==1){ echo '</tr><tr>'; }
echo '
<td>
<a class="head_room_'.$blink['ms'].'" href="/ms/">
<div class="head_room_title">������<div style="line-height:28px;">���</div>������</div>
</a>
</td>
<td>
<a class="head_room_'.$blink['gizmo'].'" href="/gizmo/">
<div class="head_room_title"><div style="line-height:20px;padding-top: 5px;color:#ffba00;">�����</div><div style="line-height:30px;">�����</div></div>
</a>
</td>
</tr>
</table>


</td>
<td></td>
</tr>
</table>';


// ____________________ ��������� ������� ____________________


if($mobile==0 && !empty($ads_chain_1_m)){


$ads_value=str_replace('<','$ads_chain_1_last[]=array(',$d['ads_chain_1_last']);
$ads_chain_1_last=array();
eval($ads_value);
echo '<div class="head_chain_1">';
for($n=0;$n<$ads_chain_1_i;$n++){
if(!empty($ads_chain_1_last[$n])){
if($ads_chain_1_style_s==0){ $ads_chain_1_last[$n][1]=0; }
echo '<a class="head_chain_1_a_'.$ads_chain_1_last[$n][1].'" target="_blank" href="/?ads=chain_1&id='.$ads_chain_1_last[$n][0].'"><span>'.$ads_chain_1_last[$n][2].'</span></a>';
}
else{
echo '<a class="head_chain_1_a_0" target="_blank" href="/ads_chain_1/"><span>����� ��������</span></a>';
}
}
echo '</div>';


}


?>
