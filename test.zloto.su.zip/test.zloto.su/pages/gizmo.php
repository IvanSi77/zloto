<?php


if(isset($gizmo_m) && $gizmo_m==0){ echo '������ ��������'; exit; }


// ____________________ �������� ����������� ____________________


function gizmo_check($gizmo_level){
for($n=0;$n<sizeof($gizmo_level);$n++){
$gizmo_level[$n][0]=number_format($gizmo_level[$n][0],4,'.','');
if(empty($gizmo_level[$n][0]) || !is_numeric($gizmo_level[$n][0]) || $gizmo_level[$n][0]<0 || $gizmo_level[$n][0]>100000){
exit('������� '.($n+1).': �������� �������� ���������� ��������: '.$gizmo_level[$n][0]);
}
foreach($gizmo_level[$n][1] as $v){
if(empty($v) || !is_numeric($v) || $v<0 || $v>100000){
exit('������� '.($n+1).': �������� �������� ���������� �������: '.$v);
}
}
if(!isset($gizmo_level[$n][2]) || ($gizmo_level[$n][2]!=0 && $gizmo_level[$n][2]!=1 && $gizmo_level[$n][2]!=2 && $gizmo_level[$n][2]!=3)){
exit('������� '.($n+1).': �������� �������� ����������� ��������� ������: '.$gizmo_level[$n][2]);
}
if(empty($gizmo_level[$n][3]) || ($gizmo_level[$n][3]!=1 && $gizmo_level[$n][3]!=2 && $gizmo_level[$n][3]!=3)){
exit('������� '.($n+1).': �������� �������� ����������� ��������� ������: '.$gizmo_level[$n][3]);
}
}
return $gizmo_level;
}


// ____________________ ��� ���������� �������� ____________________


if(isset($_SESSION['gizmo_s']) && $_SESSION['gizmo_s']>0  && !empty($u_id)){


$sum=preg_replace("#[^0-9\.]+#",'',$_SESSION['gizmo_s']);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>15){ $sum=0; }
$_SESSION['gizmo_s']=0;
$_SESSION['gizmo_n']=0;
$_SESSION['gizmo_b']=0;


if($sum>0){
mysqli_query($db,"UPDATE users SET balance=(balance+$sum) WHERE uid=$u_id LIMIT 1") or die('cant return bet');
$mydm['balance']+=$sum;
$mydm['balance']=number_format($mydm['balance'],4,'.','');
echo '<script type="text/javascript">
document.getElementById("my_balance").innerHTML="'.$mydm['balance'].'";
document.getElementById("balance_coin").style.display="block";
setTimeout(\'document.getElementById("balance_coin").style.display="none";\',3000);
</script>';
}


}


// ____________________ ���� ____________________


if(!empty($_POST['act']) && $_POST['act']=='bet' && (!empty($_POST['sum']) || isset($_POST['type']))){
// ���� ���� config.php ��� ��� ���������
if(!empty($admin_uid)){ die('wrong post'); }
require_once('../config.php');
if(empty($gizmo_m)){ exit; }
// �� �����������
if(empty($u_id)){ echo 'window.location="/login";'; exit; }
// ������ �� ������ ������
if(!empty($_SESSION['gizmo_time']) && $_SESSION['gizmo_time']>microtime(true)-0.2){ exit; }
$_SESSION['gizmo_time']=microtime(true);


// ____________________ ������ ____________________


if(empty($_SESSION['gizmo_s']) && !empty($_POST['sum']) && empty($_POST['type'])){


$sum=preg_replace("#[^0-9\.]+#",'',$_POST['sum']);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>15){ echo 'gizmo_error("�������� �����");'; exit; }
if($mydm['balance']<$sum){ echo 'gizmo_error("�� ������� ������������ �����");'; exit; }
if($sum<$gizmo_min){ echo 'gizmo_error("����������� ����� ������ '.$gizmo_min.'");'; exit; }
if($sum>$gizmo_max){ echo 'gizmo_error("������������ ����� ������ '.$gizmo_max.'");'; exit; }


mysqli_query($db,"UPDATE users SET balance=(balance-$sum) WHERE uid=$u_id LIMIT 1") or die('cant user minus balance');


$mydm['balance']-=$sum;
$mydm['balance']=number_format($mydm['balance'],4,'.','');


echo 'document.getElementById("my_balance").innerHTML="'.$mydm['balance'].'";';
echo 'gizmo_start("'.number_format($sum,4,'.','').'");';


$_SESSION['gizmo_s']="$sum"; // ����� � ������ ����� 0.61 �� ������������ � 0.6099999999
$_SESSION['gizmo_n']=0;
$_SESSION['gizmo_b']=0;


exit;


}


// ____________________ ������� ��� ������ ������ ____________________


if(!empty($_SESSION['gizmo_s']) && empty($_POST['sum']) && isset($_SESSION['gizmo_n']) && $_SESSION['gizmo_n']==0 && isset($_SESSION['gizmo_b']) && !empty($_POST['type']) && $_POST['type']==5){


$sum=preg_replace("#[^0-9\.]+#",'',$_SESSION['gizmo_s']);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>15){ $sum=0; }
$_SESSION['gizmo_s']=0;
$_SESSION['gizmo_n']=0;
$_SESSION['gizmo_b']=0;


$gizmo_text='';


if($sum>0){
mysqli_query($db,"UPDATE users SET balance=(balance+$sum) WHERE uid=$u_id LIMIT 1") or die('cant return bet');
$mydm['balance']+=$sum;
$mydm['balance']=number_format($mydm['balance'],4,'.','');
echo 'gizmo_stop=1;';
$gizmo_text.='if(gizmo_sound==1){ document.getElementById(\"sound_money\").play(); }';
$gizmo_text.='document.getElementById(\"my_balance\").innerHTML=\"'.$mydm['balance'].'\";';
$gizmo_text.='document.getElementById(\"balance_coin\").style.display=\"block\";';
echo 'setTimeout(\'document.getElementById("balance_coin").style.display="none";\',3500);';
}


$gizmo_text.='gizmo_reset();';
$gizmo_text.='document.getElementById(\"gizmo_play\").style.display=\"block\";';
$gizmo_text.='document.getElementById(\"gizmo_take\").style.display=\"none\";';
$gizmo_text.='document.getElementById(\"gizmo_sum\").disabled=false;';
$gizmo_text.='gizmo_stop=0;gizmo_wait=0;gizmo_started=0;';


echo 'setTimeout("'.$gizmo_text.'",500);';


exit;


}


$gizmo_was_n=$_SESSION['gizmo_n'];
$gizmo_status=8;


// ____________________ �������� ����� ____________________


if(!empty($_SESSION['gizmo_s']) && empty($_POST['sum']) && isset($_SESSION['gizmo_n']) && isset($_SESSION['gizmo_b']) && !empty($_POST['type']) && ($_POST['type']==1 || $_POST['type']==2 || $_POST['type']==3  || $_POST['type']==4)){


echo 'gizmo_stop=1;';


if(empty($gizmo_level[$_SESSION['gizmo_n']])){ echo 'gizmo_error("����� ������ �� ����������");'; exit; }


$gizmo_level=gizmo_check($gizmo_level);


if($gizmo_level[$_SESSION['gizmo_n']][3]==1){ $gizmo_a=array(1,1,1,0); }
if($gizmo_level[$_SESSION['gizmo_n']][3]==2){ $gizmo_a=array(1,1,0,0); }
if($gizmo_level[$_SESSION['gizmo_n']][3]==3){ $gizmo_a=array(1,0,0,0); }


if(!empty($gizmo_level[$_SESSION['gizmo_n']][1]) && !empty($gizmo_level[$_SESSION['gizmo_n']][2])){
shuffle($gizmo_level[$_SESSION['gizmo_n']][1]);
if($gizmo_level[$_SESSION['gizmo_n']][2]==1){ $gizmo_bonus_rnd=rand(1,5); }
if($gizmo_level[$_SESSION['gizmo_n']][2]==2){ $gizmo_bonus_rnd=rand(1,10); }
if($gizmo_level[$_SESSION['gizmo_n']][2]==3){ $gizmo_bonus_rnd=rand(1,15); }
}


if(!empty($gizmo_bonus_rnd) && $gizmo_bonus_rnd==1){
$gizmo_a[]=2;
}


shuffle($gizmo_a);


$gizmo_status=$gizmo_a[0];


}


// ____________________ ������ �� ����� �� ������� ____________________


if($gizmo_status==1 || $gizmo_status==2){


$s_q=mysqli_query($db,"SELECT gizmo_kassa FROM data LIMIT 1") or die('cant select data');
$s_m=mysqli_fetch_assoc($s_q);
if(!isset($s_m['gizmo_kassa'])){ echo 'gizmo_error("������");'; exit; }


$sum=preg_replace("#[^0-9\.]+#",'',$_SESSION['gizmo_s']);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>15){ echo 'gizmo_error("������ � ����� ������");'; exit; }


$gizmo_b=preg_replace("#[^0-9\.]+#",'',$_SESSION['gizmo_b']);
$gizmo_b=number_format($gizmo_b,4,'.','')+0;
if(!is_numeric($gizmo_b) || strlen($gizmo_b)>15){ echo 'gizmo_error("������ � ����� ������");'; exit; }


if($gizmo_status==1){ $profit=number_format($sum*$gizmo_level[$_SESSION['gizmo_n']][0]+$gizmo_b,4,'.',''); }
else{ $profit=number_format($sum*$gizmo_level[$_SESSION['gizmo_n']][0]+$gizmo_b+$sum*$gizmo_level[$_SESSION['gizmo_n']][1][0],4,'.',''); }
$real=number_format($profit-$sum,4,'.','');


if($s_m['gizmo_kassa']-$real<0 || ($gizmo_limit!=0 && $sum>=$gizmo_limit)){ $profit=0; $real=0; $gizmo_b=0; $gizmo_status=0; }


}


// ____________________ ������� ____________________


if($gizmo_status==1 || $gizmo_status==2){


if($gizmo_status==2){
$gizmo_b+=number_format($sum*$gizmo_level[$_SESSION['gizmo_n']][1][0],4,'.','');
$gizmo_b=number_format($gizmo_b,4,'.','')+0;
if(empty($gizmo_b) || !is_numeric($gizmo_b) || strlen($gizmo_b)>15){ echo 'gizmo_error("������ � ������ ����� ������");'; exit; }
$_SESSION['gizmo_b']="$gizmo_b";
}


if($_SESSION['gizmo_n']<sizeof($gizmo_level)-1){ $_SESSION['gizmo_n']+=1; }
else{ $gizmo_win_full=1; }


$gizmo_text='';


// �� ��������� �������
if(empty($gizmo_win_full)){
$gizmo_text.='document.getElementById(\"gizmo_take_sum\").innerHTML=\"'.$profit.'\";';
if($gizmo_status==1){ $gizmo_text.='if(gizmo_sound==1){ document.getElementById(\"sound_win_level\").play(); }'; }
if($gizmo_status==2){ $gizmo_text.='if(gizmo_sound==1){ document.getElementById(\"sound_win_bonus\").play(); }'; }
// �������ר� ���� �����
if($gizmo_status==2){
for($n=$_SESSION['gizmo_n'];$n<sizeof($gizmo_level);$n++){
$gizmo_text.='document.getElementById(\"gizmo_priz_span_'.$n.'\").innerHTML='.number_format($sum*$gizmo_level[$n][0]+$gizmo_b,4,'.','').';';
}
}
$gizmo_text.='gizmo_set_table('.$_SESSION['gizmo_n'].');';
}
// ��������� �������
else{
$gizmo_text.='gizmo_win_full(\"'.$profit.'\");';
if($gizmo_status==2){
$gizmo_text.='document.getElementById(\"gizmo_priz_span_'.$gizmo_was_n.'\").innerHTML=\"'.number_format($sum*$gizmo_level[$gizmo_was_n][0]+$gizmo_b,4,'.','').'\";';
}
$gizmo_text.='if(gizmo_sound==1){ document.getElementById(\"sound_win_full\").play(); }';
}


if($gizmo_status==1){ $gizmo_text.='document.getElementById(\"gizmo_cell_'.$gizmo_was_n.'_'.$_POST['type'].'\").innerHTML=\"<font></font>\";'; }
if($gizmo_status==2){ $gizmo_text.='document.getElementById(\"gizmo_cell_'.$gizmo_was_n.'_'.$_POST['type'].'\").innerHTML=\"<i>x'.$gizmo_level[$gizmo_was_n][1][0].'</i>\";'; }
$gizmo_text.='gizmo_wait=0;gizmo_stop=0;';


echo 'setTimeout("'.$gizmo_text.'",500);';


}


if(!empty($_SESSION['gizmo_s']) && empty($_POST['sum']) && isset($_SESSION['gizmo_n']) && !empty($gizmo_level[$_SESSION['gizmo_n']]) && isset($_SESSION['gizmo_b']) && !empty($_POST['type']) && $_POST['type']==5){
$gizmo_take_money=1;
}


// ____________________ ��������, ������ ������ � ����� ____________________


if($gizmo_status==0 || !empty($gizmo_win_full) || !empty($gizmo_take_money)){


if($gizmo_status==0){
echo 'setTimeout("gizmo_default('.$gizmo_was_n.','.$_POST['type'].');document.getElementById(\"gizmo_cell_'.$gizmo_was_n.'_'.$_POST['type'].'\").innerHTML=\"<b></b>\";if(gizmo_sound==1){ document.getElementById(\"sound_lose\").play(); }",500);';
}


if(!empty($gizmo_win_full) || !empty($gizmo_take_money)){
echo 'setTimeout("gizmo_default('.$gizmo_was_n.','.$_POST['type'].');",500);';
}


echo 'setTimeout("document.getElementById(\"gizmo_sum\").disabled=false;gizmo_wait=0;gizmo_stop=0;gizmo_started=0;",500);';
echo 'setTimeout("document.getElementById(\"gizmo_take\").style.display=\"none\";document.getElementById(\"gizmo_play\").style.display=\"block\";",500);';


$sum=preg_replace("#[^0-9\.]+#",'',$_SESSION['gizmo_s']);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>15){ echo 'gizmo_error("������ � ����� ������");'; exit; }
$gizmo_b=preg_replace("#[^0-9\.]+#",'',$_SESSION['gizmo_b']);
$gizmo_b=number_format($gizmo_b,4,'.','')+0;
if(!is_numeric($gizmo_b) || strlen($gizmo_b)>15){ echo 'gizmo_error("������ � ����� ������");'; exit; }


// ��� �������� ������


$contest_bet=0;


if(!empty($contest_bet_m) && !empty($gizmo_contest)){


$s_q=mysqli_query($db,"SELECT contest_bet_d_1,contest_bet_d_2 FROM data LIMIT 1") or die('cant select data');
$d=mysqli_fetch_assoc($s_q);


$contest_bet_d_1=strtotime($d['contest_bet_d_1']);
$contest_bet_d_2=strtotime($d['contest_bet_d_2']);


if($time>$contest_bet_d_1 && $time<$contest_bet_d_2){ $contest_bet=$sum; }


}


// ��������������� ��� ������ �����


if(!empty($gizmo_take_money)){
$profit=number_format($sum*$gizmo_level[$gizmo_was_n-1][0]+$gizmo_b,4,'.','');
$real=number_format($profit-$sum,4,'.','');
}


// ���� ��������, �� �������� � ������ ������� 0
//if($gizmo_status==0){ $gizmo_was_n=0; }


if(!empty($gizmo_win_full)){ $gizmo_was_n+=1; }


// �������� ������


$_SESSION['gizmo_s']=0;
$_SESSION['gizmo_n']=0;
$_SESSION['gizmo_b']=0;


// ���������� ���������


mysqli_query($db,"INSERT INTO room_gizmo SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',uid=$u_id,login='".$mydm['login']."',avatar='".$mydm['avatar']."',level='$gizmo_was_n',sum='$sum',profit='$profit',bonus='$gizmo_b'") or die('cant insert room_gizmo');


$last_id=0+mysqli_insert_id($db);


if(!empty($last_id) && $last_id%100==0){
mysqli_query($db,"DELETE FROM room_gizmo WHERE id<".($last_id-100));
mysqli_query($db,"OPTIMIZE TABLE room_gizmo") or die('cant optimize room_gizmo');
}


}


// ____________________ ������ ������ � ����� ____________________


if(!empty($gizmo_win_full) || !empty($gizmo_take_money)){


mysqli_query($db,"UPDATE data SET games_gizmo='$last_id',gizmo_kassa=(gizmo_kassa-$real) LIMIT 1") or die('cant update data win_full and take_money');


if(empty($mode_gd) || ($mode_gd!=1 && $mode_gd!=2 && $mode_gd!=3 && $mode_gd!=4)){ $mode_gd=1; }
if(empty($_COOKIE['mg'])){ $_COOKIE['mg']=$mode_gd; }
if($_COOKIE['mg']==1){ $mode_gd=1; }
if($_COOKIE['mg']==2){ $mode_gd=2; }
if($_COOKIE['mg']==3){ $mode_gd=3; }
if($_COOKIE['mg']==4){ $mode_gd=4; }


$mode_balance=0;
$mode_money=0;


if($mode_gd==1){ $mode_balance=0; $mode_money=$profit; }
if($mode_gd==2){ $mode_balance=$sum; $mode_money=$real; }
if($mode_gd==3){ $mode_balance=$profit; $mode_money=0; }
if($mode_gd==4){ $mode_balance=$real; $mode_money=$sum; }


mysqli_query($db,"UPDATE users SET balance=(balance+$mode_balance),money=(money+$mode_money),bets_time=$time,bets_gizmo_s=(bets_gizmo_s+$sum),bets_gizmo_r=(bets_gizmo_r+$profit),bets_c=(bets_c+1),bets_win=(bets_win+1),contest_bet=contest_bet+$contest_bet WHERE uid=$u_id LIMIT 1") or die('cant update user win_full and take_money');


$mydm['balance']+=$mode_balance;
$mydm['balance']=number_format($mydm['balance'],4,'.','');
$mydm['money']+=$mode_money;
$mydm['money']=number_format($mydm['money'],4,'.','');


$gizmo_text='';


$gizmo_text.='document.getElementById(\"my_balance\").innerHTML=\"'.$mydm['balance'].'\";';
$gizmo_text.='document.getElementById(\"my_money\").innerHTML=\"'.$mydm['money'].'\";';


if($mode_gd==2 || $mode_gd==3 || $mode_gd==4){
$gizmo_text.='document.getElementById(\"balance_coin\").style.display=\"block\";';
$gizmo_text.='clearTimeout(balance_coin_time);';
$gizmo_text.='balance_coin_time=setTimeout(\'document.getElementById(\"balance_coin\").style.display=\"none\";\',3500);';
}


if($mode_gd==1 || $mode_gd==2 || $mode_gd==4){
$gizmo_text.='document.getElementById(\"money_coin\").style.display=\"block\";';
$gizmo_text.='clearTimeout(money_coin_time);';
$gizmo_text.='money_coin_time=setTimeout(\'document.getElementById(\"money_coin\").style.display=\"none\";\',3500);';
}


if(!empty($gizmo_win_full)){ $gizmo_text.='if(gizmo_sound==1){ document.getElementById(\"sound_win_full\").play(); }'; }
if(!empty($gizmo_take_money)){ $gizmo_text.='if(gizmo_sound==1){ document.getElementById(\"sound_money\").play(); }'; }


if($gizmo_rstyle==1){
$gizmo_received=number_format(($mydm['bets_gizmo_r']-$mydm['bets_gizmo_s']+$real),4,'.','');
if($gizmo_received<0){ $gizmo_received='<span style=\"color:#ca7a7a\">'.$gizmo_received.'</span>'; }
else{ $gizmo_received='<span style=\"color:#acd983\">+'.$gizmo_received.'</span>'; }
$gizmo_text.='document.getElementById(\"gizmo_received\").innerHTML=\''.$gizmo_received.'\';';
}


echo 'setTimeout("'.$gizmo_text.'",500);';


}


// ____________________ �������� ____________________


if($gizmo_status==0){


$to_sp_1=0;
$to_sp_2=0;
$to_sp_3=0;


if($mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){ $to_sp_1=number_format(($sum/100*$gizmo_r_1),4,'.','')+0; }
if($mydm['sp_uid_2']>0 && $mydm['sp_ban_2']==0){ $to_sp_2=number_format(($sum/100*$gizmo_r_2),4,'.','')+0; }
if($mydm['sp_uid_3']>0 && $mydm['sp_ban_3']==0){ $to_sp_3=number_format(($sum/100*$gizmo_r_3),4,'.','')+0; }


$update_ref_sum='';
$ref_sum=number_format($to_sp_1+$to_sp_2+$to_sp_3,4,'.','')+0;
if($ref_sum>0){ $update_ref_sum=',ref_sum=(ref_sum+'.$ref_sum.')'; }


$to_admin=number_format($sum/100*$gizmo_admin,4,'.','')+0;
$update_gizmo_kassa=number_format($sum-$to_admin-$ref_sum,4,'.','')+0;


$bm_text='';


$refback=0;
$to_rb_other='';


if(!empty($gizmo_refback_m) && $to_sp_1>0 && !empty($_SESSION['gizmo_rb']) && is_numeric($_SESSION['gizmo_rb']) && $_SESSION['gizmo_rb']<=100){
$refback=$to_sp_1*$_SESSION['gizmo_rb']/100;
$refback=number_format($refback,4,'.','')+0;
if($refback>0){
$to_rb_other='to_rb_other=(to_rb_other+'.$refback.'),';
if($gizmo_refback_to=='balance'){ $bm_text='balance=(balance+'.$refback.'),'; }
else{ $bm_text='money=(money+'.$refback.'),'; }
}
$to_sp_1=$to_sp_1-$refback;
$to_sp_1=number_format($to_sp_1,4,'.','')+0;
if($to_sp_1<0){ $to_sp_1=0; }
}


$to_sp_1_t='';
$to_sp_2_t='';
$to_sp_3_t='';


if($to_sp_1>0){ $to_sp_1_t='to_sp_1=(to_sp_1+'.$to_sp_1.'),'; }
if($to_sp_2>0){ $to_sp_2_t='to_sp_2=(to_sp_2+'.$to_sp_2.'),'; }
if($to_sp_3>0){ $to_sp_3_t='to_sp_3=(to_sp_3+'.$to_sp_3.'),'; }


mysqli_query($db,"UPDATE users SET $bm_text $to_rb_other $to_sp_1_t $to_sp_2_t $to_sp_3_t bets_time=$time,bets_gizmo_s=(bets_gizmo_s+$sum),bets_c=(bets_c+1),contest_bet=contest_bet+$contest_bet WHERE uid=$u_id LIMIT 1") or die('cant user update balance');
mysqli_query($db,"UPDATE data SET games_gizmo='$last_id',gizmo_kassa=(gizmo_kassa+$update_gizmo_kassa),admin_gizmo_r=(admin_gizmo_r+$to_admin) $update_ref_sum LIMIT 1") or die('cant update data');


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"UPDATE users SET $gizmo_way=($gizmo_way+$to_sp_1),nrs=(nrs+$to_sp_1),refs_r_1=(refs_r_1+$to_sp_1),rb_other=(rb_other+$refback) WHERE uid='".$mydm['sp_uid_1']."' LIMIT 1") or die('cant update sp balance 1'); }
if($to_sp_2>0){ mysqli_query($db,"UPDATE users SET $gizmo_way=($gizmo_way+$to_sp_2),nrs=(nrs+$to_sp_2),refs_r_2=(refs_r_2+$to_sp_2) WHERE uid='".$mydm['sp_uid_2']."' LIMIT 1") or die('cant update sp balance 2'); }
if($to_sp_3>0){ mysqli_query($db,"UPDATE users SET $gizmo_way=($gizmo_way+$to_sp_3),nrs=(nrs+$to_sp_3),refs_r_3=(refs_r_3+$to_sp_3) WHERE uid='".$mydm['sp_uid_3']."' LIMIT 1") or die('cant update sp balance 3'); }


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=1,sum='$to_sp_1',sp_uid='".$mydm['sp_uid_1']."',info='����� �����',refback='$refback'") or die('cant insert refs_profit 1'); }
if($to_sp_2>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=2,sum='$to_sp_2',sp_uid='".$mydm['sp_uid_2']."',info='����� �����'") or die('cant insert refs_profit 2'); }
if($to_sp_3>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=3,sum='$to_sp_3',sp_uid='".$mydm['sp_uid_3']."',info='����� �����'") or die('cant insert refs_profit 3'); }


$mydm[$gizmo_refback_to]=number_format($mydm[$gizmo_refback_to]+$refback,4,'.','');


$gizmo_text='';


$gizmo_text.='document.getElementById(\"my_'.$gizmo_refback_to.'\").innerHTML=\"'.$mydm[$gizmo_refback_to].'\";';


if($gizmo_rstyle==1){
$gizmo_received=number_format(($mydm['bets_gizmo_r']-$mydm['bets_gizmo_s']-$sum),4,'.','');
if($gizmo_received<0){ $gizmo_received='<span style=\"color:#ca7a7a\">'.$gizmo_received.'</span>'; }
else{ $gizmo_received='<span style=\"color:#acd983\">+'.$gizmo_received.'</span>'; }
$gizmo_text.='document.getElementById(\"gizmo_received\").innerHTML=\''.$gizmo_received.'\'';
}


echo 'setTimeout("'.$gizmo_text.'",500);';


}


exit;


}


// ____________________ ���������� ������ ��������� ��� ____________________


if(!empty($_POST['act']) && $_POST['act']=='up'){
// ���� ���� config.php ��� ��� ���������
if(!empty($admin_uid)){ die('wrong post'); }
require_once('../config.php');
// ������ �� ������ ����������
if(!empty($_SESSION['gizmo_up_time']) && $_SESSION['gizmo_up_time']>$time-2){ exit; }
$_SESSION['gizmo_up_time']=$time;


if(isset($_SESSION['gizmo_fid'])){ $gizmo_from=$_SESSION['gizmo_fid']; }
else{ $gizmo_from=0; $_SESSION['gizmo_fid']=0; }


$gizmo_fid=0;


$s_q=mysqli_query($db,"SELECT * FROM room_gizmo WHERE id>$gizmo_from ORDER BY id ASC") or die('cant select last gizmo');
while($s_m=mysqli_fetch_assoc($s_q)){


$gizmo_text='';


if($mobile!=0){ $gizmo_m_style='style="font-size:12px;"'; }


if($gizmo_fid==0){ $gizmo_fid=$s_m['id']; }
$gizmo_nid=$s_m['id'];
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$gizmo_text.='<tr class="gizmo_s_tr_n">';
if($mobile==0 && $gizmo_nstyle==1){ $gizmo_text.='<td class="gizmo_s_num" width="60px">'.$s_m['id'].'</td>'; }
if($u_id==$admin_uid){
$gizmo_text.='<td class="gizmo_s_avatar" style="padding-left:5px;" width="45px"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>';
$gizmo_text.='<td class="gizmo_s_login" width="160px"><div><a target="_blank" href="/profile/'.$profile_link.'" '.$gizmo_m_style.'>'.$s_m['login'].'</a></div></td>';
}
else{
$gizmo_text.='<td class="gizmo_s_avatar" style="padding-left:5px;" width="45px"><img src="'.$s_m['avatar'].'"></td>';
$gizmo_text.='<td class="gizmo_s_login" width="160px"><div>'.$s_m['login'].'</div></td>';
}
if($mobile==0){
$gizmo_text.='<td class="gizmo_s_level" width="120px">'.$s_m['level'].'</td>';
}
$gizmo_text.='<td class="gizmo_s_sum" width="80px" '.$gizmo_m_style.'>'.$s_m['sum'].' p.</td>';
if($s_m['profit']==0){ $gizmo_text.='<td class="gizmo_s_profit_0" '.$gizmo_m_style.'>'.$s_m['profit'].' �.</td>'; }
else{
$gizmo_x='';
if($s_m['bonus']>0){ $gizmo_x='<div>'.$s_m['bonus'].' �.</div>'; }
$gizmo_text.='<td class="gizmo_s_profit_1" '.$gizmo_m_style.'>'.$s_m['profit'].' �.'.$gizmo_x.'</td>';
}
$gizmo_text.='</tr>';


echo 'gizmo_up_list.push(\''.$gizmo_text.'\');';


}


if(!empty($gizmo_nid) && $gizmo_nid!=$_SESSION['gizmo_fid']){ $_SESSION['gizmo_fid']=$gizmo_nid; }


exit;
}


// ____________________ �������� ____________________


if(!isset($_COOKIE['gizmo_sound']) || $_COOKIE['gizmo_sound']==1){ $sound=1; }else{ $sound=0; }
echo '<div class="title">'.$title.'<span id="sound" class="sound_'.$sound.'" onclick="gizmo_sound_toggle();"></span></div>
<script type="text/javascript">var gizmo_sound='.$sound.';</script>';


$gizmo_level=gizmo_check($gizmo_level);


echo '
<audio id="sound_cell" preload>
<source src="/assets/gizmo/gizmo_cell.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_cell.mp3" type="audio/mpeg">
</audio>


<audio id="sound_lose" preload>
<source src="/assets/gizmo/gizmo_lose.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_lose.mp3" type="audio/mpeg">
</audio>


<audio id="sound_money" preload>
<source src="/assets/gizmo/gizmo_money.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_money.mp3" type="audio/mpeg">
</audio>


<audio id="sound_start" preload>
<source src="/assets/gizmo/gizmo_start.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_start.mp3" type="audio/mpeg">
</audio>


<audio id="sound_take" preload>
<source src="/assets/gizmo/gizmo_take.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_take.mp3" type="audio/mpeg">
</audio>


<audio id="sound_win_bonus" preload>
<source src="/assets/gizmo/gizmo_win_bonus.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_win_bonus.mp3" type="audio/mpeg">
</audio>


<audio id="sound_win_full" preload>
<source src="/assets/gizmo/gizmo_win_full.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_win_full.mp3" type="audio/mpeg">
</audio>


<audio id="sound_win_level" preload>
<source src="/assets/gizmo/gizmo_win_level.ogg" type="audio/ogg">
<source src="/assets/gizmo/gizmo_win_level.mp3" type="audio/mpeg">
</audio>
';


if(empty($mobile)){ $gizmo_width=100; $gizmo_margin=132; $gizmo_wf_margin=80; }
else{ $gizmo_width=60; $gizmo_margin=52;  $gizmo_wf_margin=0; }


echo '<div class="gizmo_common">


<div class="gizmo_info_common" id="gizmo_info_common" style="display:none;">
<div class="gizmo_info_text">
������� ������ ������, ������� "������" � �������� ���� �� ������ �����.
<br>���� ��� �������� ����� ��� �����, �� �� �������� � ������ ������� ������� ��� ���������� ����.
<br>���� ������� �����, �� ��������� ����� �������� �� ������� � ����� ������.
<br>����������� ������ <span>'.$gizmo_min.'</span> ���. ������������ ������ <span>'.$gizmo_max.'</span> ���.
<br>��� ���������� ��������, ���� ���� �� ���� ���������, �� ������ ������������ �� ������.
<br>� ������ ��������� ��� ������� ���� - ��������, ������ - �������, ����� - �����.';
if(!empty($gizmo_r_1) || !empty($gizmo_r_2) || !empty($gizmo_r_3)){
if($gizmo_way=='balance'){ echo '<br>� ����� ��������� �������� �������� ����������� �� �������:'; }
else{ echo '<br>� ����� ��������� �������� �������� ����������� �� �����:'; }
if(!empty($gizmo_r_1)){ echo '<br><span>'.$gizmo_r_1.'%</span> �������� 1-�� ������'; }
if(!empty($gizmo_r_2)){ echo '<br><span>'.$gizmo_r_2.'%</span> �������� 2-�� ������'; }
if(!empty($gizmo_r_3)){ echo '<br><span>'.$gizmo_r_3.'%</span> �������� 3-�� ������'; }
}
echo '</div></div>


<table class="gizmo_block" align="center" cellpadding="0" cellspacing="0">
<tr>
<td>


<div class="gizmo_info_title" onclick="view(\'gizmo_info_common\');">��� ������?</div>';


if(empty($mode_gd) || ($mode_gd!=1 && $mode_gd!=2 && $mode_gd!=3 && $mode_gd!=4)){ $mode_gd=1; }
if(empty($_COOKIE['mg']) || ($_COOKIE['mg']!=1 && $_COOKIE['mg']!=2 && $_COOKIE['mg']!=3 && $_COOKIE['mg']!=4)){ $_COOKIE['mg']=$mode_gd; }


echo '<div class="gizmo_mode_game">
<select id="mode_game" name="mode_game" onChange="document.cookie=\'mg=\'+this.value+\';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT\';">';
foreach($mode_game as $i=>$v){
if($_COOKIE['mg']==$i){ echo '<option value="'.$i.'" selected>'.$v.'</option>'; }
else{ echo '<option value="'.$i.'">'.$v.'</option>'; }
}
echo '</select>
</div>';


if($gizmo_rstyle==1){
$gizmo_received=number_format(($mydm['bets_gizmo_r']-$mydm['bets_gizmo_s']),4,'.','');
if($gizmo_received<0){ $gizmo_received='<span style="color:#ca7a7a">'.$gizmo_received.'</span>'; }
else{ $gizmo_received='<span style="color:#acd983">+'.$gizmo_received.'</span>'; }
echo '<div class="gizmo_received_title">����������</div>
<div class="gizmo_received_sum">
<span id="gizmo_received"">'.$gizmo_received.'</span> <font>���.</font>
</div>';
}


echo '<div id="gizmo_border" class="gizmo_border">


<div id="gizmo_win_full_common" class="gizmo_win_full_1" style="display:none;margin-left:'.$gizmo_wf_margin.'px;margin-top:0px;">
<div class="gizmo_win_full_2">
<div class="gizmo_win_full_text_1">������ ������!</div>
<div class="gizmo_win_full_text_2"><span id="gizmo_win_full_sum">+0.0000</span> <font>���.</font></div>
</div>
</div>';


$gizmo_js='var gizmo_level=[];';


for($n=sizeof($gizmo_level)-1;$n>=0;$n--){
$gizmo_js.='gizmo_level['.$n.']='.$gizmo_level[$n][0].';';
$gizmo_priz_sum=$gizmo_level[$n][0]*$gizmo_min;
$gizmo_priz_sum=number_format($gizmo_priz_sum,4,'.','');
echo '<table id="gizmo_cells_table_'.$n.'" class="gizmo_cells_table" cellpadding="0" cellspacing="0">
<td id="gizmo_priz_td_'.$n.'" class="gizmo_priz_td" colspan="4" style="display:table-cell"><div style="margin-left:'.$gizmo_margin.'px"><img src="/images/pages/gizmo/gizmo_priz_sum.png"><span id="gizmo_priz_span_'.$n.'">'.$gizmo_priz_sum.'</span> <font>���.</font></div></td>
</tr>
<tr>
<td id="gizmo_cell_'.$n.'_1" class="gizmo_cell" width="'.$gizmo_width.'px"><div></div></td>
<td id="gizmo_cell_'.$n.'_2" class="gizmo_cell" width="'.$gizmo_width.'px"><div></div></td>
<td id="gizmo_cell_'.$n.'_3" class="gizmo_cell" width="'.$gizmo_width.'px"><div></div></td>
<td id="gizmo_cell_'.$n.'_4" class="gizmo_cell" width="'.$gizmo_width.'px"><div></div></td>
</tr>
</table>';
}


echo '</div>


<div id="gizmo_play" class="gizmo_play" onclick="gizmo_bet_ajax_send(0);" style="display:block;">������</div>


<div id="gizmo_take" class="gizmo_take" onclick="gizmo_bet_ajax_send(5);" style="display:none;"><span>�������</span> <font id="gizmo_take_sum"></font> <b>���.</b></div>


<div id="gizmo_error" class="gizmo_error" style="display:none;"></div>


<table class="gizmo_bet_common" align="center" cellpadding="0" cellspacing="0">
<tr>
<td class="gizmo_bet_minus"><div onclick="gizmo_minus();">&ndash;</div></td>
<td class="gizmo_bet_sum" align="center">
<input id="gizmo_sum" name="sum" type="text" value="'.$gizmo_min.'" oninput="gizmo_input_sum();" autocomplete="off"/>
<div>������</div>
</td>
<td class="gizmo_bet_plus"><div onclick="gizmo_plus();">+</div></td>
</tr>
</table>


</td>
</tr>
</table>
 
 
</div>


<div class="gizmo_s_word">��������� '.$gizmo_c.' ���</div>';


if($mobile!=0){ $gizmo_m_style='style="font-size:12px;"'; }


echo '<table class="gizmo_s_table" cellpadding="0" cellspacing="0">
<tr>';
if($mobile==0 && $gizmo_nstyle==1){ echo '<td class="gizmo_s_title" style="text-align:center;" width="60px">#</td>'; }
echo '<td class="gizmo_s_title" style="padding-left:5px;" width="200px">������������</td>';
if($mobile==0){ echo '<td class="gizmo_s_title" width="120px" align="center">�������</td>';
}
echo '<td class="gizmo_s_title" width="80px">������</td>
<td class="gizmo_s_title" width="110px">�������</td>
</tr>
</table>


<div id="gizmo_div" style="height:'.($gizmo_c*40).'px;overflow:hidden;">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody id="gizmo_insert">';


$gizmo_fid=0;
$gizmo_nid=0;
$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT * FROM room_gizmo ORDER BY id DESC LIMIT $gizmo_c") or die('cant select last gizmo');
while($s_m=mysqli_fetch_assoc($s_q)){


$gizmo_text='';


if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
if($gizmo_fid==0){ $gizmo_fid=$s_m['id']; }
$gizmo_nid=$s_m['id'];
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$gizmo_text.='<tr class="gizmo_s_tr_'.$row_tr_n.'">';
if($mobile==0 && $gizmo_nstyle==1){ $gizmo_text.='<td class="gizmo_s_num" width="60px">'.$s_m['id'].'</td>'; }
if($u_id==$admin_uid){
$gizmo_text.='<td class="gizmo_s_avatar" style="padding-left:5px;" width="45px"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>';
$gizmo_text.='<td class="gizmo_s_login" width="160px"><div><a target="_blank" href="/profile/'.$profile_link.'" '.$gizmo_m_style.'>'.$s_m['login'].'</a></div></td>';
}
else{
$gizmo_text.='<td class="gizmo_s_avatar" style="padding-left:5px;" width="45px"><img src="'.$s_m['avatar'].'"></td>';
$gizmo_text.='<td class="gizmo_s_login" width="160px"><div>'.$s_m['login'].'</div></td>';
}
if($mobile==0){
$gizmo_text.='<td class="gizmo_s_level" width="120px">'.$s_m['level'].'</td>';
}
$gizmo_text.='<td class="gizmo_s_sum" width="80px" '.$gizmo_m_style.'>'.$s_m['sum'].' p.</td>';
if($s_m['profit']==0){ $gizmo_text.='<td class="gizmo_s_profit_0" '.$gizmo_m_style.'>'.$s_m['profit'].' �.</td>'; }
else{
$gizmo_x='';
if($s_m['bonus']>0){ $gizmo_x='<div>'.$s_m['bonus'].' �.</div>'; }
$gizmo_text.='<td class="gizmo_s_profit_1" '.$gizmo_m_style.'>'.$s_m['profit'].' �.'.$gizmo_x.'</td>';
}
$gizmo_text.='</tr>';


echo $gizmo_text;


}


$_SESSION['gizmo_fid']=$gizmo_fid;


echo '</tbody></table></div>


<script type="text/javascript">';


echo $gizmo_js;


echo '
function gizmo_sound_toggle(){
if(gizmo_sound==1){ gizmo_sound=0; }
else{ gizmo_sound=1; }
document.cookie="gizmo_sound="+gizmo_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+gizmo_sound;
}


var balance_coin_time;
var money_coin_time;
var gizmo_started=0;
var gizmo_message_time;


function gizmo_error(message_text){
clearTimeout(gizmo_message_time);
document.getElementById("gizmo_error").innerHTML=message_text;
document.getElementById("gizmo_play").style.display="none";
document.getElementById("gizmo_error").style.display="block";
gizmo_message_time=setTimeout(\'document.getElementById("gizmo_error").style.display="none";document.getElementById("gizmo_play").style.display="block";\',2000);
}


function gizmo_minus(){
if(gizmo_started==1){ return; }
var gizmo_sum=document.getElementById("gizmo_sum").value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');
if(gizmo_sum>0){}
else{ gizmo_sum='.$gizmo_min.'; }
gizmo_sum/=2;
gizmo_sum=gizmo_sum.toFixed(2);
if(gizmo_sum<'.$gizmo_min.'){ gizmo_sum='.$gizmo_min.'; }
document.getElementById("gizmo_sum").value=gizmo_sum;
gizmo_reset();
}


function gizmo_plus(){
if(gizmo_started==1){ return; }
var gizmo_sum=document.getElementById("gizmo_sum").value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');
if(gizmo_sum>0){}
else{ gizmo_sum='.$gizmo_min.'; }
gizmo_sum*=2;
gizmo_sum=gizmo_sum.toFixed(2);
if(gizmo_sum>'.$gizmo_max.'){ gizmo_sum='.$gizmo_max.'; }
document.getElementById("gizmo_sum").value=gizmo_sum;
gizmo_reset();
}


function gizmo_input_sum(){
var gizmo_sum=document.getElementById("gizmo_sum").value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');
if(gizmo_sum>'.$gizmo_max.'){ gizmo_sum='.$gizmo_max.'; }
document.getElementById("gizmo_sum").value=gizmo_sum;
gizmo_reset();
}


function gizmo_reset(){
document.getElementById("gizmo_win_full_common").style.display="none";
var gizmo_sum=document.getElementById("gizmo_sum").value;
for(var n=0;n<gizmo_level.length;n++){
if(gizmo_sum>0){ document.getElementById("gizmo_priz_span_"+n).innerHTML=(gizmo_sum*gizmo_level[n]).toFixed(4); }
else{ document.getElementById("gizmo_priz_span_"+n).innerHTML="0.0000"; }
document.getElementById("gizmo_cells_table_"+n).className="gizmo_cells_table";
document.getElementById("gizmo_priz_td_"+n).className="gizmo_priz_td";
document.getElementById("gizmo_priz_td_"+n).style.display="table-cell";
document.getElementById("gizmo_cell_"+n+"_1").innerHTML="<div></div>";
document.getElementById("gizmo_cell_"+n+"_2").innerHTML="<div></div>";
document.getElementById("gizmo_cell_"+n+"_3").innerHTML="<div></div>";
document.getElementById("gizmo_cell_"+n+"_4").innerHTML="<div></div>";
}
}


function gizmo_start(take_sum){
if(gizmo_started==1){ return; }
gizmo_started=1;
gizmo_reset();
document.getElementById("gizmo_take_sum").innerHTML=take_sum;
document.getElementById("gizmo_play").style.display="none";
document.getElementById("gizmo_take").style.display="block";
document.getElementById("gizmo_sum").disabled=true;
gizmo_set_table(0);
}


function gizmo_set_table(n){
document.getElementById("gizmo_cells_table_"+n).className="gizmo_cells_table gizmo_cells_table_2";
document.getElementById("gizmo_priz_td_"+n).className="gizmo_priz_td gizmo_priz_td_2";
document.getElementById("gizmo_cell_"+n+"_1").innerHTML="<span onclick=\"gizmo_bet_ajax_send(1);\"></span>";
document.getElementById("gizmo_cell_"+n+"_2").innerHTML="<span onclick=\"gizmo_bet_ajax_send(2);\"></span>";
document.getElementById("gizmo_cell_"+n+"_3").innerHTML="<span onclick=\"gizmo_bet_ajax_send(3);\"></span>";
document.getElementById("gizmo_cell_"+n+"_4").innerHTML="<span onclick=\"gizmo_bet_ajax_send(4);\"></span>";
if(n>0){
document.getElementById("gizmo_cells_table_"+(n-1)).className="gizmo_cells_table";
document.getElementById("gizmo_priz_td_"+(n-1)).style.display="none";
document.getElementById("gizmo_cell_"+(n-1)+"_1").innerHTML="<div></div>";
document.getElementById("gizmo_cell_"+(n-1)+"_2").innerHTML="<div></div>";
document.getElementById("gizmo_cell_"+(n-1)+"_3").innerHTML="<div></div>";
document.getElementById("gizmo_cell_"+(n-1)+"_4").innerHTML="<div></div>";
}
}


function gizmo_default(n,b){
document.getElementById("gizmo_cells_table_"+n).className="gizmo_cells_table";
document.getElementById("gizmo_priz_td_"+n).className="gizmo_priz_td";
if(b!=1){ document.getElementById("gizmo_cell_"+n+"_1").innerHTML="<div></div>"; }
if(b!=2){ document.getElementById("gizmo_cell_"+n+"_2").innerHTML="<div></div>"; }
if(b!=3){ document.getElementById("gizmo_cell_"+n+"_3").innerHTML="<div></div>"; }
if(b!=4){ document.getElementById("gizmo_cell_"+n+"_4").innerHTML="<div></div>"; }
}


function gizmo_win_full(sum){
var gizmo_wh_h=document.getElementById("gizmo_border").offsetHeight;
document.getElementById("gizmo_win_full_sum").innerHTML="+"+sum;
document.getElementById("gizmo_win_full_common").style.marginTop=(gizmo_wh_h-120)/2+"px";
document.getElementById("gizmo_win_full_common").style.display="block";
}


var gizmo_bet_ajax=new XMLHttpRequest();
var gizmo_wait=0;
var gizmo_stop=0;


function gizmo_bet_ajax_send(type){
if(gizmo_wait==1){ return; }
if(gizmo_started==1 && type==0){ return; }
if(gizmo_started==0 && type!=0){ return; }
gizmo_wait=1;
if(type==0){
var gizmo_bet_ajax_vars="act=bet&sum="+document.getElementById("gizmo_sum").value;
}
else{ var gizmo_bet_ajax_vars="act=bet&type="+type; }
if(type==0 && gizmo_sound==1){ document.getElementById("sound_start").play(); }
if(type==5 && gizmo_sound==1){ document.getElementById("sound_take").play(); }
if(type!=0 && type!=5 && gizmo_sound==1){ document.getElementById("sound_cell").play(); }
gizmo_bet_ajax.onreadystatechange=function(){
if(gizmo_bet_ajax.readyState==4){
if(gizmo_bet_ajax.status==200){
try{ eval(gizmo_bet_ajax.responseText); }
catch(e){}
}
if(gizmo_stop==0){
setTimeout("gizmo_wait=0;",200);
}
}
}
gizmo_bet_ajax.open("POST","/pages/gizmo.php",true);
gizmo_bet_ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
gizmo_bet_ajax.send(gizmo_bet_ajax_vars);
}


var gizmo_up_tr_n=1;
var gizmo_up_list=new Array();
var gizmo_up_can=1;


function gizmo_up_scroll(){
if(gizmo_up_list.length>0 && gizmo_up_can==1){
if(gizmo_up_tr_n==1){ gizmo_up_tr_n=0; }else{ gizmo_up_tr_n++; }
var gizmo_up_text=gizmo_up_list.shift();
gizmo_up_text=gizmo_up_text.replace(/gizmo\_s\_tr\_n/,"gizmo_s_tr_"+gizmo_up_tr_n);
document.getElementById("gizmo_insert").insertAdjacentHTML("afterBegin",gizmo_up_text);
document.getElementById("gizmo_div").scrollTop+=40;
gizmo_up_can=2;
}
if(gizmo_up_can>1){ gizmo_up_can+=5; }
if(gizmo_up_can>300){ gizmo_up_can=1; }
document.getElementById("gizmo_div").scrollTop-=1;
requestAnimationFrame(gizmo_up_scroll);
}


var gizmo_up_ajax=new XMLHttpRequest();


function gizmo_up_ajax_send(){
gizmo_up_ajax.onreadystatechange=function(){
if(gizmo_up_ajax.readyState==4){
clearTimeout(gizmo_up_time);
if(gizmo_up_ajax.status==200){
try{ eval(gizmo_up_ajax.responseText); }
catch(e){}
}
gizmo_up_time=setTimeout("gizmo_up_ajax_send();",5000);
}
}
gizmo_up_ajax.open("POST","/pages/gizmo.php",true);
gizmo_up_ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
gizmo_up_ajax.send("act=up");
}


var gizmo_up_time=setTimeout("gizmo_up_scroll();gizmo_up_ajax_send();",5000);


</script>';


?>
