<?php


if(isset($ms_m) && $ms_m==0){ echo '������ ��������'; exit; }


// ____________________ ������ ____________________


if(!empty($_POST['act']) && $_POST['act']=='bet' && !empty($_POST['sum']) && !empty($_POST['type']) && ($_POST['type']=='less' || $_POST['type']=='more')){
// ���� ���� config.php ��� ��� ���������
if(!empty($admin_uid)){ die('wrong post'); }
require_once('../config.php');
if(empty($ms_m)){ exit; }
// �� �����������
if(empty($u_id)){ echo 'window.location="/login";'; exit; }
// ������ �� ������ ������
if(!empty($_SESSION['ms_time']) && $_SESSION['ms_time']>$time-1){ exit; }
$_SESSION['ms_time']=$time;


$sum=preg_replace("#[^0-9\.]+#",'',$_POST['sum']);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>15){ echo 'show_message("<div class=\"ms_error\">�������� �����</div>");'; exit; }
if($mydm['balance']<$sum){ echo 'show_message("<div class=\"ms_error\">�� ������� ������������ �����</div>");'; exit; }
if($sum<$ms_min){ echo 'show_message("<div class=\"ms_error\">����������� ����� ������ '.$ms_min.'</div>");'; exit; }
if($sum>$ms_max){ echo 'show_message("<div class=\"ms_error\">������������ ����� ������ '.$ms_max.'</div>");'; exit; }


$chance=preg_replace("#[^0-9\.]+#",'',$_POST['chance']);
$chance=number_format($chance,2,'.','')+0;
if(empty($chance) || !is_numeric($chance) || strlen($chance)>5){ echo 'show_message("<div class=\"ms_error\">�������� ����</div>");'; exit; }
if($chance<$ms_small){ echo 'show_message("<div class=\"ms_error\">����������� ���� '.$ms_small.'</div>");'; exit; }
if($chance>$ms_big){ echo 'show_message("<div class=\"ms_error\">������������ ���� '.$ms_big.'</div>");'; exit; }


$random=rand(0,99999);
$win=0;


if($_POST['type']=='less'){
$type='less';
$ms_less=1+floor($chance/100*99999);
$target='0-'.$ms_less;
$ms_to_lose=rand(($ms_less+2),99999);
if($ms_less>$random){ $win=1; }
}
else{
$type='more';
$ms_more=1+floor(99999-$chance/100*99999);
$target=$ms_more.'-99999';
$ms_to_lose=rand(0,($ms_more-2));
if($ms_more<$random){ $win=1; }
}


$s_q=mysqli_query($db,"SELECT ms_kassa FROM data LIMIT 1") or die('cant select data');
$s_m=mysqli_fetch_assoc($s_q);
if(!isset($s_m['ms_kassa'])){ echo 'show_message("<div class=\"ms_error\">������</div>");'; exit; }


$profit=number_format($sum*100/$chance,4,'.','');
$real=number_format($profit-$sum,4,'.','');


if($s_m['ms_kassa']-$real<0 || ($ms_limit!=0 && $sum>=$ms_limit)){ $win=0; }


$_SESSION['ms_s']=$sum;
$_SESSION['ms_c']=$chance;


// ��� �������� ������


$contest_bet=0;


if(!empty($contest_bet_m) && !empty($ms_contest)){


$s_q=mysqli_query($db,"SELECT contest_bet_d_1,contest_bet_d_2 FROM data LIMIT 1") or die('cant select data');
$d=mysqli_fetch_assoc($s_q);


$contest_bet_d_1=strtotime($d['contest_bet_d_1']);
$contest_bet_d_2=strtotime($d['contest_bet_d_2']);


if($time>$contest_bet_d_1 && $time<$contest_bet_d_2){ $contest_bet=$sum; }


}


if($win==1){


mysqli_query($db,"INSERT INTO room_ms SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',uid=$u_id,login='".$mydm['login']."',avatar='".$mydm['avatar']."',digits='$random',target='$target',sum='$sum',chance='$chance',profit='$profit'") or die('cant set room_ms');


$last_id=0+mysqli_insert_id($db);


mysqli_query($db,"UPDATE data SET games_ms='$last_id',ms_kassa=(ms_kassa-$real) LIMIT 1") or die('cant update data');


if(empty($mode_gd) || ($mode_gd!=1 && $mode_gd!=2 && $mode_gd!=3 && $mode_gd!=4)){ $mode_gd=1; }
if(empty($_COOKIE['mg'])){ $_COOKIE['mg']=$mode_gd; }
if($_COOKIE['mg']==1){ $mode_gd=1; }
if($_COOKIE['mg']==2){ $mode_gd=2; }
if($_COOKIE['mg']==3){ $mode_gd=3; }
if($_COOKIE['mg']==4){ $mode_gd=4; }


$mode_balance=0;
$mode_money=0;


if($mode_gd==1){ $mode_balance=-$sum; $mode_money=$profit; }
if($mode_gd==2){ $mode_balance=0; $mode_money=$real; }
if($mode_gd==3){ $mode_balance=$real; $mode_money=0; }
if($mode_gd==4){ $mode_balance=-$sum+$real; $mode_money=$sum; }


mysqli_query($db,"UPDATE users SET balance=(balance+$mode_balance),money=(money+$mode_money),bets_time=$time,bets_ms_s=(bets_ms_s+$sum),bets_ms_r=(bets_ms_r+$profit),bets_c=(bets_c+1),bets_win=(bets_win+1),contest_bet=contest_bet+$contest_bet WHERE uid=$u_id LIMIT 1") or die('cant user update balance');


$mydm['balance']+=$mode_balance;
$mydm['balance']=number_format($mydm['balance'],4,'.','');
$mydm['money']+=$mode_money;
$mydm['money']=number_format($mydm['money'],4,'.','');


if($mobile==0){ echo 'show_message("<div class=\"ms_win\">������ ����� '.$random.' �� �������� '.$profit.' ���.</div>");'; }
else{ echo 'show_message("<div class=\"ms_win\" style=\"line-height:20px;\">������ ����� '.$random.'<br>�� �������� '.$profit.' ���.</div>");'; }
echo 'document.getElementById("my_balance").innerHTML="'.$mydm['balance'].'";
document.getElementById("my_money").innerHTML="'.$mydm['money'].'";';


if($mode_gd==3 || $mode_gd==4){
echo 'document.getElementById("balance_coin").style.display="block";
clearTimeout(balance_coin_time);
balance_coin_time=setTimeout(\'document.getElementById("balance_coin").style.display="none";\',3000);';
}


if($mode_gd==1 || $mode_gd==2 || $mode_gd==4){
echo 'document.getElementById("money_coin").style.display="block";
clearTimeout(money_coin_time);
money_coin_time=setTimeout(\'document.getElementById("money_coin").style.display="none";\',3000);';
}


echo 'if(ms_sound==1){ document.getElementById("sound_win").play(); }';


if($ms_rstyle==1){
$ms_received=number_format(($mydm['bets_ms_r']-$mydm['bets_ms_s']+$real),4,'.','');
if($ms_received<0){ $ms_received='<span style="color:#f00000">'.$ms_received.'</span>'; }
else{ $ms_received='<span style="color:#18d352">+'.$ms_received.'</span>'; }
echo 'document.getElementById("ms_received").innerHTML=\''.$ms_received.'\'';
}


if(!empty($last_id) && $last_id%100==0){
mysqli_query($db,"DELETE FROM room_ms WHERE id<".($last_id-100));
mysqli_query($db,"OPTIMIZE TABLE room_ms") or die('cant optimize room_ms');
}


exit;
}


if($win==0){


mysqli_query($db,"INSERT INTO room_ms SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',uid=$u_id,login='".$mydm['login']."',avatar='".$mydm['avatar']."',digits='$ms_to_lose',target='$target',sum='$sum',chance='$chance',profit='0'") or die('cant set room_ms');
$last_id=0+mysqli_insert_id($db);


$to_sp_1=0;
$to_sp_2=0;
$to_sp_3=0;


if($mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){ $to_sp_1=number_format(($sum/100*$ms_r_1),4,'.','')+0; }
if($mydm['sp_uid_2']>0 && $mydm['sp_ban_2']==0){ $to_sp_2=number_format(($sum/100*$ms_r_2),4,'.','')+0; }
if($mydm['sp_uid_3']>0 && $mydm['sp_ban_3']==0){ $to_sp_3=number_format(($sum/100*$ms_r_3),4,'.','')+0; }


$update_ref_sum='';
$ref_sum=number_format($to_sp_1+$to_sp_2+$to_sp_3,4,'.','')+0;
if($ref_sum>0){ $update_ref_sum=',ref_sum=(ref_sum+'.$ref_sum.')'; }


$to_admin=number_format($sum/100*$ms_admin,4,'.','')+0;
$update_ms_kassa=number_format($sum-$to_admin-$ref_sum,4,'.','')+0;


$bm_text='balance=(balance-'.$sum.'),';


$refback=0;
$to_rb_other='';


if(!empty($ms_refback_m) && $to_sp_1>0 && !empty($_SESSION['ms_rb']) && is_numeric($_SESSION['ms_rb']) && $_SESSION['ms_rb']<=100){
$refback=$to_sp_1*$_SESSION['ms_rb']/100;
$refback=number_format($refback,4,'.','')+0;
if($refback>0){
$to_rb_other='to_rb_other=(to_rb_other+'.$refback.'),';
if($ms_refback_to=='balance'){ $bm_text='balance=(balance-'.number_format($sum-$refback,4,'.','').'),'; }
else{ $bm_text='balance=(balance-'.$sum.'),money=(money+'.$refback.'),'; }
}
$to_sp_1=$to_sp_1-$refback;
$to_sp_1=number_format($to_sp_1,4,'.','')+0;
if($to_sp_1<0){ $to_sp_1=0; }
}


$to_sp_1_t='';
$to_sp_2_t='';
$to_sp_3_t='';


if($to_sp_1>0){ $to_sp_1_t='to_sp_1=(to_sp_1+'.$to_sp_1.'),'; }
if($to_sp_2>0){ $to_sp_2_t='to_sp_2=(to_sp_2+'.$to_sp_2.'),'; }
if($to_sp_3>0){ $to_sp_3_t='to_sp_3=(to_sp_3+'.$to_sp_3.'),'; }


mysqli_query($db,"UPDATE users SET $bm_text $to_rb_other $to_sp_1_t $to_sp_2_t $to_sp_3_t bets_time=$time,bets_ms_s=(bets_ms_s+$sum),bets_c=(bets_c+1),contest_bet=contest_bet+$contest_bet WHERE uid=$u_id LIMIT 1") or die('cant user update balance');
mysqli_query($db,"UPDATE data SET games_ms='$last_id',ms_kassa=(ms_kassa+$update_ms_kassa),admin_ms_r=(admin_ms_r+$to_admin) $update_ref_sum LIMIT 1") or die('cant update data');


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"UPDATE users SET $ms_way=($ms_way+$to_sp_1),nrs=(nrs+$to_sp_1),refs_r_1=(refs_r_1+$to_sp_1),rb_other=(rb_other+$refback) WHERE uid='".$mydm['sp_uid_1']."' LIMIT 1") or die('cant update sp balance 1'); }
if($to_sp_2>0){ mysqli_query($db,"UPDATE users SET $ms_way=($ms_way+$to_sp_2),nrs=(nrs+$to_sp_2),refs_r_2=(refs_r_2+$to_sp_2) WHERE uid='".$mydm['sp_uid_2']."' LIMIT 1") or die('cant update sp balance 2'); }
if($to_sp_3>0){ mysqli_query($db,"UPDATE users SET $ms_way=($ms_way+$to_sp_3),nrs=(nrs+$to_sp_3),refs_r_3=(refs_r_3+$to_sp_3) WHERE uid='".$mydm['sp_uid_3']."' LIMIT 1") or die('cant update sp balance 3'); }


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=1,sum='$to_sp_1',sp_uid='".$mydm['sp_uid_1']."',info='������ ��� ������',refback='$refback'") or die('cant insert refs_profit 1'); }
if($to_sp_2>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=2,sum='$to_sp_2',sp_uid='".$mydm['sp_uid_2']."',info='������ ��� ������'") or die('cant insert refs_profit 2'); }
if($to_sp_3>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=3,sum='$to_sp_3',sp_uid='".$mydm['sp_uid_3']."',info='������ ��� ������'") or die('cant insert refs_profit 3'); }


$mydm[$ms_refback_to]=number_format($mydm[$ms_refback_to]+$refback,4,'.','');


$mydm['balance']=number_format($mydm['balance']-$sum,4,'.','');


if($mobile==0){ echo 'show_message("<div class=\"ms_lose\">������ ����� '.$ms_to_lose.' �� ��������� '.$sum.' ���.</div>");'; }
else{ echo 'show_message("<div class=\"ms_lose\" style=\"line-height:20px;\">������ ����� '.$ms_to_lose.'<br>�� ��������� '.$sum.' ���.</div>");'; }
echo 'document.getElementById("my_balance").innerHTML="'.$mydm['balance'].'";document.getElementById("my_money").innerHTML="'.$mydm['money'].'";';


if($ms_rstyle==1){
$ms_received=number_format(($mydm['bets_ms_r']-$mydm['bets_ms_s']-$sum),4,'.','');
if($ms_received<0){ $ms_received='<span style="color:#f00000">'.$ms_received.'</span>'; }
else{ $ms_received='<span style="color:#18d352">+'.$ms_received.'</span>'; }
echo 'document.getElementById("ms_received").innerHTML=\''.$ms_received.'\'';
}


}


exit;
}


// ____________________ ���������� ������ ��������� ��� ____________________


if(!empty($_POST['act']) && $_POST['act']=='up'){
// ���� ���� config.php ��� ��� ���������
if(!empty($admin_uid)){ die('wrong post'); }
require_once('../config.php');
// ������ �� ������ ����������
if(!empty($_SESSION['ms_up_time']) && $_SESSION['ms_up_time']>$time-2){ exit; }
$_SESSION['ms_up_time']=$time;


if(isset($_SESSION['ms_fid'])){ $ms_from=$_SESSION['ms_fid']; }
else{ $ms_from=0; $_SESSION['ms_fid']=0; }


$ms_fid=0;


$s_q=mysqli_query($db,"SELECT * FROM room_ms WHERE id>$ms_from ORDER BY id ASC") or die('cant select last ms');
while($s_m=mysqli_fetch_assoc($s_q)){


$ms_text='';


if($mobile!=0){ $ms_m_style='style="font-size:12px;"'; }


if($ms_fid==0){ $ms_fid=$s_m['id']; }
$ms_nid=$s_m['id'];
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$ms_text.='<tr class="ms_s_tr_n">';
if($mobile==0 && $ms_nstyle==1){ $ms_text.='<td class="ms_s_num" width="60px">'.$s_m['id'].'</td>'; }
if($u_id==$admin_uid){
$ms_text.='<td class="ms_s_avatar" style="padding-left:5px;" width="45px"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>';
$ms_text.='<td class="ms_s_login" width="160px"><div><a target="_blank" href="/profile/'.$profile_link.'" '.$ms_m_style.'>'.$s_m['login'].'</a></div></td>';
}
else{
$ms_text.='<td class="ms_s_avatar" style="padding-left:5px;" width="45px"><img src="'.$s_m['avatar'].'"></td>';
$ms_text.='<td class="ms_s_login" width="160px"><div>'.$s_m['login'].'</div></td>';
}
if($mobile==0){
if($s_m['profit']==0){ $ms_text.='<td class="ms_s_digits_0" width="80px">'.$s_m['digits'].'</td>'; }
else{ $ms_text.='<td class="ms_s_digits_1" width="80px">'.$s_m['digits'].'</td>'; }
$ms_text.='<td class="ms_s_target" width="120px">'.$s_m['target'].'</td>';
}
$ms_text.='<td class="ms_s_sum" width="80px" '.$ms_m_style.'>'.$s_m['sum'].' p.</td>';
if($mobile==0){
if($ms_cstyle==0){
if($s_m['chance']<30){ $ms_text.='<td class="ms_s_chance_0" width="80px"><span><font style="width:'.($s_m['chance']/2+2).'px"></font></span></td>'; }
if($s_m['chance']>=30 && $s_m['chance']<60){ $ms_text.='<td class="ms_s_chance_1" width="80px"><span><font style="width:'.($s_m['chance']/2+2).'px"></font></span></td>'; }
if($s_m['chance']>=60){ $ms_text.='<td class="ms_s_chance_2" width="80px"><span><font style="width:'.($s_m['chance']/2+2).'px"></font></span></td>'; }
}
else{ $ms_text.='<td class="ms_s_chance_d" width="80px">'.$s_m['chance'].'%</td>'; }
}
if($s_m['profit']==0){ $ms_text.='<td class="ms_s_profit_0" '.$ms_m_style.'>'.$s_m['profit'].' �.</td>'; }
else{ $ms_text.='<td class="ms_s_profit_1" '.$ms_m_style.'>'.$s_m['profit'].' �.</td>'; }
$ms_text.='</tr>';


echo 'ms_list.push(\''.$ms_text.'\');';


}


if(!empty($ms_nid) && $ms_nid!=$_SESSION['ms_fid']){ $_SESSION['ms_fid']=$ms_nid; }


exit;
}


// ____________________ �������� ____________________


if(!isset($_COOKIE['ms_sound']) || $_COOKIE['ms_sound']==1){ $sound=1; }else{ $sound=0; }
echo '<div class="title">'.$title.'<span id="sound" class="sound_'.$sound.'" onclick="ms_sound_toggle();"></span></div>
<script type="text/javascript">var ms_sound='.$sound.';</script>';


if(!empty($_SESSION['ms_s']) && !empty($_SESSION['ms_c'])){
$ms_dis_s=$_SESSION['ms_s'];
$ms_dis_c=$_SESSION['ms_c'];
}
else{
$ms_dis_s=$ms_min;
$ms_dis_c=$ms_big;
}
$ms_dis_w=number_format($ms_dis_s*100/$ms_dis_c,4,'.','');
$ms_dis_l=1+floor($ms_dis_c/100*99999);
$ms_dis_m=1+floor(99999-$ms_dis_c/100*99999);


if($u_id>0){
echo '<audio id="sound_win" preload>
<source src="/assets/ms_win.ogg" type="audio/ogg">
<source src="/assets/ms_win.mp3" type="audio/mpeg">
</audio>';
}


echo '
<div class="ms_info_title" onclick="view(\'ms_info_common\');">��� ������?</div>
<div class="ms_info_common" id="ms_info_common" style="display:none;">
<div class="ms_info_text">
������� ������ ������ � ���� ���� ��������. ��� ������ ����, ��� ������ �������.
<br>�������� ���������� ������ ��� ������.
<br>������� ������������ ����� �� <span>0</span> �� <span>99 999</span>.
<br>���� ����� ��������� � �������� ���������, ������� �� �������, �� �����������.
<br>����������� ������ <span>'.$ms_min.'</span> ���. ������������ ������ <span>'.$ms_max.'</span> ���.
<br>����������� ���� <span>'.$ms_small.' %</span> ������������ ���� <span>'.$ms_big.' %</span>';
if(!empty($ms_r_1) || !empty($ms_r_2) || !empty($ms_r_3)){
if($ms_way=='balance'){ echo '<br>� ����� ��������� �������� �������� ����������� �� �������:'; }
else{ echo '<br>� ����� ��������� �������� �������� ����������� �� �����:'; }
if(!empty($ms_r_1)){ echo '<br><span>'.$ms_r_1.'%</span> �������� 1-�� ������'; }
if(!empty($ms_r_2)){ echo '<br><span>'.$ms_r_2.'%</span> �������� 2-�� ������'; }
if(!empty($ms_r_3)){ echo '<br><span>'.$ms_r_3.'%</span> �������� 3-�� ������'; }
}
echo '</div></div>';


if(empty($mode_gd) || ($mode_gd!=1 && $mode_gd!=2 && $mode_gd!=3 && $mode_gd!=4)){ $mode_gd=1; }
if(empty($_COOKIE['mg']) || ($_COOKIE['mg']!=1 && $_COOKIE['mg']!=2 && $_COOKIE['mg']!=3 && $_COOKIE['mg']!=4)){ $_COOKIE['mg']=$mode_gd; }


echo '<div class="ms_mode_game">
<select id="mode_game" name="mode_game" onChange="document.cookie=\'mg=\'+this.value+\';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT\';">';
foreach($mode_game as $i=>$v){
if($_COOKIE['mg']==$i){ echo '<option value="'.$i.'" selected>'.$v.'</option>'; }
else{ echo '<option value="'.$i.'">'.$v.'</option>'; }
}
echo '</select>';


if($ms_rstyle==1){
$ms_received=number_format(($mydm['bets_ms_r']-$mydm['bets_ms_s']),4,'.','');
if($ms_received<0){ $ms_received='<span style="color:#f00000">'.$ms_received.'</span>'; }
else{ $ms_received='<span style="color:#18d352">+'.$ms_received.'</span>'; }
echo '<div class="ms_received_title">����������</div>
<div class="ms_received_sum">
<span id="ms_received"">'.$ms_received.'</span> <font>���.</font>
</div>';
}


echo '<div id="message" style="display:none;"></div>


<div id="pre_profit_common" style="display:block;">
<div class="ms_pre_profit_title">��������� �������</div>
<div class="ms_pre_profit_sum">
<span id="pre_profit"">'.$ms_dis_w.'</span> <font>���.</font>
</div>
</div>
</div>


<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td>';


if($mobile==0){
$ms_bet_style='width:44%;margin-right:1%;float:left;';
$ms_chance_style='width:45%;margin-left:1%;float:left;';
}
else{
$ms_bet_style='';
$ms_chance_style='';
}


echo '<table class="ms_choice_common" align="center" cellpadding="0" cellspacing="0">
<tr>
<td>
<div class="ms_choice_less_title"><span>������ ���</span> <font id="less">'.$ms_dis_l.'</font></div>
<div class="ms_choice_less_button" onclick="sum_ajax_send(\'less\');">������</div>
</td>
<td>
<div class="ms_choice_more_title"><span>������ ���</span> <font id="more">'.$ms_dis_m.'</font></div>
<div class="ms_choice_more_button" onclick="sum_ajax_send(\'more\');">������</div>
</td>
</tr>
</table>';


echo '<div class="ms_bet_common" style="'.$ms_bet_style.'">
<div class="ms_bet_title">������:</div>
<input id="sum" name="sum" class="ms_bet_input" value="'.$ms_dis_s.'" oninput="this.style.color=\'#000000\';this.value=this.value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');if(this.value>'.$ms_max.'){ this.value='.$ms_max.'; } up_profit();" autocomplete="off"/>
<div class="ms_bet_buttons">';
echo '<span onclick="check_sc();document.getElementById(\'sum\').value*=2;update_profit();">�������</span>';
echo '<span onclick="check_sc();document.getElementById(\'sum\').value/=2;update_profit();" style="margin-left:4%;margin-right:4%;">��������</span>';
echo '<span onclick="document.getElementById(\'sum\').value='.$ms_max.';update_profit();" style="margin-right:4%;">����</span>';
echo '<span onclick="document.getElementById(\'sum\').value='.$ms_min.';update_profit();">���</span>';
echo '</div>
</div>


<div class="ms_chance_common" style="'.$ms_chance_style.'">
<div class="ms_chance_title">���� �� '.$ms_small.' �� '.$ms_big.'%:</div>
<input id="chance" name="chance" class="ms_chance_input" value="'.$ms_dis_c.'" oninput="this.style.color=\'#000000\';this.value=this.value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');if(this.value>'.$ms_big.'){ this.value='.$ms_big.'; } up_profit();" autocomplete="off"/>
<div class="ms_chance_buttons">';
echo '<span onclick="check_sc();document.getElementById(\'chance\').value*=2;update_profit();">�������</span>';
echo '<span onclick="check_sc();document.getElementById(\'chance\').value/=2;update_profit();" style="margin-left:4%;margin-right:4%;">��������</span>';
echo '<span onclick="document.getElementById(\'chance\').value='.$ms_big.';update_profit();" style="margin-right:4%;">����</span>';
echo '<span onclick="document.getElementById(\'chance\').value='.$ms_small.';update_profit();">���</span>';
echo '</div>
</div>


</td>
</tr>
</table>


<div style="clear:both;"></div>


<div class="ms_s_word">��������� '.$ms_c.' ���</div>';


if($mobile!=0){ $ms_m_style='style="font-size:12px;"'; }


echo '<table class="ms_s_table" cellpadding="0" cellspacing="0">
<tr>';
if($mobile==0 && $ms_nstyle==1){ echo '<td class="ms_s_title" style="text-align:center;" width="60px">#</td>'; }
echo '<td class="ms_s_title" style="padding-left:5px;" width="200px">������������</td>';
if($mobile==0){ echo '<td class="ms_s_title" width="80px">�����</td>
<td class="ms_s_title" width="120px">����</td>';
}
echo '<td class="ms_s_title" width="80px">������</td>';
if($mobile==0){ echo '<td class="ms_s_title" width="80px">����</td>'; }
echo '<td class="ms_s_title" width="110px">�������</td>
</tr>
</table>


<div id="ms_div" style="height:'.($ms_c*40).'px;overflow:hidden;">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody id="ms_insert">';


$ms_fid=0;
$ms_nid=0;
$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT * FROM room_ms ORDER BY id DESC LIMIT $ms_c") or die('cant select last ms');
while($s_m=mysqli_fetch_assoc($s_q)){


$ms_text='';


if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
if($ms_fid==0){ $ms_fid=$s_m['id']; }
$ms_nid=$s_m['id'];
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
$ms_text.='<tr class="ms_s_tr_'.$row_tr_n.'">';
if($mobile==0 && $ms_nstyle==1){ $ms_text.='<td class="ms_s_num" width="60px">'.$s_m['id'].'</td>'; }
if($u_id==$admin_uid){
$ms_text.='<td class="ms_s_avatar" style="padding-left:5px;" width="45px"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>';
$ms_text.='<td class="ms_s_login" width="160px"><div><a target="_blank" href="/profile/'.$profile_link.'" '.$ms_m_style.'>'.$s_m['login'].'</div></a></td>';
}
else{
$ms_text.='<td class="ms_s_avatar" style="padding-left:5px;" width="45px"><img src="'.$s_m['avatar'].'"></td>';
$ms_text.='<td class="ms_s_login" width="160px"><div>'.$s_m['login'].'</div></td>';
}
if($mobile==0){
if($s_m['profit']==0){ $ms_text.='<td class="ms_s_digits_0" width="80px">'.$s_m['digits'].'</td>'; }
else{ $ms_text.='<td class="ms_s_digits_1" width="80px">'.$s_m['digits'].'</td>'; }
$ms_text.='<td class="ms_s_target" width="120px">'.$s_m['target'].'</td>';
}
$ms_text.='<td class="ms_s_sum" width="80px" '.$ms_m_style.'>'.$s_m['sum'].' p.</td>';
if($mobile==0){
if($ms_cstyle==0){
if($s_m['chance']<30){ $ms_text.='<td class="ms_s_chance_0" width="80px"><span><font style="width:'.($s_m['chance']/2+2).'px"></font></span></td>'; }
if($s_m['chance']>=30 && $s_m['chance']<60){ $ms_text.='<td class="ms_s_chance_1" width="80px"><span><font style="width:'.($s_m['chance']/2+2).'px"></font></span></td>'; }
if($s_m['chance']>=60){ $ms_text.='<td class="ms_s_chance_2" width="80px"><span><font style="width:'.($s_m['chance']/2+2).'px"></font></span></td>'; }
}
else{ $ms_text.='<td class="ms_s_chance_d" width="80px">'.$s_m['chance'].'%</td>'; }
}
if($s_m['profit']==0){ $ms_text.='<td class="ms_s_profit_0" '.$ms_m_style.'>'.$s_m['profit'].' �.</td>'; }
else{ $ms_text.='<td class="ms_s_profit_1" '.$ms_m_style.'>'.$s_m['profit'].' �.</td>'; }
$ms_text.='</tr>';


echo $ms_text;


}


$_SESSION['ms_fid']=$ms_fid;


echo '</tbody></table></div>


<script type="text/javascript">


var balance_coin_time;
var money_coin_time;


function ms_sound_toggle(){
if(ms_sound==1){ ms_sound=0; }
else{ ms_sound=1; }
document.cookie="ms_sound="+ms_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+ms_sound;
}


function check_sc(){
if(document.getElementById("sum").value>0){}
else{ document.getElementById("sum").value='.$ms_min.'; }
if(document.getElementById("chance").value>0){}
else{ document.getElementById("chance").value='.$ms_big.'; }
}


function up_profit(){
if(document.getElementById("sum").value>='.$ms_min.' && document.getElementById("sum").value<='.$ms_max.'
 && document.getElementById("chance").value>='.$ms_small.' && document.getElementById("chance").value<='.$ms_big.'
){
document.getElementById("pre_profit").innerHTML=(100/Number(document.getElementById("chance").value)*Number(document.getElementById("sum").value)).toFixed(4);
}
else{
document.getElementById("pre_profit").innerHTML="0.0000";
}
if(document.getElementById("chance").value>='.$ms_small.' && document.getElementById("chance").value<='.$ms_big.'){
document.getElementById("less").innerHTML=1+Math.floor(Number(document.getElementById("chance").value)/100*99999);
document.getElementById("more").innerHTML=1+Math.floor(99999-Number(document.getElementById("chance").value)/100*99999);
}
else{
document.getElementById("less").innerHTML=0;
document.getElementById("more").innerHTML=0;
}
}


function update_profit(){
document.getElementById("sum").value=Number(document.getElementById("sum").value).toFixed(2);
if(document.getElementById("sum").value>'.$ms_max.'){ document.getElementById("sum").value='.$ms_max.'; }
if(document.getElementById("sum").value<'.$ms_min.'){ document.getElementById("sum").value='.$ms_min.'; }
document.getElementById("chance").value=Number(document.getElementById("chance").value).toFixed(2);
if(document.getElementById("chance").value>'.$ms_big.'){ document.getElementById("chance").value='.$ms_big.'; }
if(document.getElementById("chance").value<'.$ms_small.'){ document.getElementById("chance").value='.$ms_small.'; }
document.getElementById("sum").style.color="#000000";
document.getElementById("chance").style.color="#000000";
up_profit();
}


function show_message(message_text){
clearTimeout(message_time);
document.getElementById("message").innerHTML=message_text;
document.getElementById("pre_profit_common").style.display="none";
document.getElementById("message").style.display="block";
message_time=setTimeout(\'document.getElementById("message").style.display="none";document.getElementById("pre_profit_common").style.display="block";\',3000);
}


var sum_ajax=new XMLHttpRequest();
var message_time;
var sum_can=0;


function sum_ajax_send(type){
if(document.getElementById("sum").value>='.$ms_min.' && document.getElementById("sum").value<='.$ms_max.'){ }
else{ document.getElementById("sum").style.color="#ff0000"; return; }
if(document.getElementById("chance").value>='.$ms_small.' && document.getElementById("chance").value<='.$ms_big.'){ }
else{ document.getElementById("chance").style.color="#ff0000"; return; }
if(sum_can==1){ return; }
sum_can=1;
var sum_ajax_vars="act=bet&sum="+document.getElementById("sum").value+"&chance="+document.getElementById("chance").value+"&type="+type;
sum_ajax.onreadystatechange=function(){
if(sum_ajax.readyState==4){
if(sum_ajax.status==200){
try{ eval(sum_ajax.responseText); }
catch(e){}
}
setTimeout("sum_can=0;",1000);
}
}
sum_ajax.open("POST","/pages/ms.php",true);
sum_ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
sum_ajax.send(sum_ajax_vars);
}


var ms_tr_n=1;
var ms_list=new Array();
var ms_can=1;


function ms_scroll(){
if(ms_list.length>0 && ms_can==1){
if(ms_tr_n==1){ ms_tr_n=0; }else{ ms_tr_n++; }
var ms_text=ms_list.shift();
ms_text=ms_text.replace(/ms\_s\_tr\_n/,"ms_s_tr_"+ms_tr_n);
document.getElementById("ms_insert").insertAdjacentHTML("afterBegin",ms_text);
document.getElementById("ms_div").scrollTop+=40;
ms_can=2;
}
if(ms_can>1){ ms_can+=5; }
if(ms_can>300){ ms_can=1; }
document.getElementById("ms_div").scrollTop-=1;
requestAnimationFrame(ms_scroll);
}


var up_ajax=new XMLHttpRequest();


function up_ajax_send(){
up_ajax.onreadystatechange=function(){
if(up_ajax.readyState==4){
clearTimeout(up_time);
if(up_ajax.status==200){
try{ eval(up_ajax.responseText); }
catch(e){}
}
up_time=setTimeout("up_ajax_send();",2000);
}
}
up_ajax.open("POST","/pages/ms.php",true);
up_ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
up_ajax.send("act=up");
}


var up_time=setTimeout("ms_scroll();up_ajax_send();",2000);


</script>';


?>
