<?php


if(empty($game_branch_m)){ echo '������ ��������'; exit; }


if(!isset($_COOKIE['branch_sound']) || $_COOKIE['branch_sound']==1){ $sound=1; }else{ $sound=0; }
echo '<div class="title">'.$title.'<span id="sound" class="sound_'.$sound.'" onclick="gb_sound_toggle();"></span></div>
<script type="text/javascript">var gb_sound='.$sound.';</script>';


require_once('branch_config.php');


// �� ������, ���� �������� ���������� �������. ��� ������� 20, � ����� ������� 5. ������ ������ ��������� �������
if($mydm['branch_level']>sizeof($game_branch_level)-2){ $mydm['branch_level']=0; }


$mydm['branch_level']+=1;
$game_branch_time=$game_branch_time*60;


if(!isset($_SESSION['branch_stime'])){ $_SESSION['branch_stime']=0; }


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){
$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);
}
else{
$_POST=array();
}


$game_branch_set_level=$mydm['branch_level'];


$game_branch_width=$game_branch_level[$game_branch_set_level][0]; // ������
$game_branch_height=$game_branch_level[$game_branch_set_level][1]; // ������


$game_branch_item=array(); // ������ �������� ����


// ������� ��� ����


$game_branch_padds='background-position:';
$game_branch_pos=$game_branch_width/2;
if(strlen($game_branch_pos)>strlen($game_branch_width)){ $game_branch_padds.='25px '; }
else{ $game_branch_padds.='0px '; }
$game_branch_pos=$game_branch_height/2;
if(strlen($game_branch_pos)>strlen($game_branch_height)){ $game_branch_padds.='25px;'; }
else{ $game_branch_padds.='0px;'; }


// ��� ���� ���������
$game_branch_types=array();
$game_branch_types[1]=array(array(1,3),array(2,4));
$game_branch_types[2]=array(array(1,2),array(2,3),array(3,4),array(1,4));
$game_branch_types[3]=array(array(1,2,4),array(1,2,3),array(2,3,4),array(1,3,4));


// ��������� �������
$game_branch_light_x=mt_rand(1,$game_branch_width);
$game_branch_light_y=mt_rand(1,$game_branch_height);


// ����� ����������� ��������
$game_branch_lights_rnd_path=array();
if($game_branch_light_x-1>0){ $game_branch_lights_rnd_path[]=1; }
if($game_branch_light_y-1>0){ $game_branch_lights_rnd_path[]=2; }
if($game_branch_light_x+1<=$game_branch_width){ $game_branch_lights_rnd_path[]=3; }
if($game_branch_light_y+1<=$game_branch_height){ $game_branch_lights_rnd_path[]=4; }


// �������� ��������� ��������� �����������
$game_branch_origin=mt_rand(0,sizeof($game_branch_lights_rnd_path)-1);
$game_branch_origin=$game_branch_lights_rnd_path[$game_branch_origin];


// ������ ��� �� ����
$game_branch_item[$game_branch_light_x][$game_branch_light_y]=array(0,$game_branch_origin);


$game_branch_finish=0;


function game_branch_tree(){


global $game_branch_fcount,$game_branch_finish;


if($game_branch_finish==1){ return; }
$game_branch_fcount++;
if($game_branch_fcount>90){ return; }


global $game_branch_width,$game_branch_height,$game_branch_item,$game_branch_types,$game_branch_light_x,$game_branch_light_y,$game_branch_lights_rnd_path,$game_branch_origin;


// ���� ��������� �����


$game_branch_free_lights=array();


for($i=1;$i<=$game_branch_height;$i++){
for($j=1;$j<=$game_branch_width;$j++){
if(!empty($game_branch_item[$j][$i])){
if($game_branch_item[$j][$i][0]==0){
if(empty($game_branch_item[$j-1][$i]) && $j-1>0){ $game_branch_free_lights[]=array($j,$i,$game_branch_item[$j][$i][1]); continue; }
if(empty($game_branch_item[$j][$i-1]) && $i-1>0){ $game_branch_free_lights[]=array($j,$i,$game_branch_item[$j][$i][1]); continue; }
if(empty($game_branch_item[$j+1][$i]) && $j+1<=$game_branch_width){ $game_branch_free_lights[]=array($j,$i,$game_branch_item[$j][$i][1]); continue; }
if(empty($game_branch_item[$j][$i+1]) && $i+1<=$game_branch_height){ $game_branch_free_lights[]=array($j,$i,$game_branch_item[$j][$i][1]); continue; }
}}}}


// ���� ��� ��������� ����, �� �����


if(empty($game_branch_free_lights)){
$game_branch_finish=1;
return;
}


// ��������� ����� �� ���������
$game_branch_light=mt_rand(0,sizeof($game_branch_free_lights)-1);
$game_branch_light_x=$game_branch_free_lights[$game_branch_light][0];
$game_branch_light_y=$game_branch_free_lights[$game_branch_light][1];
$game_branch_origin=$game_branch_free_lights[$game_branch_light][2];


// ����� ����������� ��������
$game_branch_lights_rnd_path=array();
if($game_branch_light_x-1>0){ $game_branch_lights_rnd_path[]=1; }
if($game_branch_light_y-1>0){ $game_branch_lights_rnd_path[]=2; }
if($game_branch_light_x+1<=$game_branch_width){ $game_branch_lights_rnd_path[]=3; }
if($game_branch_light_y+1<=$game_branch_height){ $game_branch_lights_rnd_path[]=4; }


// � ����� ����������� ������ �����
$game_branch_cant_go=array();
if((!empty($game_branch_item[$game_branch_light_x-1][$game_branch_light_y]) && $game_branch_origin!=1) || $game_branch_light_x-1==0){ $game_branch_cant_go[]=1; }
if((!empty($game_branch_item[$game_branch_light_x][$game_branch_light_y-1]) && $game_branch_origin!=2) || $game_branch_light_y-1==0){ $game_branch_cant_go[]=2; }
if((!empty($game_branch_item[$game_branch_light_x+1][$game_branch_light_y]) && $game_branch_origin!=3) || $game_branch_light_x+1>$game_branch_width){ $game_branch_cant_go[]=3; }
if((!empty($game_branch_item[$game_branch_light_x][$game_branch_light_y+1]) && $game_branch_origin!=4) || $game_branch_light_y+1>$game_branch_height){ $game_branch_cant_go[]=4; }


// �������� ��������� ���� ������


$game_branch_rnd_types=array();


for($n=1;$n!=4;$n++){
if(empty($game_branch_types[$n])){
continue;
}
for($p=0;$p<sizeof($game_branch_types[$n]);$p++){
$game_branch_bad=0;
$game_branch_match=0;
for($v=0;$v<sizeof($game_branch_types[$n][$p]);$v++){
if($game_branch_types[$n][$p][$v]==$game_branch_origin && in_array($game_branch_types[$n][$p][$v],$game_branch_lights_rnd_path)){
$game_branch_match=1;
for($h=0;$h<sizeof($game_branch_types[$n][$p]);$h++){
if(in_array($game_branch_types[$n][$p][$h],$game_branch_cant_go)){
$game_branch_bad=1;
}}}
if($v==sizeof($game_branch_types[$n][$p])-1 && $game_branch_bad==0 && $game_branch_match==1){
$game_branch_rnd_types[]=array($n,$p+1);
if($n==3){
$game_branch_triples[]=array($n,$p+1);
}}}}}


// ���� ���� �������, �� �������� ����� ���


if(!empty($game_branch_triples)){
$game_branch_rnd_types=array();
$game_branch_rnd_types=$game_branch_triples;
}


// �������� �������� ����� �� ��������� ��������� ������


$game_branch_set_type=mt_rand(0,sizeof($game_branch_rnd_types)-1);
$game_branch_item[$game_branch_light_x][$game_branch_light_y]=$game_branch_rnd_types[$game_branch_set_type];


// ������ ����� �� �������������


$game_branch_tree_size=sizeof($game_branch_types[$game_branch_rnd_types[$game_branch_set_type][0]][$game_branch_rnd_types[$game_branch_set_type][1]-1]);


for($n=0;$n<$game_branch_tree_size;$n++){
$game_branch_type_lrtd=$game_branch_types[$game_branch_rnd_types[$game_branch_set_type][0]][$game_branch_rnd_types[$game_branch_set_type][1]-1][$n];
if($game_branch_type_lrtd==1 && empty($game_branch_item[$game_branch_light_x-1][$game_branch_light_y])){ $game_branch_item[$game_branch_light_x-1][$game_branch_light_y]=array(0,3); }
if($game_branch_type_lrtd==2 && empty($game_branch_item[$game_branch_light_x][$game_branch_light_y-1])){ $game_branch_item[$game_branch_light_x][$game_branch_light_y-1]=array(0,4); }
if($game_branch_type_lrtd==3 && empty($game_branch_item[$game_branch_light_x+1][$game_branch_light_y])){ $game_branch_item[$game_branch_light_x+1][$game_branch_light_y]=array(0,1); }
if($game_branch_type_lrtd==4 && empty($game_branch_item[$game_branch_light_x][$game_branch_light_y+1])){ $game_branch_item[$game_branch_light_x][$game_branch_light_y+1]=array(0,2); }
}


game_branch_tree();


}


// ____________________ ������ ____________________


if(!empty($_POST['act']) && $_POST['act']=='start' && $_SESSION['branch_stime']==0 && $mydm['branch_time']+$game_branch_time<$time && $mydm['up_m']>=$game_branch_up_m){


for($n=0;$n<10;$n++){
$game_branch_fcount=1;
game_branch_tree();
}


$_SESSION['branch_stime']=$time;


$game_branch_sess='';


for($i=1;$i<=$game_branch_height;$i++){
for($j=1;$j<=$game_branch_width;$j++){
$game_branch_sess.=$game_branch_item[$j][$i][0].$game_branch_item[$j][$i][1];
}
}


$_SESSION['branch']=$game_branch_sess;


}


// ____________________ ������� ____________________


if(!empty($_POST['act']) && $_POST['act']=='lose' && $_SESSION['branch_stime']!=0){
mysqli_query($db,"UPDATE users SET branch_level=0,branch_time=$time WHERE uid='$u_id' LIMIT 1") or die('cant update lose');
$_SESSION['branch_stime']=0;
$mydm['branch_time']=$time;
$mydm['branch_level']=0;
$game_branch_set_level=1;
}


$game_branch_rates_q=mysqli_query($db,"SELECT * FROM games WHERE name='branch' LIMIT 1") or die("cant select games");
$game_branch_rates_m=mysqli_fetch_assoc($game_branch_rates_q);


if(empty($game_branch_rates_m['name'])){ echo 'no game'; exit; }


// ____________________ ��������� ������ ____________________


if($game_branch_rates_m['period']<$time){

$game_branch_dn=date('w',$time);
$game_branch_at=0;
if($game_branch_dn==0){ $game_branch_at=86400; }
if($game_branch_dn>1){ $game_branch_at=-86400*($game_branch_dn-1); }
$game_branch_period=strtotime(date('d.m.Y',$time))+$game_branch_at;
$game_branch_period=preg_replace("#[^0-9]+#",'',$game_branch_period);
$game_branch_period=604800+number_format($game_branch_period,0,'','');
if(empty($game_branch_period) || !is_numeric($game_branch_period) || strlen($game_branch_period)!=10){
echo '������! �� ���� ���������� ����� ������������� ��������� ��������.';
exit;
}
mysqli_query($db,"UPDATE games SET period='".$game_branch_period."',top='' WHERE name='branch' LIMIT 1") or die('cant update period');
$game_branch_rates_m['top']='';
}


$game_branch_tops=array();
eval($game_branch_rates_m['top']);


$game_branch_lasts=array();
eval($game_branch_rates_m['last']);


$game_branch_elapsed='00:00:00';
$game_branch_status='tostart';


if($mydm['branch_time']+$game_branch_time<$time){
if($_SESSION['branch_stime']==0){
if($mydm['up_m']>=$game_branch_up_m){
$game_branch_center='<form id="game_branch_start_form" method="POST">
<input type="hidden" name="a_time" value="'.$time.'">
<input type="hidden" name="act" value="start">
</form>
<div class="game_branch_stat_start" onclick="document.getElementById(\'game_branch_start_form\').submit();">������</div>';
}
$game_branch_status='tostart';
}
else{
$t_seconds=$game_branch_time;
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.=':'; $t_m.=':';
$game_branch_center='<form id="game_branch_lose_form" method="POST">
<input type="hidden" name="a_time" value="'.$time.'">
<input type="hidden" name="act" value="lose">
</form>
<div id="game_branch_stat_lose" class="game_branch_stat_lose" onclick="document.getElementById(\'game_branch_lose_form\').submit();" style="display:block;">�������</div>
<div id="game_branch_stat_tosttime" class="game_branch_stat_tosttime"  style="display:none;">�� ����: <span id="time_to_start">'.$t_h.$t_m.$t_s.'</span></div>';
$game_branch_center.='<script type="text/javascript">
"use strict";
var t_tos_start;
function t_tos_timer(){
var t_seconds='.$t_seconds.'-(Math.round(new Date().getTime()/1000)-t_tos_start);
if(t_seconds<1){ location.href=location.href; return; }
else{
var t_h=parseInt(t_seconds/3600); var t_m=parseInt((t_seconds-t_h*3600)/60); var t_s=parseInt(t_seconds-t_h*3600-t_m*60);
if(t_h<10){ t_h="0"+t_h; } if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_h+=":"; t_m+=":";
document.getElementById("time_to_start").innerHTML=t_h+t_m+t_s;
setTimeout("t_tos_timer();",100);
}}
</script>';
$game_branch_status='started';
$game_branch_elapsed=$time-$_SESSION['branch_stime'];
}
}
else{
$t_seconds=$mydm['branch_time']+$game_branch_time-$time+1;
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.=':'; $t_m.=':';
$game_branch_status='notime';
$game_branch_center='<div class="game_branch_stat_tosttime">�� ����: <span id="time_to_start">'.$t_h.$t_m.$t_s.'</span></div>';
$game_branch_center.='<script type="text/javascript">
"use strict";
var t_tos_start=Math.round(new Date().getTime()/1000);
function t_tos_timer(){
var t_seconds='.$t_seconds.'-(Math.round(new Date().getTime()/1000)-t_tos_start);
if(t_seconds<0){ location.href=location.href; return; }
else{
var t_h=parseInt(t_seconds/3600); var t_m=parseInt((t_seconds-t_h*3600)/60); var t_s=parseInt(t_seconds-t_h*3600-t_m*60);
if(t_h<10){ t_h="0"+t_h; } if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_h+=":"; t_m+=":";
document.getElementById("time_to_start").innerHTML=t_h+t_m+t_s;
setTimeout("t_tos_timer();",100);
}}
t_tos_timer();
</script>';
}


if($game_branch_status=='started'){


if(empty($_SESSION['branch'])){
mysqli_query($db,"UPDATE users SET branch_time=0 WHERE uid='$u_id' LIMIT 1") or die('cant update restart');
$_SESSION['branch_stime']=0;
echo 'no branch';
exit;
}


$gbi=array();
$gbrep=$_SESSION['branch'];


$n=0;
for($i=1;$i<=$game_branch_height;$i++){
for($j=1;$j<=$game_branch_width;$j++){
$gbi[$j][$i]=array($gbrep[$n],$gbrep[$n+1]);
$n+=2;
}
}


// �������� ��������


$game_branch_no_lights=array();


for($i=1;$i<=$game_branch_height;$i++){
for($j=1;$j<=$game_branch_width;$j++){
if($gbi[$j][$i][0]!=0){
$game_branch_no_lights[]=array($j,$i);
}
}
}


$game_branch_rnd_no_lights=mt_rand(0,sizeof($game_branch_no_lights)-1);
$game_branch_energy_x=$game_branch_no_lights[$game_branch_rnd_no_lights][0];
$game_branch_energy_y=$game_branch_no_lights[$game_branch_rnd_no_lights][1];


// �������������


for($i=1;$i<=$game_branch_height;$i++){
for($j=1;$j<=$game_branch_width;$j++){
$game_branch_shuffle=mt_rand(1,2);
if($gbi[$j][$i][0]!=1){
while($gbi[$j][$i][1]==$game_branch_shuffle){
$game_branch_shuffle=mt_rand(1,4);
}
}
$gbi[$j][$i][1]=$game_branch_shuffle;
}
}


}


echo '<link rel="stylesheet" href="/games/branch/branch.css" type="text/css">';


// ____________________ ������ ____________________


if($mobile==0 && !empty($ads_banner_2_m)){


$ads_banner_2_c='ads_banner_2_c_'.$page;
$ads_banner_2_c=$$ads_banner_2_c;
if(!empty($ads_banner_2_c)){
$ads_value=str_replace('<','$ads_banner_2_last[]=array(',$d['ads_banner_2_last']);
$ads_banner_2_last=array();
eval($ads_value);
for($n=0;$n<sizeof($ads_banner_2_last);$n++){
if($ads_banner_2_last[$n][1]<$time){ array_splice($ads_banner_2_last,$n,1); $n--; }
}
shuffle($ads_banner_2_last);
echo '<div class="games_banner_2">';
for($n=0;$n<$ads_banner_2_c;$n++){
if(!empty($ads_banner_2_last[$n])){ echo '<a target="_blank" href="'.$serf_site.'/?ads=banner_2&id='.$ads_banner_2_last[$n][0].'"><img src="'.$ads_banner_2_last[$n][2].'"></a>'; }
else{ echo '<a target="_blank" href="'.$serf_site.'/ads_banner_2/"><img src="'.$serf_site.'/images/cabinet/ads_is_banner/46860.gif"></a>'; }
}
echo '</div>';
}


}


echo '<div class="game_branch_common">


<table class="game_branch_stat" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td class="game_branch_stat_avatar">';
if(!empty($game_branch_tops[$game_branch_set_level])){ echo '<img src="'.$game_branch_tops[$game_branch_set_level][0].'">'; }
echo '</td>
<td width="190px">';
if(!empty($game_branch_tops[$game_branch_set_level])){


$t_seconds=$game_branch_tops[$game_branch_set_level][2];
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.=':'; $t_m.=':';


echo '<div class="game_branch_stat_tlevel">������ ����� ������</div>
<div class="game_branch_stat_tlogin">�����: '.$game_branch_tops[$game_branch_set_level][1].'</div>
<div class="game_branch_stat_ttime">�����: '.$t_h.$t_m.$t_s.'</div>';
}
else{ echo '<div class="game_branch_stat_notop">��� �������</div>'; }
echo '</td>
<td class="game_branch_stat_center"><div class="game_branch_stat_cash">����������: <font id="game_branch_cash">'.$mydm['branch_r'].'</font> �</div>';
echo $game_branch_center;
echo '</td>
<td>
<div class="game_branch_stat_mylevel">������� '.$game_branch_set_level.' �� '.(sizeof($game_branch_level)-1).'</div>
<div class="game_branch_stat_mytime">�����: <span id="game_branch_stat_mytime">'.$game_branch_elapsed.'</span></div>
</td>
</table>';


if($game_branch_status=='started'){


echo '<script type="text/javascript">';


$gb_etime_d=(int)($game_branch_elapsed/86400);
$gb_etime_h=(int)(($game_branch_elapsed-$gb_etime_d*86400)/3600);
$gb_etime_m=(int)((($game_branch_elapsed-$gb_etime_d*86400)-$gb_etime_h*3600)/60);
$gb_etime_s=(int)((($game_branch_elapsed-$gb_etime_d*86400)-$gb_etime_h*3600-$gb_etime_m*60));
$gb_etime_h+=$gb_etime_d*24;


echo '
gb_et_h='.$gb_etime_h.';
gb_et_m='.$gb_etime_m.';
gb_et_s='.$gb_etime_s.';


var gb_stoptime=0;
var gb_time=Math.round(new Date().getTime()/1000);


function nule(gb_et_d){ return ((gb_et_d<10)?"0":"")+gb_et_d; }


function gb_elapse_time(){
if(gb_stoptime==1){ return; }
nsec=Math.round(new Date().getTime()/1000)-gb_time;
gb_et_ns=gb_et_s+nsec; gb_et_ps=parseInt((gb_et_s+nsec)/60); gb_et_ns-=gb_et_ps*60;
gb_et_nm=gb_et_m+gb_et_ps; gb_et_pm=parseInt((gb_et_m+gb_et_ps)/60); gb_et_nm-=gb_et_pm*60;
gb_et_nh=gb_et_h+gb_et_pm; gb_et_ph=parseInt((gb_et_h+gb_et_pm)/24);
document.getElementById("game_branch_stat_mytime").innerHTML=nule(gb_et_nh)+":"+nule(gb_et_nm)+":"+nule(gb_et_ns);
setTimeout("gb_elapse_time();",100);
}


gb_elapse_time();
</script>';
}


echo '<div style="width:704px;margin:auto;">
<div id="game_branch_win" class="game_branch_win" style="display:none;">
<div class="game_branch_win_level">������� '.$game_branch_set_level.' �������!</div>
<div class="game_branch_win_time">����� ����: <span id="game_branch_win_time">00:00:00</span></div>
<div class="game_branch_win_fbonus">����� �� �����������: <font>+<span id="game_branch_win_fbonus">0.00</span> �</font></div>
<div id="game_branch_win_rbonus" class="game_branch_win_rbonus" style="display:none;">����� �� ����� ������: <font>+<span id="game_branch_win_rbonus_s">0.00</span> �</font></div>
</div>
</div>';


echo '<table class="game_branch_table" style="'.$game_branch_padds.'" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td align="center" valign="middle">';


if($game_branch_status=='tostart'){
echo '<table class="game_branch_tostart_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td>
<div class="game_branch_tostart_info">';
if($mydm['up_m']<$game_branch_up_m){
echo '������������ �� ����� ����� ��, ��� �������� �� '.$game_branch_up_m.' ���.';
}
else{
echo '��������� � ������ �����.
<br>���������� ����� ������ � �������� �����.
<br>��������� �������� �� ������������� � �������.';
}
echo '</div>
</td>
</tr>
</table>';
}


if($game_branch_status=='notime'){
echo '<table class="game_branch_notime_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td>
<div class="game_branch_notime_info">
��������� ��������� ������� � �������� �����.
</div>
</td>
</tr>
</table>';
}


if($game_branch_status=='started'){


echo '<table class="game_branch_cells" align="center" cellpadding="0px" cellspacing="0px">';


$game_branch_ijs='';


for($i=1;$i<=$game_branch_height;$i++){
echo '<tr>';
for($j=1;$j<=$game_branch_width;$j++){
echo '<td>';
$game_branch_ijs.='gb_item['.$j.']['.$i.'][0]='.$gbi[$j][$i][0].';gb_item['.$j.']['.$i.'][1]='.$gbi[$j][$i][1].';';
if($j==$game_branch_energy_x && $i==$game_branch_energy_y){
echo '<div id="game_branch_i_'.$j.'_'.$i.'" class="game_branch_'.$gbi[$j][$i][0].'_'.$gbi[$j][$i][1].'_2" onclick="game_branch_turn('.$j.','.$i.');"></div>';
}
else{
echo '<div id="game_branch_i_'.$j.'_'.$i.'" class="game_branch_'.$gbi[$j][$i][0].'_'.$gbi[$j][$i][1].'_0" onclick="game_branch_turn('.$j.','.$i.');"></div>';
}
echo '</td>';
}
echo '</tr>';
}


echo '</table>';
}


echo '
</td>
</tr>
</table>';


if($game_branch_show==1){
echo '
<table class="game_branch_rates_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td class="game_branch_rate_title"><font id="gbr_word_1" style="display:block;">��������� ��������</font><font id="gbr_word_2" style="display:none;">������ �������</font></td>
<td class="game_branch_rate_button"><div id="gbr_button_1" style="display:block;" onclick="gbr_change();">������ �������</div><div id="gbr_button_2" style="display:none;" onclick="gbr_change();">��������� ��������</div></td>
</tr>
</table>


<div class="game_branch_rate_div">
<div id="gbr_div_1" style="display:block;">';


foreach($game_branch_lasts as $game_branch_rm){
$t_seconds=$game_branch_rm[3];
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.=':'; $t_m.=':';
echo '<div class="game_branch_rate_div_cont">
<table class="game_branch_rate_table" align="center" cellpadding="0px" cellspacing="10px">
<tr>
<td><img class="game_branch_rate_avatar" src="'.$game_branch_rm[0].'"></td>
<td><div class="game_branch_rate_login">'.$game_branch_rm[1].'</div></td>
<td><div class="game_branch_rate_level_num">'.$game_branch_rm[2].'</div></td>
<td><div class="game_branch_rate_level_word">�������</div></td>
<td><div class="game_branch_rate_time_i">&nbsp;</div></td>
<td><div class="game_branch_rate_time_w">'.$t_h.$t_m.$t_s.'</div></td>
<td><div class="game_branch_rate_sum_i">&nbsp;</div></td>
<td><div class="game_branch_rate_sum_a">'.$game_branch_rm[4].'</div></td>
</tr>
</table>
</div>';
}


echo '
</div>
<div id="gbr_div_2" style="display:none;">';


for($n=10;$n!=0;$n--){
if(!empty($game_branch_tops[$n])){
$t_seconds=$game_branch_tops[$n][2];
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.=':'; $t_m.=':';
echo '<div class="game_branch_tops_div_cont">
<table class="game_branch_tops_table" align="center" cellpadding="0px" cellspacing="10px">
<tr>
<td><img class="game_branch_tops_avatar" src="'.$game_branch_tops[$n][0].'"></td>
<td><div class="game_branch_tops_login">'.$game_branch_tops[$n][1].'</div></td>
<td><div class="game_branch_tops_level_num">'.$n.'</div></td>
<td><div class="game_branch_tops_level_word">�������</div></td>
<td><div class="game_branch_tops_time_i">&nbsp;</div></td>
<td><div class="game_branch_tops_time_w">'.$t_h.$t_m.$t_s.'</div></td>
</tr>
</table>
</div>';
}
}


echo '
</div>
</div>';
}


echo '
</div>


<style>
::selection {background:none;}
</style>


<audio id="game_branch_turn" preload>
<source src="/games/branch/sounds/game_branch_turn.mp3" type="audio/mpeg">
</audio>


<audio id="game_branch_computer" preload>
<source src="/games/branch/sounds/game_branch_computer.mp3" type="audio/mpeg">
</audio>


<audio id="game_branch_finished" preload loop>
<source src="/games/branch/sounds/game_branch_finished.mp3" type="audio/mpeg">
</audio>';


echo '
<script type="text/javascript">


var gbr_dis=1;
var gbr_dis_a=1;
var gbr_dis_b=2;


function gbr_change(){
document.getElementById("gbr_word_"+gbr_dis_a).style.display="none";
document.getElementById("gbr_word_"+gbr_dis_b).style.display="block";
document.getElementById("gbr_button_"+gbr_dis_a).style.display="none";
document.getElementById("gbr_button_"+gbr_dis_b).style.display="block";
document.getElementById("gbr_div_"+gbr_dis_a).style.display="none";
document.getElementById("gbr_div_"+gbr_dis_b).style.display="block";
if(gbr_dis==1){ gbr_dis=2; gbr_dis_a=2; gbr_dis_b=1; return; }
if(gbr_dis==2){ gbr_dis=1; gbr_dis_a=1; gbr_dis_b=2; }
}


function gb_sound_toggle(){
if(gb_sound==1){ gb_sound=0; }
else{ gb_sound=1; }
document.cookie="branch_sound="+gb_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+gb_sound;
}


</script>
';



if($game_branch_status=='started'){


echo '<script type="text/javascript">


var gb_types=new Array();
gb_types[0]=new Array();
gb_types[0][1]=new Array("1");
gb_types[0][2]=new Array("2");
gb_types[0][3]=new Array("3");
gb_types[0][4]=new Array("4");
gb_types[1]=new Array();
gb_types[1][1]=new Array(1,3);
gb_types[1][2]=new Array(2,4);
gb_types[2]=new Array();
gb_types[2][1]=new Array(1,2);
gb_types[2][2]=new Array(2,3);
gb_types[2][3]=new Array(3,4);
gb_types[2][4]=new Array(1,4);
gb_types[3]=new Array();
gb_types[3][1]=new Array(1,2,4);
gb_types[3][2]=new Array(1,2,3);
gb_types[3][3]=new Array(2,3,4);
gb_types[3][4]=new Array(1,3,4);


var gb_width='.$game_branch_width.';
var gb_height='.$game_branch_height.';


var gb_e_x='.$game_branch_energy_x.';
var gb_e_y='.$game_branch_energy_y.';


var gb_item=new Array();


var gb_in=0;
var gb_im=0;
var gb_n=0;
var gb_x=1;
var gb_y=1;
var gb_ofind=0;
var gb_turn_sound=0;
var gb_finished=0;
var gb_line="";


// ____________________ ������� ������ ������ ����


var gb_item=new Array();
for(gb_in=1;gb_in<gb_width+1;gb_in++){
gb_item[gb_in]=new Array();
for(gb_im=1;gb_im<gb_height+1;gb_im++){
gb_item[gb_in][gb_im]=new Array();
gb_item[gb_in][gb_im][2]=0;
}
}


// ____________________ ��������� ������ ����������


'.$game_branch_ijs.'


// ____________________ ������ ���


gb_item[gb_e_x][gb_e_y][2]=2;


var gb_nxx=0;
var gb_nyy=0;


function game_branch_turn(xx,yy){
if(gb_finished==1){
return;
}
gb_nxx=xx;
gb_nyy=yy;


gb_type=gb_item[xx][yy][0];
gb_origin=gb_item[xx][yy][1];
gb_origin++;
if((gb_type==1 && gb_origin==3) || (gb_type!=1 && gb_origin==5)){ gb_origin=1; }


gb_item[gb_nxx][gb_nyy][1]=gb_origin;
gb_item[gb_nxx][gb_nyy][2]=0;


document.getElementById("game_branch_i_"+gb_nxx+"_"+gb_nyy).className="game_branch_"+gb_type+"_"+gb_origin+"_"+gb_item[gb_nxx][gb_nyy][2];


document.getElementById("game_branch_turn").currentTime=0;
if(gb_sound==1){ document.getElementById("game_branch_turn").play(); }


game_branch_start();
}





function game_branch_start(){


// ____________________ �������� ����
for(gb_in=1;gb_in<gb_width+1;gb_in++){
for(gb_im=1;gb_im<gb_height+1;gb_im++){
gb_item[gb_in][gb_im][3]=0;
}
}


// ____________________ ������ �������� ���
gb_item[gb_e_x][gb_e_y][3]=1;


game_branch_energy();
}




function game_branch_energy(){


// ____________________ ���� ����� ����������


for(gb_x=1;gb_x<gb_width+1;gb_x++){
for(gb_y=1;gb_y<gb_height+1;gb_y++){
if(gb_item[gb_x][gb_y][3]==1){ continue; }


// ____________________ ��� �����
gb_ofind=0;


if(gb_x-1>0){
if(gb_item[gb_x-1][gb_y][3]==1){


for(gb_n=0;gb_n<gb_types[gb_item[gb_x-1][gb_y][0]][gb_item[gb_x-1][gb_y][1]].length;gb_n++){
if(gb_types[gb_item[gb_x-1][gb_y][0]][gb_item[gb_x-1][gb_y][1]][gb_n]==3){
gb_ofind=1;
break;
}
}


if(gb_ofind==1){
for(gb_n=0;gb_n<gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]].length;gb_n++){
if(gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]][gb_n]==1){
gb_item[gb_x][gb_y][3]=1;
game_branch_energy();
return;
}}}}}


// ____________________ ��� ������
gb_ofind=0;


if(gb_y-1>0){
if(gb_item[gb_x][gb_y-1][3]==1){


for(gb_n=0;gb_n<gb_types[gb_item[gb_x][gb_y-1][0]][gb_item[gb_x][gb_y-1][1]].length;gb_n++){
if(gb_types[gb_item[gb_x][gb_y-1][0]][gb_item[gb_x][gb_y-1][1]][gb_n]==4){
gb_ofind=1;
break;
}
}


if(gb_ofind==1){
for(gb_n=0;gb_n<gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]].length;gb_n++){
if(gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]][gb_n]==2){
gb_item[gb_x][gb_y][3]=1;
game_branch_energy();
return;
}}}}}


// ____________________ ��� ������
gb_ofind=0;


if(gb_x+1<=gb_width){
if(gb_item[gb_x+1][gb_y][3]==1){


for(gb_n=0;gb_n<gb_types[gb_item[gb_x+1][gb_y][0]][gb_item[gb_x+1][gb_y][1]].length;gb_n++){
if(gb_types[gb_item[gb_x+1][gb_y][0]][gb_item[gb_x+1][gb_y][1]][gb_n]==1){
gb_ofind=1;
break;
}
}


if(gb_ofind==1){
for(gb_n=0;gb_n<gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]].length;gb_n++){
if(gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]][gb_n]==3){
gb_item[gb_x][gb_y][3]=1;
game_branch_energy();
return;
}}}}}


// ____________________ ��� �����
gb_ofind=0;


if(gb_y+1<=gb_height){
if(gb_item[gb_x][gb_y+1][3]==1){


for(gb_n=0;gb_n<gb_types[gb_item[gb_x][gb_y+1][0]][gb_item[gb_x][gb_y+1][1]].length;gb_n++){
if(gb_types[gb_item[gb_x][gb_y+1][0]][gb_item[gb_x][gb_y+1][1]][gb_n]==2){
gb_ofind=1;
break;
}
}


if(gb_ofind==1){
for(gb_n=0;gb_n<gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]].length;gb_n++){
if(gb_types[gb_item[gb_x][gb_y][0]][gb_item[gb_x][gb_y][1]][gb_n]==4){
gb_item[gb_x][gb_y][3]=1;
game_branch_energy();
return;
}}}}}


}
}




gb_turn_sound=0;
gb_finished=1;


for(gb_in=1;gb_in<gb_width+1;gb_in++){
for(gb_im=1;gb_im<gb_height+1;gb_im++){
if(gb_item[gb_in][gb_im][3]==0){
gb_finished=0;
}
if(gb_item[gb_in][gb_im][0]==0 && gb_item[gb_in][gb_im][2]==0 && gb_item[gb_in][gb_im][3]==1){
gb_turn_sound=1;
}
if(gb_item[gb_in][gb_im][2]!=gb_item[gb_in][gb_im][3]){
gb_item[gb_in][gb_im][2]=gb_item[gb_in][gb_im][3];
document.getElementById("game_branch_i_"+gb_in+"_"+gb_im).className="game_branch_"+gb_item[gb_in][gb_im][0]+"_"+gb_item[gb_in][gb_im][1]+"_"+gb_item[gb_in][gb_im][3];
}
}
}


document.getElementById("game_branch_i_"+gb_e_x+"_"+gb_e_y).className="game_branch_"+gb_item[gb_e_x][gb_e_y][0]+"_"+gb_item[gb_e_x][gb_e_y][1]+"_2";


if(gb_turn_sound==0){
document.getElementById("game_branch_turn").currentTime=0;
if(gb_sound==1){ document.getElementById("game_branch_turn").play(); }
}
else{
document.getElementById("game_branch_computer").currentTime=0;
if(gb_sound==1){ document.getElementById("game_branch_computer").play(); }
}


if(gb_finished==1){
if(gb_sound==1){ document.getElementById("game_branch_finished").play(); }
for(gb_in=1;gb_in<gb_height+1;gb_in++){
for(gb_im=1;gb_im<gb_width+1;gb_im++){
gb_line+=gb_item[gb_im][gb_in][1];
}
}
game_branch_send();
}


}


game_branch_start();


</script>';


echo '
<script type="text/javascript">


function game_branch_send() {


var game_branch_vars="gb_line="+gb_line;
var game_branch_req=new XMLHttpRequest();
game_branch_req.onreadystatechange=function() {
if(game_branch_req.readyState==4){
if(game_branch_req.status==200){
eval(game_branch_req.responseText);
}
else{
setTimeout("game_branch_send();",5000);
}
}
}
game_branch_req.open("POST","/games/branch/branch_ajax.php",true);
game_branch_req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
game_branch_req.send(game_branch_vars);
}


</script>
';


}


?>
