<?php


require_once('../../config.php');


if(empty($game_branch_m)){ echo '������ ��������'; exit; }


require_once('branch_config.php');


// �� ������, ���� �������� ���������� �������. ��� ������� 20, � ����� ������� 5. ������ ������ ��������� �������
if($mydm['branch_level']>sizeof($game_branch_level)-2){ $mydm['branch_level']=0; }


$game_branch_time=$game_branch_time*60;


if(empty($u_id)){ echo 'window.location="/login";'; exit; }
if(empty($_POST['gb_line'])){ exit; }
if(!isset($mydm['branch_level'])){ exit; }
$mydm['branch_level']+=1;


if(empty($_SESSION['branch_stime'])){ echo 'alert("��� ������");'; exit; }


if($mydm['branch_time']+$game_branch_time>$time){ echo 'alert("����� �� �������");'; exit; }
if(empty($_SESSION['branch_stime'])){ echo 'alert("���� �� ������");'; exit; }


$gb_line=$_POST['gb_line'];
$gb_line=preg_replace('#[^0-9]+#','',$gb_line);


if(empty($gb_line) || strlen($gb_line)>300){ echo 'alert("������������ ����� $gb_line");'; exit; }


if(empty($_SESSION['branch'])){ echo 'alert("��� ������ branch");'; exit; }


$game_branch_set_level=$mydm['branch_level'];
$game_branch_width=$game_branch_level[$game_branch_set_level][0]; // ������
$game_branch_height=$game_branch_level[$game_branch_set_level][1]; // ������


$gbi=array();
$gbrep=$_SESSION['branch'];


$n=0;
for($i=1;$i<=$game_branch_height;$i++){
for($j=1;$j<=$game_branch_width;$j++){
$gbi[$j][$i]=array($gbrep[$n],$gbrep[$n+1]);
$n+=2;
}
}


// ���������� ������


if(empty($gbi)){ echo 'alert("�� ���� ������������� $gbi");'; exit; }


$game_branch_line='';


for($i=1;$i<=$game_branch_height;$i++){
for($j=1;$j<=$game_branch_width;$j++){
$game_branch_line.=$gbi[$j][$i][1];
}
}


$user_answer=array();
for($n=0;$n<strlen($gb_line);$n++){ $user_answer[]=$gb_line[$n]; }
if(empty($user_answer) || sizeof($user_answer)>300 || sizeof($user_answer)!=$game_branch_width*$game_branch_height){ echo 'alert("������������ ����� $user_answer");'; exit; }


$computed=array();
for($n=0;$n<strlen($game_branch_line);$n++){ $computed[]=$game_branch_line[$n]; }
if(empty($computed) || sizeof($computed)>300 || sizeof($computed)!=$game_branch_width*$game_branch_height){ echo 'alert("������������ ����� $computed");'; exit; }


$solved=0;
$wrong=0;


for($n=0;$n<strlen($gb_line);$n++){
if($gb_line[$n]!=$computed[$n]){ $wrong++; }
}


if($wrong<=floor($game_branch_width*$game_branch_height*0.4)){
$solved=1;
}


if($solved==0){ echo 'alert("�� �������");'; exit; }


$game_branch_ratesq=mysqli_query($db,"SELECT top,last FROM games WHERE name='branch' LIMIT 1") or die('cant select games');
$game_branch_ratesm=mysqli_fetch_assoc($game_branch_ratesq);


if(!isset($game_branch_ratesm['top'])){ exit; }


$game_branch_win_time=$time-$_SESSION['branch_stime'];


$t_seconds=$game_branch_win_time;
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.=':'; $t_m.=':';
$game_branch_win_time_w=$t_h.$t_m.$t_s;


$game_branch_win_fbonus=$game_branch_level[$game_branch_set_level][2];


$game_branch_tops=array();
eval($game_branch_ratesm['top']);


$game_branch_win_rbonus=0;


if(!isset($game_branch_tops[$game_branch_set_level]) || $game_branch_tops[$game_branch_set_level][2]>$game_branch_win_time){
$game_branch_win_rbonus=$game_branch_level[$game_branch_set_level][3];
$game_branch_tops[$game_branch_set_level]=array($mydm['avatar'],$mydm['login'],$game_branch_win_time);
}


$game_branch_up_tops='';


foreach($game_branch_tops as $gbn=>$gbv){
$game_branch_up_tops.=$gbn.'=>array(\''.$gbv[0].'\',\''.$gbv[1].'\','.$gbv[2].'),';
}


$game_branch_up_tops=rtrim($game_branch_up_tops,',');
$game_branch_up_tops='$game_branch_tops=array('.$game_branch_up_tops.');';


$game_branch_r=$mydm['branch_r']+$game_branch_win_fbonus+$game_branch_win_rbonus;


// ____________________ ������ ��������� ��� ____________________


$game_branch_lasts=array();
eval($game_branch_ratesm['last']);
$game_branch_up_lasts='array(\''.$mydm['avatar'].'\',\''.$mydm['login'].'\','.$game_branch_set_level.','.$game_branch_win_time.','.$game_branch_r.'),';
for($n=0;$n!=4;$n++){
if(!empty($game_branch_lasts[$n])){
$game_branch_up_lasts.='array(\''.$game_branch_lasts[$n][0].'\',\''.$game_branch_lasts[$n][1].'\','.$game_branch_lasts[$n][2].','.$game_branch_lasts[$n][3].','.$game_branch_lasts[$n][4].'),';
}
}


$game_branch_up_lasts=rtrim($game_branch_up_lasts,',');
$game_branch_up_lasts='$game_branch_lasts=array('.$game_branch_up_lasts.');';


// ____________________ ������� ____________________


if($game_branch_set_level>sizeof($game_branch_level)-2){ $game_branch_set_level=0; }


mysqli_query($db,"UPDATE users SET $game_branch_path=$game_branch_path+".($game_branch_win_fbonus+$game_branch_win_rbonus).",games_r=games_r+".($game_branch_win_fbonus+$game_branch_win_rbonus).",branch_level='$game_branch_set_level',branch_r='$game_branch_r',branch_time=$time WHERE uid='$u_id' LIMIT 1") or die('cant update users');
mysqli_query($db,"UPDATE games SET count=count+1,sum=sum+".($game_branch_win_fbonus+$game_branch_win_rbonus).",top=\"$game_branch_up_tops\",last=\"$game_branch_up_lasts\" WHERE name='branch' LIMIT 1") or die('cant update games');
mysqli_query($db,"UPDATE data SET games_c=games_c+1,games_r=games_r+".($game_branch_win_fbonus+$game_branch_win_rbonus)) or die('cant update data');
$_SESSION['branch']='';
$_SESSION['branch_stime']=0;


echo '
gb_stoptime=1;
t_tos_start=Math.round(new Date().getTime()/1000);
t_tos_timer();
document.getElementById("game_branch_cash").innerHTML="'.number_format($game_branch_r,4,'.','').'";
document.getElementById("game_branch_stat_lose").style.display="none";
document.getElementById("game_branch_stat_tosttime").style.display="block";
document.getElementById("game_branch_stat_mytime").innerHTML="'.$game_branch_win_time_w.'";
document.getElementById("game_branch_win_time").innerHTML="'.$game_branch_win_time_w.'";
document.getElementById("game_branch_win_fbonus").innerHTML="'.number_format($game_branch_win_fbonus,4,'.','').'";
';
if($game_branch_win_rbonus!=0){
echo 'document.getElementById("game_branch_win_rbonus").style.display="block";
document.getElementById("game_branch_win_rbonus_s").innerHTML="'.number_format($game_branch_win_rbonus,4,'.','').'";
';
}
echo 'setTimeout(\'document.getElementById("game_branch_win").style.display="block";\',2000);';


$mydm[$game_branch_path]+=$game_branch_win_fbonus+$game_branch_win_rbonus;
$mydm[$game_branch_path]=number_format($mydm[$game_branch_path],4,'.','');


echo 'document.getElementById("my_'.$game_branch_path.'").innerHTML="'.$mydm[$game_branch_path].'";
document.getElementById("'.$game_branch_path.'_coin").style.display="block";
setTimeout(\'document.getElementById("'.$game_branch_path.'_coin").style.display="none";\',3000);';


?>
