function gb_draw_effects(){


//____________________ DRAW BUBBLES ____________________


for(var n=0;n<gb_bubbles.length;n++){
gb_bubbles[n].x+=gb_bubbles[n].px;
gb_bubbles[n].y+=gb_bubbles[n].py;
gb_bubbles[n].live--;
ctx.drawImage(gb_pic_things,200,240,14,14,gb_bubbles[n].x,gb_bubbles[n].y,gb_bubbles[n].size,gb_bubbles[n].size);
if(gb_bubbles[n].live<0){
gb_bubbles.splice(n,1);
n=-1;
}
}


//____________________ DRAW CRASH BALLS ____________________


for(var n=0;n<gb_crash_timer.length;n++){
if(gb_crash_timer[n][2]>0){
gb_crash_timer[n][2]--;
}
else{
gb_crash.push(new gb_crash_gen(gb_crash_timer[n][0],gb_crash_timer[n][1],gb_crash_timer[n][3]));
gb_crash_timer.splice(n,1);
n=-1;
}
}


for(var n=0;n<gb_crash.length;n++){
gb_crash[n].x+=gb_crash[n].px;
gb_crash[n].y+=gb_crash[n].py;
gb_crash[n].live--;
ctx.beginPath();
ctx.arc(gb_crash[n].x,gb_crash[n].y,gb_crash[n].size,0,2*Math.PI,true);
ctx.fillStyle=gb_crash_color[gb_crash[n].color];
ctx.fill();
if(gb_crash[n].live<0){
gb_crash.splice(n,1);
n=-1;
}
}


//____________________ DRAW BOMB BOOM ____________________


for(var n=0;n<gb_boom.length;n++){
gb_boom[n].x+=gb_boom[n].px;
gb_boom[n].y+=gb_boom[n].py;
gb_boom[n].live--;
ctx.beginPath();
ctx.arc(gb_boom[n].x,gb_boom[n].y,gb_boom[n].size,0,2*Math.PI,true);
ctx.fillStyle=gb_boom[n].color;
ctx.fill();
if(gb_boom[n].live<0){
gb_boom.splice(n,1);
n=-1;
}
}


for(var n=0;n<gb_boom_violet.length;n++){
if(gb_boom_violet[n].w==1){
gb_boom_violet[n].size+=24;
gb_boom_violet[n].x-=12;
gb_boom_violet[n].y-=12;
}
else{
gb_boom_violet[n].size-=24;
gb_boom_violet[n].x+=12;
gb_boom_violet[n].y+=12;
}
gb_boom_violet[n].live--;
ctx.drawImage(gb_pic_things,280,0,280,280,gb_boom_violet[n].x,gb_boom_violet[n].y,gb_boom_violet[n].size,gb_boom_violet[n].size);
if(gb_boom_violet[n].live<20){
gb_boom_violet[n].w=0;
}
if(gb_boom_violet[n].live<0){
gb_boom_violet.splice(n,1);
n=-1;
}
}


//____________________ DRAW FIREBALL BOOM ____________________


for(var n=0;n<gb_fbb.length;n++){
if(gb_fbb[n].w==1){
gb_fbb[n].size+=10;
gb_fbb[n].x-=5;
gb_fbb[n].y-=5;
}
else{
gb_fbb[n].size-=10;
gb_fbb[n].x+=5;
gb_fbb[n].y+=5;
}
gb_fbb[n].live--;
ctx.drawImage(gb_pic_things,560,0,270,270,gb_fbb[n].x,gb_fbb[n].y,gb_fbb[n].size,gb_fbb[n].size);
if(gb_fbb[n].live<20){
gb_fbb[n].w=0;
}
if(gb_fbb[n].live<0){
gb_fbb.splice(n,1);
n=-1;
}
}


//____________________ DRAW PRICE ____________________


for(var n=0;n<gb_price.length;n++){
gb_price[n].x+=gb_price_move_x[gb_price[n].w];
gb_price[n].w++;
if(gb_price[n].w>19){
gb_price[n].w=0;
}
gb_price[n].y-=0.5;
gb_price[n].live--;
ctx.globalAlpha=0.9;
ctx.drawImage(gb_pic_things,(gb_price[n].num-1)*40,330,40,12,gb_price[n].x,gb_price[n].y,40,12);
ctx.globalAlpha=1;
if(gb_price[n].live<0){
gb_price.splice(n,1);
n=-1;
}
}


//____________________ DRAW COMBO ____________________


for(var n=0;n<gb_combo.length;n++){
gb_combo[n].x+=gb_combo_move_x[gb_combo[n].w];
gb_combo[n].w++;
if(gb_combo[n].w>19){
gb_combo[n].w=0;
}
gb_combo[n].y-=0.5;
gb_combo[n].live--;
//ctx.globalAlpha=0.9;
//ctx.drawImage(gb_pic_things,600,284,80,22,gb_combo[n].x,gb_combo[n].y,80,22);
//ctx.drawImage(gb_pic_things,(gb_combo[n].num-1)*34,310,34,20,gb_combo[n].x+23,gb_combo[n].y+22,34,20);
//ctx.drawImage(gb_pic_things,(gb_combo[n].num-1)*80,350,80,20,gb_combo[n].x,gb_combo[n].y+42,80,20);
//ctx.globalAlpha=1;
if(gb_combo[n].live<0){
gb_combo.splice(n,1);
n=-1;
}
}


//____________________ DRAW RATE WORDS ____________________


for(var n=0;n<gb_rate.length;n++){
gb_rate[n].x+=gb_rate_move_x[gb_rate[n].w];
gb_rate[n].w++;
if(gb_rate[n].w>19){
gb_rate[n].w=0;
}
gb_rate[n].y-=0.5;
gb_rate[n].live--;
//ctx.globalAlpha=0.9;
//ctx.drawImage(gb_pic_things,gb_rate_crop_x[gb_rate[n].num],280,gb_rate_sizes[gb_rate[n].num],30,gb_rate[n].x,gb_rate[n].y,gb_rate_sizes[gb_rate[n].num],30);
//ctx.globalAlpha=1;
if(gb_rate[n].live<0){
gb_rate.splice(n,1);
n=-1;
}
}


//____________________ END ALL DRAWS 1 ____________________


}





function gb_draw_effects_2(){


//____________________ DRAW COIN-FIREBALL-WAVE ____________________


for(var n=0;n<gb_cfw.length;n++){
gb_cfw[n].spark_n++;
if(gb_cfw[n].spark_n>2){
gb_cfw[n].spark_n=0;
gb_spark.push(new gb_spark_node(gb_cfw[n].x,gb_cfw[n].y));
}
gb_cfw[n].x+=gb_cfw[n].ax;
gb_cfw[n].y+=gb_cfw[n].ay;
ctx.drawImage(gb_pic_things,gb_cfw[n].crop_x+gb_cfw[n].p*32,gb_cfw[n].crop_y,gb_cfw[n].sx,gb_cfw[n].sy,gb_cfw[n].x,gb_cfw[n].y,gb_cfw[n].sx,gb_cfw[n].sy);
if(gb_cfw[n].w>0){
gb_cfw[n].n++;
if(gb_cfw[n].p>gb_cfw[n].w){
gb_cfw[n].p=0;
gb_cfw[n].n=0;
}
if(gb_cfw[n].n>2){
gb_cfw[n].n=0;
gb_cfw[n].p++;
}
}
if(gb_cfw[n].y>gb_cfw[n].limit_y){
if(gb_cfw[n].type==1){ gb_coins_amount++; gb_ca_str=gb_coins_amount.toString(); gb_ca_len=gb_ca_str.length; }
if(gb_cfw[n].type==2){ gb_fireball_amount++; gb_fba_str=gb_fireball_amount.toString(); gb_fba_len=gb_fba_str.length; }
if(gb_cfw[n].type==3){ gb_wave_amount++; gb_wa_str=gb_wave_amount.toString(); gb_wa_len=gb_wa_str.length; }
gb_cfw.splice(n,1);
n=-1;
}
}


//____________________ DRAW SPARK ____________________


for(var n=0;n<gb_spark.length;n++){
ctx.drawImage(gb_pic_things,730,330,26,26,gb_spark[n].x,gb_spark[n].y,gb_spark[n].size,gb_spark[n].size);
gb_spark[n].size-=1;
if(gb_spark[n].size<1){
gb_spark.splice(n,1);
n=-1;
}
}


//____________________ DRAW CUTED BALLS ____________________


for(var n=0;n<gb_cuted.length;n++){
gb_cuted[n].y+=gb_cuted[n].s;
ctx.globalAlpha=gb_cuted[n].n/100;
ctx.drawImage(gb_pic_items,0,(gb_cuted[n].type-1)*32,32,31,gb_cuted[n].x,gb_cuted[n].y,32,31);
ctx.globalAlpha=1;


gb_cuted[n].n-=1;
if(gb_cuted[n].n<1){
gb_cuted.splice(n,1);
n=-1;
}
}



//____________________ END ALL DRAWS 2 ____________________


}
