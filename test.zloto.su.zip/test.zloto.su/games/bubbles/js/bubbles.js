

//____________________ SET COINS TO MAP ____________________


var gb_sctm=Math.floor(Math.random()*5)+1;
var gb_sctm_rnd=0;


for(var gb_nn=0;gb_nn!=gb_sctm;gb_nn++){
gb_sctm_rnd=Math.floor(Math.random()*(gb_all_balls.length-20))+10;
while(gb_all_balls[gb_sctm_rnd]==0 || gb_all_balls[gb_sctm_rnd]==19){
gb_sctm_rnd=Math.floor(Math.random()*(gb_all_balls.length-20))+10;
}
gb_all_balls[gb_sctm_rnd]=19;
}


//____________________ SET CHEST TO MAP ____________________


var gb_chest_rnd=Math.floor(Math.random()*(gb_all_balls.length-20))+10;


while(gb_all_balls[gb_chest_rnd]==0 || gb_all_balls[gb_chest_rnd]==19){
gb_chest_rnd=Math.floor(Math.random()*(gb_all_balls.length-20))+10;
}


gb_all_balls[gb_chest_rnd]=20;


//____________________ MAP GEN ____________________


function gb_map_node(gb_mnode_n,gb_y,gb_x,gb_t){
this.visited=false;
this.ant=0;
this.any=0;


if(gb_t==1){
this.type=gb_all_balls[gb_mnode_n];
}
else{
this.type=0;
}


if(gb_y%2==0){ this.x=gb_x*29+8; }
else{ this.x=gb_x*29+22; }
if(this.type==14){
this.w=0;
this.n=0.6;
}
if(this.type==18 || this.type==19 || this.type==20){
this.n=0;
this.time=Math.floor(Math.random()*11)*40+100;
}
}


for(var gb_y=0;gb_y<gb_height;gb_y++){
var gb_arr=[];
for(var gb_x=0;gb_x<gb_width;gb_x++){
gb_arr.push(new gb_map_node(gb_x+gb_y*9,gb_y,gb_x,1));
}
gb_map.push(gb_arr);
}


for(var gb_x=0;gb_x<gb_width;gb_x++){
if(gb_map[0][gb_x].type==21){
var gb_crown_x=gb_x;
}
}


//____________________ VARIABLES ____________________


var gb_stop=0;
var gb_mouse_x=0;
var gb_mouse_y=0;
var gb_radian=Math.PI/180;
var gb_angle=0;
var gb_pulse=0;
var gb_pulse_w=0;
var gb_can_shoot=0;
var gb_anim_shoot=-1;
var gb_reload=1;
var gb_ball=1;
var gb_temp_ball=Math.floor(Math.random()*7)+1;
var gb_ball_x=132;
var gb_ball_y=504;
var gb_shooted=0;
var gb_shoot_angle=0;
var gb_rot_cball=0;
var gb_size_cball=0;
var gb_size_cball_w=0;
var gb_score_amount=0;
var gb_temp_score=0;
var gb_wave_can=1;
var gb_wave_n=-1;
var gb_sa_str=gb_score_amount.toString();
var gb_sa_len=gb_sa_str.length;
var gb_ra_str=gb_record_amount.toString();
var gb_ra_len=gb_ra_str.length;
var gb_ca_str=gb_coins_amount.toString();
var gb_ca_len=gb_ca_str.length;
var gb_fba_str=gb_fireball_amount.toString();
var gb_fba_len=gb_fba_str.length;
var gb_wa_str=gb_wave_amount.toString();
var gb_wa_len=gb_wa_str.length;
var gb_la_str=gb_level.toString();
var gb_la_len=gb_la_str.length;
var gb_progress_h=gb_height;
var gb_progress_up=1;
var gb_m_top=gb_height-3;
var gb_m_bottom=gb_height-1;
var gb_move_down=120;
var gb_alert_on=0;
var gb_move_speed=0;
var gb_move_wave=0;
var gb_two_d=0;
var gb_move_mine=0;
var gb_bomber=0;
var gb_bomber_y=0;
var gb_bomber_x=0;
var gb_fb_bomber=0;
var gb_fb_bomber_y=0;
var gb_fb_bomber_x=0;
var gb_collide=0;
var gb_collide_x=0;
var gb_collide_y=0;
var gb_checking=0;
var gb_checking_x=0;
var gb_checking_y=0;
var gb_expand=0;
var gb_expand_color=0;
var gb_no_check=0;
var gb_change_ink=0;
var gb_find=0;
var gb_to_boom=[];
var gb_cut=0;
var gb_bind_top=0;
var gb_cutted_n=0;
var gb_touch_move=0;
var gb_combo_sec=0;
var gb_combo_n=0;
var gb_spec_balls=Math.floor(Math.random()*30)+30;


var gb_mci_n=-1;
var gb_mci_x=new Array(79,82,85,88,91,94,97,100,103,106,109,112,115,118,121,124,127,130);
var gb_mci_y=new Array(516,513,509,505,501,497,494,491,488,487,486,486,486,488,490,492,496,499);


var gb_an_1=new Array(-1,-2,-3,-4,-5,-6,-5,-4,-3,-2,-1);
var gb_an_2=new Array(-0.5,-1,-1.5,-2,-2.5,-3,-2.5,-2,-1.5,-1,-0.5);


var gb_bub_an=new Array(
-1,-2,-3,-4,
-3,-2,-1.5,-1,-0.5,0,
0.5,1,1.5,2,2.5,3,3.5,4,
3.5,3.0,2.5,2.0,1.5,1.0,0.5,0,
0.5,1,1.5,2,2.5,3,
2.5,2.0,1.5,1.0,0.5,0,
0.5,1,1.5,2,
1.5,1.0,0.5,0,
0.2,0.5,0.7,1,
0.7,0.5,0.2,0,
0.2,0.5,0.7,
0.5,0.2,0
);


var gb_bub_mx=0;
var gb_bub_my=0;
var gb_bub_h=0;


var gb_cannon_x=document.getElementById("game_bubbles_bg").offsetLeft+150;
var gb_cannon_y=document.getElementById("game_bubbles_bg").offsetTop+518;


var gb_lose_bn=0;


document.getElementById("game_bubbles_game_table").onclick=gb_shoot;
document.getElementById("game_bubbles_fireball_div").onclick=gb_fireball_set;
document.getElementById("game_bubbles_wave_div").onclick=gb_wave_set;


// ____________________ LOGIC ____________________
// ____________________ LOGIC ____________________
// ____________________ LOGIC ____________________


function gb_logic(){


ctx.clearRect(0,0,300,550);


//____________________ BALLS MOVES SPEED ____________________


if(gb_stop==0){


if(gb_combo_sec>0){
gb_combo_sec--;
}


if(gb_m_bottom*28-gb_top_y+gb_move_down+28<300){
gb_move_speed=0.5;
}


if(gb_m_bottom*28-gb_top_y+gb_move_down+28>=300){
gb_move_speed=0.1;
}


if(gb_m_bottom*28-gb_top_y+gb_move_down+28>=410){
gb_alert_on=1;
}
else{
gb_alert_on=0;
}


if(gb_m_bottom*28-gb_top_y+gb_move_down+28>435){
gb_move_speed=0.02;
}


if(gb_m_bottom*28-gb_top_y+gb_move_down+28>465){
gb_stop=1;
gb_move_speed=0;
gb_alert_on=0;


document.getElementById("gb_play_music").pause();
if(gb_sound==1){ document.getElementById("gb_lose_sound").play(); }


for(gb_my=gb_m_bottom;gb_my>gb_m_top-1;gb_my--){
for(gb_mx=0;gb_mx<9;gb_mx++){
if(gb_map[gb_my][gb_mx].type!=0){
gb_crash_timer.push([gb_my,gb_mx,gb_lose_bn*8+80,gb_map[gb_my][gb_mx].type]);
gb_lose_bn++;
}
}
}


setTimeout('document.getElementById("game_bubbles_lose").style.display="block";',1000);


}


if(gb_move_wave>0){
if(gb_move_wave>20){
gb_move_down-=2;
}
else if(gb_move_wave>10){
gb_move_down-=1;
}
else{
gb_move_down-=0.5;
}
gb_move_wave-=1;
}


if(gb_move_mine>0){
if(gb_move_mine>20){
gb_move_down+=1.5;
}
else if(gb_move_mine>10){
gb_move_down+=1;
}
else{
gb_move_down+=0.5;
}
gb_move_mine-=1;
}


if(gb_touch_move>0){
if(gb_touch_move>7){
gb_move_down-=0.2;
}
else if(gb_touch_move>5){
gb_move_down-=0.3;
}
else if(gb_touch_move>3){
gb_move_down-=0.4;
}
else{
gb_move_down-=0.5;
}
gb_touch_move--;
}


gb_move_down+=gb_move_speed;
}


//____________________ BALLS MOVES ____________________


for(gb_my=gb_m_top;gb_my<gb_m_bottom+1;gb_my++){
for(gb_mx=0;gb_mx<9;gb_mx++){
if(gb_map[gb_my][gb_mx].type!=0){


if(gb_map[gb_my][gb_mx].type==14){
if(gb_map[gb_my][gb_mx].w==0){
gb_map[gb_my][gb_mx].n+=0.005;
if(gb_map[gb_my][gb_mx].n>1){ gb_map[gb_my][gb_mx].w=1; }
}
else{
gb_map[gb_my][gb_mx].n-=0.005;
if(gb_map[gb_my][gb_mx].n<0.7){ gb_map[gb_my][gb_mx].w=0; }
}
ctx.globalAlpha=gb_map[gb_my][gb_mx].n;
ctx.drawImage(gb_pic_items,0,(gb_map[gb_my][gb_mx].type-1)*32,32,31,gb_map[gb_my][gb_mx].x,gb_my*28-gb_top_y+gb_move_down,32,31);
ctx.globalAlpha=1;
}


else if(gb_map[gb_my][gb_mx].type==18 || gb_map[gb_my][gb_mx].type==19 || gb_map[gb_my][gb_mx].type==20){
if(gb_map[gb_my][gb_mx].time>0 && gb_map[gb_my][gb_mx].n==0){
gb_map[gb_my][gb_mx].time--;
ctx.drawImage(gb_pic_items,0,(gb_map[gb_my][gb_mx].type-1)*32,32,31,gb_map[gb_my][gb_mx].x,gb_my*28-gb_top_y+gb_move_down,32,31);
}
else{


if(gb_bub_an[gb_map[gb_my][gb_mx].n]<0){
gb_bub_mx=Math.abs(gb_bub_an[gb_map[gb_my][gb_mx].n])/2;
gb_bub_my=-gb_bub_an[gb_map[gb_my][gb_mx].n]/2;
gb_bub_h=Math.abs(gb_bub_an[gb_map[gb_my][gb_mx].n]);
}
else{
gb_bub_mx=-gb_bub_an[gb_map[gb_my][gb_mx].n]/2;
gb_bub_my=-gb_bub_an[gb_map[gb_my][gb_mx].n]/2;
gb_bub_h=-gb_bub_an[gb_map[gb_my][gb_mx].n];
}


ctx.drawImage(gb_pic_items,0,(gb_map[gb_my][gb_mx].type-1)*32,32,31,gb_map[gb_my][gb_mx].x+gb_bub_mx,gb_my*28-gb_top_y+gb_move_down-gb_bub_my,32+gb_bub_an[gb_map[gb_my][gb_mx].n],31+gb_bub_h);
gb_map[gb_my][gb_mx].n++;
if(gb_map[gb_my][gb_mx].n>=gb_bub_an.length){
gb_map[gb_my][gb_mx].n=0;
gb_map[gb_my][gb_mx].time=Math.floor(Math.random()*11)*40+100;
}
}
}


else{
if(gb_map[gb_my][gb_mx].ant==1){
ctx.drawImage(gb_pic_items,0,(gb_map[gb_my][gb_mx].type-1)*32,32,31,gb_map[gb_my][gb_mx].x,gb_my*28-gb_top_y+gb_move_down+gb_an_1[gb_map[gb_my][gb_mx].any],32,31);
gb_map[gb_my][gb_mx].any++;
if(gb_map[gb_my][gb_mx].any>10){
gb_map[gb_my][gb_mx].ant=0;
gb_map[gb_my][gb_mx].any=0;
}
}
else if(gb_map[gb_my][gb_mx].ant==2){
ctx.drawImage(gb_pic_items,0,(gb_map[gb_my][gb_mx].type-1)*32,32,31,gb_map[gb_my][gb_mx].x,gb_my*28-gb_top_y+gb_move_down+gb_an_2[gb_map[gb_my][gb_mx].any],32,31);
gb_map[gb_my][gb_mx].any++;
if(gb_map[gb_my][gb_mx].any>10){
gb_map[gb_my][gb_mx].ant=0;
gb_map[gb_my][gb_mx].any=0;
}
}
else{
ctx.drawImage(gb_pic_items,0,(gb_map[gb_my][gb_mx].type-1)*32,32,31,gb_map[gb_my][gb_mx].x,gb_my*28-gb_top_y+gb_move_down,32,31);
}
}


}
}
}


//____________________ NEW TOP AND PROGRESS UP ____________________


if(gb_m_top>0 && gb_m_top*28-gb_top_y+gb_move_down>40){
gb_m_top--;
gb_cut=1;
if(gb_m_top==0){
gb_progress_up=64;
}
else{
gb_progress_up=64/100*Math.floor(100-(gb_m_top/gb_progress_h)*100);
}
}


//____________________ SHOOT ____________________


if(gb_shooted==1){


gb_ball_x+=Math.cos(gb_shoot_angle)*8;
gb_ball_y+=Math.sin(gb_shoot_angle)*8;


if(gb_ball_x<=0){
gb_ball_x=0;
gb_shoot_angle=gb_shoot_angle*180/Math.PI;
gb_shoot_angle=360-(gb_shoot_angle-180);
gb_shoot_angle=gb_shoot_angle*Math.PI/180;
if(gb_sound==1){ document.getElementById("gb_border").play(); }
}


if(gb_ball_x>=265){
gb_ball_x=264;
gb_shoot_angle=gb_shoot_angle*180/Math.PI;
gb_shoot_angle=180+(360-gb_shoot_angle);
gb_shoot_angle=gb_shoot_angle*Math.PI/180;
if(gb_sound==1){ document.getElementById("gb_border").play(); }
}


if(gb_ball_y<0 || gb_ball_y>540){
gb_shooted=0;
gb_reload=1;
}


ctx.drawImage(gb_pic_items,0,(gb_ball-1)*32,32,32,gb_ball_x,gb_ball_y,32,32);
}


//____________________ COLLISION CHECK ____________________


if(gb_shooted==1){


gb_cut=0;


for(var gb_cy=gb_m_bottom;gb_cy>gb_m_top-1;gb_cy--){
for(var gb_cx=0;gb_cx<9;gb_cx++){
if(gb_map[gb_cy][gb_cx].type!=0){
gb_two_d=Math.sqrt(Math.pow(gb_map[gb_cy][gb_cx].x-gb_ball_x,2)+Math.pow(gb_cy*28-gb_top_y+gb_move_down-gb_ball_y,2));


if(gb_two_d<20){


gb_cut=1;


for(gb_my=gb_m_top;gb_my<gb_m_bottom+1;gb_my++){
for(gb_mx=0;gb_mx<9;gb_mx++){
gb_map[gb_my][gb_mx].visited=false;
}
}


//____________________ BALL TYPE - BUBBLE ____________________


if(gb_map[gb_cy][gb_cx].type==18){
gb_bubbles_gen(gb_cy,gb_cx,1);
}


//____________________ BALL TYPE - BUBBLE COIN ____________________


else if(gb_map[gb_cy][gb_cx].type==19){
gb_bubbles_gen(gb_cy,gb_cx,0);
gb_cfw.push(new gb_cfw_node(gb_map[gb_cy][gb_cx].x,gb_cy*28-gb_top_y+gb_move_down,1));
}


//____________________ BALL TYPE - BUBBLE CHEST ____________________


else if(gb_map[gb_cy][gb_cx].type==20){
gb_bubbles_gen(gb_cy,gb_cx,0);
gb_cfw.push(new gb_cfw_node(gb_map[gb_cy][gb_cx].x,gb_cy*28-gb_top_y+gb_move_down,Math.floor(Math.random()*2)+2));
}


//____________________ BALL TYPE - MINE ____________________


else if(gb_map[gb_cy][gb_cx].type==14){
gb_move_mine=50;
gb_map[gb_cy][gb_cx].type=0;
if(gb_sound==1){ document.getElementById("gb_move_down_mine").play(); }
gb_shooted=0;
gb_reload=1;
gb_cy=-1;
gb_cx=10;
}


//____________________ BALL TYPE DEATH ____________________


else if(gb_map[gb_cy][gb_cx].type==13){


if(gb_ball==9){
gb_bomber=1;
gb_bomber_y=gb_cy;
gb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==12){
gb_fb_bomber=1;
gb_fb_bomber_y=gb_cy;
gb_fb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else{
gb_stop=1;
gb_move_speed=0;
gb_alert_on=0;


gb_shooted=0;
gb_reload=1;
gb_cy=-1;
gb_cx=10;


document.getElementById("gb_play_music").pause();
if(gb_sound==1){ document.getElementById("gb_horror").play(); }


for(gb_my=gb_m_bottom;gb_my>gb_m_top-1;gb_my--){
for(gb_mx=0;gb_mx<9;gb_mx++){
if(gb_map[gb_my][gb_mx].type!=0){
gb_crash_timer.push([gb_my,gb_mx,gb_lose_bn*8+50,gb_map[gb_my][gb_mx].type]);
gb_lose_bn++;
}
}
}


setTimeout('document.getElementById("game_bubbles_lose").style.display="block";',1500);
}


}


//____________________ BALL TYPE - BRICK OR BETONE ____________________


else if(gb_map[gb_cy][gb_cx].type==15 || gb_map[gb_cy][gb_cx].type==17){


if(gb_ball==9){
gb_bomber=1;
gb_bomber_y=gb_cy;
gb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==12){
gb_fb_bomber=1;
gb_fb_bomber_y=gb_cy;
gb_fb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==8){
if(gb_sound==1){ document.getElementById("gb_brick_collide").play(); }
gb_shooted=0;
gb_reload=1;
gb_cy=-1;
gb_cx=10;
}


else{
if(gb_sound==1){ document.getElementById("gb_brick_collide").play(); }
gb_collide=1;
gb_collide_x=gb_cx;
gb_collide_y=gb_cy;


gb_cy=-1;
gb_cx=10;
}


}


//____________________ BALL TYPE - WOOD ____________________


else if(gb_map[gb_cy][gb_cx].type==16){


if(gb_ball==9){
gb_bomber=1;
gb_bomber_y=gb_cy;
gb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==12){
gb_fb_bomber=1;
gb_fb_bomber_y=gb_cy;
gb_fb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==8){
gb_crash_timer.push([gb_cy,gb_cx,0,gb_map[gb_cy][gb_cx].type]);
gb_map[gb_cy][gb_cx].type=0;
}


else{
if(gb_sound==1){ document.getElementById("gb_wood_collide").play(); }
gb_collide=1;
gb_collide_x=gb_cx;
gb_collide_y=gb_cy;
gb_cy=-1;
gb_cx=10;
}


}


//____________________ BALL TYPE - EXPAND ____________________


else if(gb_map[gb_cy][gb_cx].type>21 && gb_map[gb_cy][gb_cx].type<29){


if(gb_ball==9){
gb_bomber=1;
gb_bomber_y=gb_cy;
gb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==12){
gb_fb_bomber=1;
gb_fb_bomber_y=gb_cy;
gb_fb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==8){
gb_crash_timer.push([gb_cy,gb_cx,0,gb_map[gb_cy][gb_cx].type]);
gb_map[gb_cy][gb_cx].type=0;
gb_price.push(new gb_price_node(gb_cy,gb_cx,100));
}


else{


if(gb_sound==1){ document.getElementById("gb_bubble_expand").play(); }


gb_expand=1;
gb_no_check=1;


gb_collide=1;
gb_collide_x=gb_cx;
gb_collide_y=gb_cy;


gb_cy=-1;
gb_cx=10;


}


}


//____________________ BALL TYPE - COLOR ____________________


else if(gb_map[gb_cy][gb_cx].type>28){


if(gb_ball==9){
gb_bomber=1;
gb_bomber_y=gb_cy;
gb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==12){
gb_fb_bomber=1;
gb_fb_bomber_y=gb_cy;
gb_fb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==8){
gb_crash_timer.push([gb_cy,gb_cx,0,gb_map[gb_cy][gb_cx].type]);
gb_map[gb_cy][gb_cx].type=0;
gb_price.push(new gb_price_node(gb_cy,gb_cx,100));
}


else{


if(gb_sound==1){ document.getElementById("gb_color_bubble").play(); }


gb_change_ink=1;
gb_no_check=1;


gb_collide=1;
gb_collide_x=gb_cx;
gb_collide_y=gb_cy;


gb_cy=-1;
gb_cx=10;


}


}


//____________________ BALL TYPE - SHARK ____________________


else if(gb_map[gb_cy][gb_cx].type==11){


if(gb_ball==9){
gb_bomber=1;
gb_bomber_y=gb_cy;
gb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==12){
gb_fb_bomber=1;
gb_fb_bomber_y=gb_cy;
gb_fb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==8){
gb_crash_timer.push([gb_cy,gb_cx,0,gb_map[gb_cy][gb_cx].type]);
gb_map[gb_cy][gb_cx].type=0;
}


else{


if(gb_sound==1){ document.getElementById("gb_bubble_collide").play(); }


gb_no_check=1;


gb_collide=1;
gb_collide_x=gb_cx;
gb_collide_y=gb_cy;


gb_cy=-1;
gb_cx=10;


}


}


//____________________ BALL TYPE - CROWN ____________________


else if(gb_map[gb_cy][gb_cx].type==21){


gb_map[gb_cy][gb_cx].type=0;
gb_cy=-1;
gb_cx=10;
gb_shooted=0;
gb_reload=1;


}


//____________________ BALL TYPE - RANDOM ____________________


else{


if(gb_ball==9){
gb_bomber=1;
gb_bomber_y=gb_cy;
gb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==12){
gb_fb_bomber=1;
gb_fb_bomber_y=gb_cy;
gb_fb_bomber_x=gb_cx;
gb_cy=-1;
gb_cx=10;
}


else if(gb_ball==8){
gb_crash_timer.push([gb_cy,gb_cx,0,gb_map[gb_cy][gb_cx].type]);
gb_map[gb_cy][gb_cx].type=0;
gb_price.push(new gb_price_node(gb_cy,gb_cx,100));
}


else{


if(gb_sound==1){ document.getElementById("gb_bubble_collide").play(); }


gb_collide=1;
gb_collide_x=gb_cx;
gb_collide_y=gb_cy;


gb_cy=-1;
gb_cx=10;


}


}


}
}
}
}


}


//____________________ COLLIDE FUNCTION ____________________


if(gb_collide==1){


gb_collide=0;


//____________________ RIGHT TOP ____________________


if(gb_ball_y-(gb_collide_y*28-gb_top_y+gb_move_down)<2 && gb_ball_x-gb_map[gb_collide_y][gb_collide_x].x>15){


if(gb_collide_x+1<=8){
if(gb_map[gb_collide_y][gb_collide_x+1].type==0){
gb_map[gb_collide_y][gb_collide_x+1].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x+1;
gb_checking_y=gb_collide_y;
}
}


}


//____________________ LEFT TOP ____________________


if(gb_ball_y-(gb_collide_y*28-gb_top_y+gb_move_down)<2 && gb_map[gb_collide_y][gb_collide_x].x-gb_ball_x>15){
if(gb_collide_x>0){
if(gb_map[gb_collide_y][gb_collide_x-1].type==0){
gb_map[gb_collide_y][gb_collide_x-1].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x-1;
gb_checking_y=gb_collide_y;
}
}


}





if(gb_checking==0){


if(gb_collide_y+1==gb_height){
gb_height++;
var gb_arr=[];
for(var gb_x=0;gb_x<gb_width;gb_x++){
gb_arr.push(new gb_map_node(gb_x+(gb_collide_y+1)*9,(gb_collide_y+1),gb_x,0));
}
gb_map.push(gb_arr);
}


if(gb_collide_y+1>gb_m_bottom){
gb_m_bottom++;
}


//____________________ LEFT BOTTOM ____________________


if(gb_map[gb_collide_y][gb_collide_x].x-gb_ball_x+2>=0){
if(gb_collide_y%2==0){
if(gb_collide_x-1>=0){
if(gb_map[gb_collide_y+1][gb_collide_x-1].type==0){
gb_map[gb_collide_y+1][gb_collide_x-1].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x-1;
gb_checking_y=gb_collide_y+1;
}
}
else{
if(gb_map[gb_collide_y+1][gb_collide_x].type==0){
gb_map[gb_collide_y+1][gb_collide_x].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x;
gb_checking_y=gb_collide_y+1;
}
}
}
else{
if(gb_map[gb_collide_y+1][gb_collide_x].type==0){
gb_map[gb_collide_y+1][gb_collide_x].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x;
gb_checking_y=gb_collide_y+1;
}
}


//____________________ IF NO LEFT BOTTOM ____________________


if(gb_checking==0){
if(gb_collide_x-1>=0){
if(gb_map[gb_collide_y][gb_collide_x-1].type==0){
gb_map[gb_collide_y][gb_collide_x-1].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x-1;
gb_checking_y=gb_collide_y;
}
}
}


}


//____________________ RIGHT BOTTOM ____________________


else{


if(gb_collide_y%2==0){


if(gb_map[gb_collide_y+1][gb_collide_x].type==0){
gb_map[gb_collide_y+1][gb_collide_x].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x;
gb_checking_y=gb_collide_y+1;
}


}
else{


if(gb_collide_x+1<=8){
if(gb_map[gb_collide_y+1][gb_collide_x+1].type==0){
gb_map[gb_collide_y+1][gb_collide_x+1].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x+1;
gb_checking_y=gb_collide_y+1;
}
}
else{
if(gb_map[gb_collide_y+1][gb_collide_x].type==0){
gb_map[gb_collide_y+1][gb_collide_x].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x;
gb_checking_y=gb_collide_y+1;
}
}


}


//____________________ IF NO RIGHT BOTTOM ____________________


if(gb_checking==0){
if(gb_collide_x+1<=8){
if(gb_map[gb_collide_y][gb_collide_x+1].type==0){
gb_map[gb_collide_y][gb_collide_x+1].type=gb_ball;
gb_checking=1;
gb_checking_x=gb_collide_x+1;
gb_checking_y=gb_collide_y;
}
}
}


}





gb_map[gb_collide_y][gb_collide_x].ant=1;


if(gb_collide_y%2==0){
if(gb_collide_y-1>=gb_m_top){
gb_map[gb_collide_y-1][gb_collide_x].ant=2;
if(gb_collide_x>0){
if(gb_map[gb_collide_y-1][gb_collide_x-1].type!=0){
gb_map[gb_collide_y-1][gb_collide_x-1].ant=2;
}
}
}
}


else{
if(gb_collide_y-1>=gb_m_top){
gb_map[gb_collide_y-1][gb_collide_x].ant=2;
if(gb_collide_x<8){
if(gb_map[gb_collide_y-1][gb_collide_x+1].type!=0){
gb_map[gb_collide_y-1][gb_collide_x+1].ant=2;
}
}
}
}


}


gb_shooted=0;
gb_reload=1;


}


//____________________ EXPAND FUNCTION ____________________


if(gb_expand==1){


gb_expand=0;


gb_expand_color=gb_map[gb_collide_y][gb_collide_x].type-21;


gb_map[gb_collide_y][gb_collide_x].type=gb_expand_color;


if(gb_collide_x>0){
if(gb_map[gb_collide_y][gb_collide_x-1].type==0){
gb_map[gb_collide_y][gb_collide_x-1].type=gb_expand_color;
}
}


if(gb_collide_x<8){
if(gb_map[gb_collide_y][gb_collide_x+1].type==0){
gb_map[gb_collide_y][gb_collide_x+1].type=gb_expand_color;
}
}


if(gb_collide_y-1>=gb_m_top){


if(gb_collide_x>0){
if(gb_map[gb_collide_y-1][gb_collide_x-1].type==0){
gb_map[gb_collide_y-1][gb_collide_x-1].type=gb_expand_color;
}
}


if(gb_map[gb_collide_y-1][gb_collide_x].type==0){
gb_map[gb_collide_y-1][gb_collide_x].type=gb_expand_color;
}


if(gb_collide_x<8){
if(gb_map[gb_collide_y-1][gb_collide_x+1].type==0){
gb_map[gb_collide_y-1][gb_collide_x+1].type=gb_expand_color;
}
}


}


if(gb_collide_y+1<=gb_m_bottom){


if(gb_collide_x>0){
if(gb_map[gb_collide_y+1][gb_collide_x-1].type==0){
gb_map[gb_collide_y+1][gb_collide_x-1].type=gb_expand_color;
}
}


if(gb_map[gb_collide_y+1][gb_collide_x].type==0){
gb_map[gb_collide_y+1][gb_collide_x].type=gb_expand_color;
}


if(gb_collide_x<8){
if(gb_map[gb_collide_y+1][gb_collide_x+1].type==0){
gb_map[gb_collide_y+1][gb_collide_x+1].type=gb_expand_color;
}
}


}


}


//____________________ COLOR CHANGE FUNCTION ____________________


if(gb_change_ink==1){


gb_change_ink=0;


gb_change_color=gb_map[gb_collide_y][gb_collide_x].type-28;


gb_map[gb_collide_y][gb_collide_x].type=gb_change_color;


if(gb_collide_x>0){
if((gb_map[gb_collide_y][gb_collide_x-1].type>0 && gb_map[gb_collide_y][gb_collide_x-1].type<8) || gb_map[gb_collide_y][gb_collide_x-1].type>21){
gb_map[gb_collide_y][gb_collide_x-1].type=gb_change_color;
}
}


if(gb_collide_x<8){
if((gb_map[gb_collide_y][gb_collide_x+1].type>0 && gb_map[gb_collide_y][gb_collide_x+1].type<8) || gb_map[gb_collide_y][gb_collide_x+1].type>21){
gb_map[gb_collide_y][gb_collide_x+1].type=gb_change_color;
}
}


if(gb_collide_y-1>=gb_m_top){


if(gb_collide_x>0){
if((gb_map[gb_collide_y-1][gb_collide_x-1].type>0 && gb_map[gb_collide_y-1][gb_collide_x-1].type<8) || gb_map[gb_collide_y-1][gb_collide_x-1].type>21){
gb_map[gb_collide_y-1][gb_collide_x-1].type=gb_change_color;
}
}


if((gb_map[gb_collide_y-1][gb_collide_x].type>0 && gb_map[gb_collide_y-1][gb_collide_x].type<8) || gb_map[gb_collide_y-1][gb_collide_x].type>21){
gb_map[gb_collide_y-1][gb_collide_x].type=gb_change_color;
}


if(gb_collide_x<8){
if((gb_map[gb_collide_y-1][gb_collide_x+1].type>0 && gb_map[gb_collide_y-1][gb_collide_x+1].type<8) || gb_map[gb_collide_y-1][gb_collide_x+1].type>21){
gb_map[gb_collide_y-1][gb_collide_x+1].type=gb_change_color;
}
}


}


if(gb_collide_y+1<=gb_m_bottom){


if(gb_collide_x>0){
if((gb_map[gb_collide_y+1][gb_collide_x-1].type>0 && gb_map[gb_collide_y+1][gb_collide_x-1].type<8) || gb_map[gb_collide_y+1][gb_collide_x-1].type>21){
gb_map[gb_collide_y+1][gb_collide_x-1].type=gb_change_color;
}
}


if((gb_map[gb_collide_y+1][gb_collide_x].type>0 && gb_map[gb_collide_y+1][gb_collide_x].type<8) || gb_map[gb_collide_y+1][gb_collide_x].type>21){
gb_map[gb_collide_y+1][gb_collide_x].type=gb_change_color;
}


if(gb_collide_x<8){
if((gb_map[gb_collide_y+1][gb_collide_x+1].type>0 && gb_map[gb_collide_y+1][gb_collide_x+1].type<8) || gb_map[gb_collide_y+1][gb_collide_x+1].type>21){
gb_map[gb_collide_y+1][gb_collide_x+1].type=gb_change_color;
}
}


}


}


//____________________ BOMB FUNCTION ____________________


if(gb_bomber==1){
gb_bomber=0;


gb_crash_timer.push([gb_bomber_y,gb_bomber_x,0,gb_map[gb_bomber_y][gb_bomber_x].type]);
gb_map[gb_bomber_y][gb_bomber_x].type=0;


if(gb_map[gb_bomber_y][gb_bomber_x].type<8 || gb_map[gb_bomber_y][gb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_bomber_y,gb_bomber_x,100));
}


if(gb_bomber_x>0){
if(gb_map[gb_bomber_y][gb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_bomber_y,gb_bomber_x-1,0,gb_map[gb_bomber_y][gb_bomber_x-1].type]);
gb_map[gb_bomber_y][gb_bomber_x-1].type=0;
if(gb_map[gb_bomber_y][gb_bomber_x-1].type<8 || gb_map[gb_bomber_y][gb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_bomber_y,gb_bomber_x-1,100));
}
}
}


if(gb_bomber_x<8){
if(gb_map[gb_bomber_y][gb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_bomber_y,gb_bomber_x+1,0,gb_map[gb_bomber_y][gb_bomber_x+1].type]);
gb_map[gb_bomber_y][gb_bomber_x+1].type=0;
if(gb_map[gb_bomber_y][gb_bomber_x+1].type<8 || gb_map[gb_bomber_y][gb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_bomber_y,gb_bomber_x+1,100));
}
}
}


if(gb_bomber_y-1>=gb_m_top){


if(gb_bomber_x>0){
if(gb_map[gb_bomber_y-1][gb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_bomber_y-1,gb_bomber_x-1,0,gb_map[gb_bomber_y-1][gb_bomber_x-1].type]);
gb_map[gb_bomber_y-1][gb_bomber_x-1].type=0;
if(gb_map[gb_bomber_y-1][gb_bomber_x-1].type<8 || gb_map[gb_bomber_y-1][gb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_bomber_y-1,gb_bomber_x-1,100));
}
}
}


if(gb_map[gb_bomber_y-1][gb_bomber_x].type!=0){
gb_crash_timer.push([gb_bomber_y-1,gb_bomber_x,0,gb_map[gb_bomber_y-1][gb_bomber_x].type]);
gb_map[gb_bomber_y-1][gb_bomber_x].type=0;
if(gb_map[gb_bomber_y-1][gb_bomber_x].type<8 || gb_map[gb_bomber_y-1][gb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_bomber_y-1,gb_bomber_x,100));
}
}


if(gb_bomber_x<8){
if(gb_map[gb_bomber_y-1][gb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_bomber_y-1,gb_bomber_x+1,0,gb_map[gb_bomber_y-1][gb_bomber_x+1].type]);
gb_map[gb_bomber_y-1][gb_bomber_x+1].type=0;
if(gb_map[gb_bomber_y-1][gb_bomber_x+1].type<8 || gb_map[gb_bomber_y-1][gb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_bomber_y-1,gb_bomber_x+1,100));
}
}
}


}


if(gb_bomber_y+1<=gb_m_bottom){


if(gb_bomber_x>0){
if(gb_map[gb_bomber_y+1][gb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_bomber_y+1,gb_bomber_x-1,0,gb_map[gb_bomber_y+1][gb_bomber_x-1].type]);
gb_map[gb_bomber_y+1][gb_bomber_x-1].type=0;
if(gb_map[gb_bomber_y+1][gb_bomber_x-1].type<8 || gb_map[gb_bomber_y+1][gb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_bomber_y+1,gb_bomber_x-1,100));
}
}
}


if(gb_map[gb_bomber_y+1][gb_bomber_x].type!=0){
gb_crash_timer.push([gb_bomber_y+1,gb_bomber_x,0,gb_map[gb_bomber_y+1][gb_bomber_x].type]);
gb_map[gb_bomber_y+1][gb_bomber_x].type=0;
if(gb_map[gb_bomber_y+1][gb_bomber_x].type<8 || gb_map[gb_bomber_y+1][gb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_bomber_y+1,gb_bomber_x,100));
}
}


if(gb_bomber_x<8){
if(gb_map[gb_bomber_y+1][gb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_bomber_y+1,gb_bomber_x+1,0,gb_map[gb_bomber_y+1][gb_bomber_x+1].type]);
gb_map[gb_bomber_y+1][gb_bomber_x+1].type=0;
if(gb_map[gb_bomber_y+1][gb_bomber_x+1].type<8 || gb_map[gb_bomber_y+1][gb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_bomber_y+1,gb_bomber_x+1,100));
}
}
}


}


gb_boom_gen(gb_map[gb_bomber_y][gb_bomber_x].x,gb_bomber_y*28-gb_top_y+gb_move_down);


gb_shooted=0;
gb_reload=1;


}


//____________________ FIREBALL BOMB FUNCTION ____________________


if(gb_fb_bomber==1){
gb_fb_bomber=0;


gb_crash_timer.push([gb_fb_bomber_y,gb_fb_bomber_x,0,gb_map[gb_fb_bomber_y][gb_fb_bomber_x].type]);
gb_map[gb_fb_bomber_y][gb_fb_bomber_x].type=0;


if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x].type<8 || gb_map[gb_fb_bomber_y][gb_fb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y,gb_fb_bomber_x,100));
}


if(gb_fb_bomber_x>0){
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y,gb_fb_bomber_x-1,0,gb_map[gb_fb_bomber_y][gb_fb_bomber_x-1].type]);
gb_map[gb_fb_bomber_y][gb_fb_bomber_x-1].type=0;
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x-1].type<8 || gb_map[gb_fb_bomber_y][gb_fb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y,gb_fb_bomber_x-1,100));
}
}
}


if(gb_fb_bomber_x>1){
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x-2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y,gb_fb_bomber_x-2,0,gb_map[gb_fb_bomber_y][gb_fb_bomber_x-2].type]);
gb_map[gb_fb_bomber_y][gb_fb_bomber_x-2].type=0;
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x-2].type<8 || gb_map[gb_fb_bomber_y][gb_fb_bomber_x-2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y,gb_fb_bomber_x-2,100));
}
}
}


if(gb_fb_bomber_x<8){
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y,gb_fb_bomber_x+1,0,gb_map[gb_fb_bomber_y][gb_fb_bomber_x+1].type]);
gb_map[gb_fb_bomber_y][gb_fb_bomber_x+1].type=0;
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x+1].type<8 || gb_map[gb_fb_bomber_y][gb_fb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y,gb_fb_bomber_x+1,100));
}
}
}


if(gb_fb_bomber_x<7){
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x+2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y,gb_fb_bomber_x+2,0,gb_map[gb_fb_bomber_y][gb_fb_bomber_x+2].type]);
gb_map[gb_fb_bomber_y][gb_fb_bomber_x+2].type=0;
if(gb_map[gb_fb_bomber_y][gb_fb_bomber_x+2].type<8 || gb_map[gb_fb_bomber_y][gb_fb_bomber_x+2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y,gb_fb_bomber_x+2,100));
}
}
}


if(gb_fb_bomber_y-1>=gb_m_top){


if(gb_fb_bomber_x>0){
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-1,gb_fb_bomber_x-1,0,gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-1].type]);
gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-1].type=0;
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-1].type<8 || gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-1,gb_fb_bomber_x-1,100));
}
}
}


if(gb_fb_bomber_x>1){
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-1,gb_fb_bomber_x-2,0,gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-2].type]);
gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-2].type=0;
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-2].type<8 || gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x-2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-1,gb_fb_bomber_x-2,100));
}
}
}


if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-1,gb_fb_bomber_x,0,gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x].type]);
gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x].type=0;
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x].type<8 || gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-1,gb_fb_bomber_x,100));
}
}


if(gb_fb_bomber_x<8){
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-1,gb_fb_bomber_x+1,0,gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+1].type]);
gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+1].type=0;
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+1].type<8 || gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-1,gb_fb_bomber_x+1,100));
}
}
}


if(gb_fb_bomber_x<7){
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-1,gb_fb_bomber_x+2,0,gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+2].type]);
gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+2].type=0;
if(gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+2].type<8 || gb_map[gb_fb_bomber_y-1][gb_fb_bomber_x+2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-1,gb_fb_bomber_x+2,100));
}
}
}


}


if(gb_fb_bomber_y-2>=gb_m_top){


if(gb_fb_bomber_x>0){
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-2,gb_fb_bomber_x-1,0,gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-1].type]);
gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-1].type=0;
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-1].type<8 || gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-2,gb_fb_bomber_x-1,100));
}
}
}


if(gb_fb_bomber_x>1){
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-2,gb_fb_bomber_x-2,0,gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-2].type]);
gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-2].type=0;
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-2].type<8 || gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x-2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-2,gb_fb_bomber_x-2,100));
}
}
}


if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-2,gb_fb_bomber_x,0,gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x].type]);
gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x].type=0;
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x].type<8 || gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-2,gb_fb_bomber_x,100));
}
}


if(gb_fb_bomber_x<8){
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-2,gb_fb_bomber_x+1,0,gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+1].type]);
gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+1].type=0;
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+1].type<8 || gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-2,gb_fb_bomber_x+1,100));
}
}
}


if(gb_fb_bomber_x<7){
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y-2,gb_fb_bomber_x+2,0,gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+2].type]);
gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+2].type=0;
if(gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+2].type<8 || gb_map[gb_fb_bomber_y-2][gb_fb_bomber_x+2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y-2,gb_fb_bomber_x+2,100));
}
}
}


}


if(gb_fb_bomber_y+1<=gb_m_bottom){


if(gb_fb_bomber_x>0){
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+1,gb_fb_bomber_x-1,0,gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-1].type]);
gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-1].type=0;
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-1].type<8 || gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+1,gb_fb_bomber_x-1,100));
}
}
}


if(gb_fb_bomber_x>1){
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+1,gb_fb_bomber_x-2,0,gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-2].type]);
gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-2].type=0;
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-2].type<8 || gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x-2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+1,gb_fb_bomber_x-2,100));
}
}
}


if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+1,gb_fb_bomber_x,0,gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x].type]);
gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x].type=0;
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x].type<8 || gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+1,gb_fb_bomber_x,100));
}
}


if(gb_fb_bomber_x<8){
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+1,gb_fb_bomber_x+1,0,gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+1].type]);
gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+1].type=0;
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+1].type<8 || gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+1,gb_fb_bomber_x+1,100));
}
}
}


if(gb_fb_bomber_x<7){
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+1,gb_fb_bomber_x+2,0,gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+2].type]);
gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+2].type=0;
if(gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+2].type<8 || gb_map[gb_fb_bomber_y+1][gb_fb_bomber_x+2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+1,gb_fb_bomber_x+2,100));
}
}
}


}


if(gb_fb_bomber_y+2<=gb_m_bottom){


if(gb_fb_bomber_x>0){
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+2,gb_fb_bomber_x-1,0,gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-1].type]);
gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-1].type=0;
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-1].type<8 || gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+2,gb_fb_bomber_x-1,100));
}
}
}


if(gb_fb_bomber_x>1){
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+2,gb_fb_bomber_x-2,0,gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-2].type]);
gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-2].type=0;
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-2].type<8 || gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x-2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+2,gb_fb_bomber_x-2,100));
}
}
}


if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+2,gb_fb_bomber_x,0,gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x].type]);
gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x].type=0;
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x].type<8 || gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+2,gb_fb_bomber_x,100));
}
}


if(gb_fb_bomber_x<8){
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+1].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+2,gb_fb_bomber_x+1,0,gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+1].type]);
gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+1].type=0;
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+1].type<8 || gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+1].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+2,gb_fb_bomber_x+1,100));
}
}
}


if(gb_fb_bomber_x<7){
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+2].type!=0){
gb_crash_timer.push([gb_fb_bomber_y+2,gb_fb_bomber_x+2,0,gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+2].type]);
gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+2].type=0;
if(gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+2].type<8 || gb_map[gb_fb_bomber_y+2][gb_fb_bomber_x+2].type>21){
gb_price.push(new gb_price_node(gb_fb_bomber_y+2,gb_fb_bomber_x+2,100));
}
}
}


}


gb_fbb.push(new gb_fireball_node(gb_map[gb_fb_bomber_y][gb_fb_bomber_x].x+10,gb_fb_bomber_y*28-gb_top_y+gb_move_down+10));


gb_shooted=0;
gb_reload=1;


}


//____________________ CHECKING OR NOT ____________________


if(gb_no_check==1){
gb_no_check=0;
gb_checking=0;
}


if(gb_checking==1){
gb_checking=0;
gb_find=1;


if(gb_map[gb_checking_y][gb_checking_x].type==11){
gb_find=0;
}


}


//____________________ FIND SIMILAR ____________________


if(gb_find==1){
gb_find=0;
gb_to_boom=[];


var gb_frontier=[[gb_checking_y,gb_checking_x]];
gb_map[gb_checking_y][gb_checking_x].visited=true;


gb_to_boom.push([gb_checking_y,gb_checking_x]);


while(gb_frontier.length>0){


if(gb_frontier.length>0){
var gb_current=gb_frontier[0];


if(gb_frontier[0][0]%2==0){ var gb_look=[[-1,-1],[-1,0],[0,-1],[0,1],[1,-1],[1,0]]; }
else{ var gb_look=[[-1,0],[-1,1],[0,-1],[0,1],[1,0],[1,1]]; }


gb_frontier.splice(0,1);


for(var i=0;i<6;i++){
var gb_n_y=gb_current[0]+gb_look[i][0];
var gb_n_x=gb_current[1]+gb_look[i][1];


if(gb_n_y<gb_m_top || gb_n_y>gb_m_bottom || gb_n_x<0 || gb_n_x>8){ continue; }
if(gb_map[gb_n_y][gb_n_x].visited==true){ continue; }
if(gb_map[gb_n_y][gb_n_x].type>10 || gb_map[gb_n_y][gb_n_x].type==0){ continue; }


//____________________ NO RAINBOW ____________________


if(gb_map[gb_checking_y][gb_checking_x].type!=10){
if(gb_map[gb_n_y][gb_n_x].type==gb_map[gb_checking_y][gb_checking_x].type || gb_map[gb_n_y][gb_n_x].type==10){
gb_frontier.push([gb_n_y,gb_n_x]);
gb_map[gb_n_y][gb_n_x].visited=true;
gb_to_boom.push([gb_n_y,gb_n_x]);
}
}


//____________________ RAINBOW - RAINBOW ____________________


if(gb_map[gb_checking_y][gb_checking_x].type==10 && gb_map[gb_collide_y][gb_collide_x].type==10){
if(gb_map[gb_n_y][gb_n_x].type==10){
gb_frontier.push([gb_n_y,gb_n_x]);
gb_map[gb_n_y][gb_n_x].visited=true;
gb_to_boom.push([gb_n_y,gb_n_x]);
}
}


//____________________ RAINBOW - NO RAINBOW ____________________


if(gb_map[gb_checking_y][gb_checking_x].type==10 && gb_map[gb_collide_y][gb_collide_x].type!=10){
if(gb_map[gb_n_y][gb_n_x].type==gb_map[gb_collide_y][gb_collide_x].type || gb_map[gb_n_y][gb_n_x].type==10){
gb_frontier.push([gb_n_y,gb_n_x]);
gb_map[gb_n_y][gb_n_x].visited=true;
gb_to_boom.push([gb_n_y,gb_n_x]);
}
}


}
}
}


if(gb_to_boom.length<3){
gb_to_boom=[];
}


}


//____________________ BOMB IT ALL ____________________


if(gb_to_boom.length>0){
for(var n=0;n<gb_to_boom.length;n++){
gb_crash_timer.push([gb_to_boom[n][0],gb_to_boom[n][1],0,gb_map[gb_to_boom[n][0]][gb_to_boom[n][1]].type]);
gb_map[gb_to_boom[n][0]][gb_to_boom[n][1]].type=0;
if(n<=2){ gb_price.push(new gb_price_node(gb_to_boom[n][0],gb_to_boom[n][1],100)); }
if(n>2 && n<=17){ gb_price.push(new gb_price_node(gb_to_boom[n][0],gb_to_boom[n][1],(n-1)*100)); }
if(n>17){ gb_price.push(new gb_price_node(gb_to_boom[n][0],gb_to_boom[n][1],1600)); }
}
gb_touch_move=10;
}


//____________________ CUT BALLS ____________________


if(gb_cut==1){
gb_cut=0;
gb_cutted_n=gb_to_boom.length;


for(gb_my=gb_m_top;gb_my<gb_m_bottom+1;gb_my++){
for(gb_mx=0;gb_mx<9;gb_mx++){
gb_map[gb_my][gb_mx].visited=false;
}
}


var gb_frontier=[];


for(gb_mx=0;gb_mx<9;gb_mx++){
if(gb_map[gb_m_top][gb_mx].type!=0){
gb_frontier.push([gb_m_top,gb_mx]);
gb_map[gb_m_top][gb_mx].visited=true;
}
}


while(gb_frontier.length>0){


if(gb_frontier.length>0){
var gb_current=gb_frontier[0];


if(gb_frontier[0][0]%2==0){ var gb_look=[[-1,-1],[-1,0],[0,-1],[0,1],[1,-1],[1,0]]; }
else{ var gb_look=[[-1,0],[-1,1],[0,-1],[0,1],[1,0],[1,1]]; }


gb_frontier.splice(0,1);


for(var i=0;i<6;i++){
var gb_n_y=gb_current[0]+gb_look[i][0];
var gb_n_x=gb_current[1]+gb_look[i][1];


if(gb_n_y<gb_m_top || gb_n_y>gb_m_bottom || gb_n_x<0 || gb_n_x>8){ continue; }
if(gb_map[gb_n_y][gb_n_x].visited==true || gb_map[gb_n_y][gb_n_x].type==0){ continue; }


gb_frontier.push([gb_n_y,gb_n_x]);
gb_map[gb_n_y][gb_n_x].visited=true;


}
}
}


for(gb_my=gb_m_top;gb_my<gb_m_bottom+1;gb_my++){
for(gb_mx=0;gb_mx<9;gb_mx++){
if(gb_map[gb_my][gb_mx].visited==false && gb_map[gb_my][gb_mx].type!=0){
gb_cuted.push(new gb_cuted_node(gb_my*28-gb_top_y+gb_move_down,gb_map[gb_my][gb_mx].x,gb_map[gb_my][gb_mx].type));
gb_map[gb_my][gb_mx].type=0;


if(gb_to_boom.length>0){
gb_cutted_n++;
if(gb_cutted_n>2 && gb_cutted_n<=17){ gb_price.push(new gb_price_node(gb_my,gb_mx,(gb_cutted_n-1)*100)); }
if(gb_cutted_n>17){ gb_price.push(new gb_price_node(gb_my,gb_mx,1600)); }
}


}
}
}


}


//____________________ CALCULATION BONUS ____________________


if(gb_to_boom.length>0){
if(gb_cutted_n>=6 && gb_cutted_n<=9){ gb_rate.push(new gb_rate_node(gb_checking_y*28-gb_top_y+gb_move_down-120,gb_map[gb_checking_y][gb_checking_x].x,1)); }
if(gb_cutted_n>9 && gb_cutted_n<=13){ gb_rate.push(new gb_rate_node(gb_checking_y*28-gb_top_y+gb_move_down-120,gb_map[gb_checking_y][gb_checking_x].x,2)); }
if(gb_cutted_n>13 && gb_cutted_n<=17){ gb_rate.push(new gb_rate_node(gb_checking_y*28-gb_top_y+gb_move_down-120,gb_map[gb_checking_y][gb_checking_x].x,3)); }
if(gb_cutted_n>17 && gb_cutted_n<=21){ gb_rate.push(new gb_rate_node(gb_checking_y*28-gb_top_y+gb_move_down-120,gb_map[gb_checking_y][gb_checking_x].x,4)); }
if(gb_cutted_n>21){ gb_rate.push(new gb_rate_node(gb_checking_y*28-gb_top_y+gb_move_down-120,gb_map[gb_checking_y][gb_checking_x].x,5)); }


gb_combo_sec+=210;
gb_combo_n=Math.floor((gb_combo_sec-180)/120);


if(gb_combo_n>0){


if(gb_combo_n>8){ gb_combo_sec-=210; gb_combo_n=8; }


gb_combo.push(new gb_combo_node(gb_checking_y*28-gb_top_y+gb_move_down+6-100,gb_map[gb_checking_y][gb_checking_x].x,gb_combo_n));


}


gb_to_boom=[];
}


//____________________ ERASE BOTTOM ____________________


if(gb_m_bottom>0){
for(var gb_x=0;gb_x<gb_width;gb_x++){
if(gb_map[gb_m_bottom][gb_x].type!=0){
break;
}
if(gb_x==8){
gb_m_bottom--;
}
}
}


//____________________ BIND BALL TO TOP ____________________


if(gb_shooted==1 && gb_m_top==0){
if(gb_ball_y<-gb_top_y+gb_move_down){
gb_shooted=0;
gb_reload=1;
if(gb_sound==1){ document.getElementById("gb_brick_collide").play(); }
if(gb_ball<8 || gb_ball==10 || gb_ball==11){
gb_bind_top=Math.floor((gb_ball_x)/29);
if(gb_bind_top<0){ gb_bind_top=0; }
if(gb_bind_top>8){ gb_bind_top=8; }
if(gb_map[0][gb_bind_top].type==0){
gb_map[0][gb_bind_top].type=gb_ball;
}
}
}
}


//____________________ CHECK CROWN ____________________


if(gb_stop==0 && gb_map[0][gb_crown_x].type!=21){
gb_stop=1;
gb_alert_on=0;
document.getElementById("gb_play_music").pause();
if(gb_sound==1){ document.getElementById("gb_win_sound").play(); }
gb_boom_gen(gb_map[0][gb_crown_x].x,-gb_top_y+gb_move_down);
for(gb_my=gb_m_bottom;gb_my>gb_m_top-1;gb_my--){
for(gb_mx=0;gb_mx<9;gb_mx++){
if(gb_map[gb_my][gb_mx].type!=0){
gb_crash_timer.push([gb_my,gb_mx,gb_lose_bn*8+80,gb_map[gb_my][gb_mx].type]);
gb_lose_bn++;
}
}
}
gb_send();
}


//____________________ DRAW BIND TOP ____________________


if(gb_m_top==0){
ctx.drawImage(gb_pic_things,0,376,300,24,0,(-gb_top_y+gb_move_down-26),300,24);
}


//____________________ DRAW SPEC EFFECTS ____________________


gb_draw_effects();


//____________________ WAVE BLAST ____________________


if(gb_wave_n>-1){
gb_wave_n+=10;
ctx.drawImage(gb_pic_things,0,0,280,240,10,550-gb_wave_n,280,240);
if(gb_wave_n>900){
gb_wave_n=-1;
gb_wave_can=1;
}
}


//____________________ BOTTOM ____________________


ctx.drawImage(gb_pic_bottom,0,420);


//____________________ RELOAD BALL ____________________


if(gb_reload==1){
gb_ball=gb_temp_ball;
gb_temp_ball=Math.floor(Math.random()*7)+1;
gb_spec_balls--;
if(gb_spec_balls<=0){
gb_temp_ball=Math.floor(Math.random()*4)+8;
gb_spec_balls=Math.floor(Math.random()*30)+30;
}
gb_mci_n=0;
gb_anim_shoot=0;
gb_reload=0;
if(gb_ball==9){ if(gb_sound==1){ document.getElementById("gb_bomb_burning").play(); } }
if(gb_ball==12){ if(gb_sound==1){ document.getElementById("gb_fireball_burning").play(); } }
}


//____________________ LAMP STEEL ____________________


if(gb_can_shoot==1 && gb_ball==8){
ctx.drawImage(gb_pic_lamp,0,275,122,92,90,420,122,92);
if(gb_angle<240){ gb_angle=240; }
if(gb_angle>300){ gb_angle=300; }
}


//____________________ ROTATE LAMP AND CANNON ____________________


ctx.save();
ctx.translate(150,518);
ctx.rotate(gb_angle*gb_radian);


//____________________ LAMP ____________________


if(gb_can_shoot==1 && gb_ball!=8){
ctx.drawImage(gb_pic_lamp,0,(gb_ball-1)*25,80,25,20,-12,80,25);
}


//____________________ CANNON SHOOT ANIMATE____________________


if(gb_anim_shoot>=0){
gb_anim_shoot+=1;
if(gb_anim_shoot>2){
gb_anim_shoot=-1;
}
}


ctx.drawImage(gb_pic_cannon,-37-gb_anim_shoot,-28);
ctx.restore();


//____________________ WINGS ____________________


ctx.drawImage(gb_pic_wings,102,508);


//____________________ LEFT BALL ____________________


if(gb_can_shoot==1 || gb_shooted==1){
if(gb_temp_ball==9){ ctx.drawImage(gb_pic_items,0,(gb_temp_ball-1)*32,32,32,77,515,32,32); }
else { ctx.drawImage(gb_pic_items,0,(gb_temp_ball-1)*32,32,32,74,518,32,32); }
}


//____________________ ANIMATE BALL AND TEMP BALL ____________________


if(gb_mci_n>=0){
ctx.drawImage(gb_pic_items,0,(gb_temp_ball-1)*32,32,32,78,520,1.4*gb_mci_n,1.4*gb_mci_n);
ctx.drawImage(gb_pic_items,0,(gb_ball-1)*32,32,32,gb_mci_x[gb_mci_n],gb_mci_y[gb_mci_n],32,32);
gb_mci_n++;
if(gb_mci_n>17){
gb_mci_n=-1;
gb_can_shoot=1;
}
}


//____________________ CENTER BALL ____________________


if(gb_can_shoot==1){
if(gb_ball==9){
ctx.drawImage(gb_pic_items,0,(gb_ball-1)*32,32,32,135,501,32,32);
if(gb_size_cball_w==0){ gb_size_cball+=0.15; }
else{ gb_size_cball-=0.15; }
if(gb_size_cball>4){ gb_size_cball_w=1; }
if(gb_size_cball<0.2){ gb_size_cball_w=0; }
ctx.drawImage(gb_pic_things,160,240,40,40,132-gb_size_cball,476-gb_size_cball,60+gb_size_cball,60+gb_size_cball);
}
else if(gb_ball==10){
gb_rot_cball+=4;
ctx.save();
ctx.translate(150,519);
ctx.rotate(gb_rot_cball*gb_radian);
ctx.drawImage(gb_pic_items,0,(gb_ball-1)*32,32,32,-16.5,-16.5,33,33);
ctx.restore();
}
else if(gb_ball==12){
gb_rot_cball+=1;
if(gb_size_cball_w==0){ gb_size_cball+=0.05; }
else{ gb_size_cball-=0.05; }
if(gb_size_cball>4){ gb_size_cball_w=1; }
if(gb_size_cball<0.2){ gb_size_cball_w=0; }
ctx.save();
ctx.translate(150,519);
ctx.rotate(gb_rot_cball*gb_radian);
ctx.drawImage(gb_pic_items,0,(gb_ball-1)*32,32,32,-18-gb_size_cball,-16-gb_size_cball,36+gb_size_cball,36+gb_size_cball);
ctx.restore();
}
else{
ctx.drawImage(gb_pic_items,0,(gb_ball-1)*32,32,32,132,504,32,32);
}
}


//____________________ PULSE ALERT ____________________


if(gb_alert_on==1){
if(gb_sound==1){ document.getElementById("gb_alert_sound").play(); }


if(gb_pulse_w==0){
gb_pulse+=0.01;
if(gb_pulse>0.6){ gb_pulse_w=1; }
}
else{
gb_pulse-=0.01;
if(gb_pulse<0.02){ gb_pulse_w=0; }
}


ctx.fillStyle="rgba(0,0,0,"+gb_pulse+")";
ctx.fillRect(24,462,252,5);
}


//____________________ TOP ____________________


ctx.drawImage(gb_pic_top,0,0);


//____________________ DRAW SPEC EFFECTS 2 ____________________


gb_draw_effects_2();


//____________________ PROGRESS ____________________


ctx.drawImage(gb_pic_things,278-gb_progress_up,240,gb_progress_up,34,300-gb_progress_up,0,gb_progress_up,34);


//____________________ LEVEL AMOUNT ____________________


for(var n=0;n<gb_la_len;n++){
ctx.drawImage(gb_pic_things,gb_la_str.substr(n,1)*14,240,14,14,52+n*12-(gb_la_len*7),62,14,14);
}


//____________________ SCORE AMOUNT ____________________


if(gb_temp_score>gb_score_amount){
gb_score_amount+=300;
if(gb_temp_score<gb_score_amount){
gb_score_amount=gb_temp_score;
}
gb_sa_str=gb_score_amount.toString();
gb_sa_len=gb_sa_str.length;
}


for(var n=0;n<gb_sa_len;n++){
ctx.drawImage(gb_pic_things,gb_sa_str.substr(n,1)*14,240,14,14,154+n*12-(gb_sa_len*7),62,14,14);
}


//____________________ RECORD AMOUNT ____________________


for(var n=0;n<gb_ra_len;n++){
ctx.drawImage(gb_pic_things,gb_ra_str.substr(n,1)*14,240,14,14,256+n*12-(gb_ra_len*7),62,14,14);
}


//____________________ COINS AMOUNT ____________________


for(var n=0;n<gb_ca_len;n++){
ctx.drawImage(gb_pic_things,gb_ca_str.substr(n,1)*14,240,14,14,16+n*12,522,14,14);
}


//____________________ FIREBALL AMOUNT ____________________


for(var n=0;n<gb_fba_len;n++){
ctx.drawImage(gb_pic_things,gb_fba_str.substr(n,1)*14,240,14,14,222+n*12,530,14,14);
}


//____________________ WAVE AMOUNT ____________________


for(var n=0;n<gb_wa_len;n++){
ctx.drawImage(gb_pic_things,gb_wa_str.substr(n,1)*14,240,14,14,262+n*12,530,14,14);
}


offset();


requestAnimationFrame(gb_logic);
}


//____________________ SHOOT ____________________


function gb_shoot(){
if(gb_can_shoot==0 || gb_wave_can==0 || gb_stop==1){ return; }
gb_rot_cball=0;
gb_can_shoot=0;
gb_ball_x=132;
gb_ball_y=504;
gb_shooted=1;
gb_shoot_angle=gb_angle*Math.PI/180;
if(gb_ball==8){ if(gb_sound==1){ document.getElementById("gb_steel_ball_shoot").play(); } }
else if(gb_ball==9){
if(document.getElementById("gb_bomb_burning").paused!=true){
document.getElementById("gb_bomb_burning").pause();
}
if(gb_sound==1){ document.getElementById("gb_bomb_shoot").play(); }
}
else if(gb_ball==12){
if(document.getElementById("gb_fireball_burning").paused!=true){
document.getElementById("gb_fireball_burning").pause();
}
if(gb_sound==1){ document.getElementById("gb_fireball_shoot").play(); }
}
else{ if(gb_sound==1){ document.getElementById("gb_bubble_shoot").play(); } }
}


//____________________ FIREBALL SET ____________________


function gb_fireball_set(){
if(gb_can_shoot==0 || gb_stop==1){ return; }
if(gb_fireball_amount==0){ if(gb_sound==1){ document.getElementById("gb_no_ammo").play(); } }
if(gb_fireball_amount>0 && gb_ball!=12){
if(document.getElementById("gb_bomb_burning").paused!=true){
document.getElementById("gb_bomb_burning").pause();
}
if(document.getElementById("gb_fireball_burning").paused!=true){
document.getElementById("gb_fireball_burning").pause();
}
if(gb_sound==1){ document.getElementById("gb_fireball_burning").play(); }
gb_fireball_amount--;
gb_ball=12;
gb_fba_str=gb_fireball_amount.toString();
gb_fba_len=gb_fba_str.length;
}
}


//____________________ WAVE SET ____________________


function gb_wave_set(){
if(gb_can_shoot==0 || gb_stop==1){ return; }
if(gb_wave_amount==0){ if(gb_sound==1){ document.getElementById("gb_no_ammo").play(); } }
if(gb_wave_amount>0 && gb_wave_can==1){
gb_move_wave=70;
gb_wave_can=0;
gb_wave_n=0;
if(document.getElementById("gb_wave_blast").paused==false){
document.getElementById("gb_wave_blast").pause();
document.getElementById("gb_wave_blast").currentTime=0;
}
if(gb_sound==1){ document.getElementById("gb_wave_blast").play(); }
gb_wave_amount--;
gb_wa_str=gb_wave_amount.toString();
gb_wa_len=gb_wa_str.length;
}
}


function gb_getXmlHttp(){
var gb_xmlhttp;
try{ gb_xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); }
catch(e){
try{ gb_xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); }
catch(E){ gb_xmlhttp=false; }
}
if(!gb_xmlhttp && typeof XMLHttpRequest!="undefined"){
gb_xmlhttp=new XMLHttpRequest();
}
return gb_xmlhttp;
}


var gb_timeout=setTimeout("var gb_bbb=0;",100);


function gb_send() {


gb_timeout=setTimeout("gb_send();",10000);


var gb_vars="score="+gb_temp_score+"&coins="+gb_coins_amount+"&fb="+gb_fireball_amount+"&wave="+gb_wave_amount;
var gb_req=gb_getXmlHttp()
gb_req.onreadystatechange=function() {
if(gb_req.readyState==4){
if(gb_req.status==200){
eval(gb_req.responseText);
clearTimeout(gb_timeout);
}
else{
clearTimeout(gb_timeout);
setTimeout("gb_send();",1000);
}
}
}
gb_req.open("POST","/games/bubbles/bubbles_ajax.php",true);
gb_req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
gb_req.send(gb_vars);
}


window.onload=function(){
waitImagesLoading();
}
