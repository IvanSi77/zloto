//____________________ GEN BUBBLES ____________________


function gb_bubbles_node(bub_x,bub_y,bub_px,bub_py,bub_live){
this.x=bub_x;
this.y=bub_y;
this.px=bub_px;
this.py=bub_py;
this.live=bub_live;
this.size=Math.random()*10+5;
}


var gb_bubbles=[];
var gb_bubbles_audio=1;


function gb_bubbles_gen(bub_y,bub_x,bub_a){
gb_map[bub_y][bub_x].type=0;
bub_x=gb_map[bub_y][bub_x].x+16;
bub_y=bub_y*28-gb_top_y+gb_move_down-14+28;
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,1,0.2,40));
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,0.7,-0.2,40));
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,-1,0.2,30));
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,-0.6,-0.4,50));
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,-0.4,-0.6,55));
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,-0.05,0.2,50));
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,0.2,0.4,65));
gb_bubbles.push(new gb_bubbles_node(bub_x,bub_y,0.2,-0.3,70));
if(bub_a==1){
if(gb_sound==1){ document.getElementById("gb_air_bubble_"+gb_bubbles_audio).play(); }
gb_bubbles_audio++;
if(gb_bubbles_audio>3){
gb_bubbles_audio=1;
}
}
}


//____________________ GEN CRASH BALLS ____________________


function gb_crash_node(crash_x,crash_y,crash_px,crash_py,crash_live,crash_color){
this.x=crash_x;
this.y=crash_y;
this.px=crash_px+(Math.random()*3-2)*0.5;
this.py=crash_py+(Math.random()*3-2)*0.5;
this.live=crash_live;
this.size=Math.random()*1+0.5;
this.color=crash_color;
}


var gb_crash=[];
var gb_crash_audio=1;
var gb_crash_color=[0,"#F02025","#D533DD","#F8CF16","#FDAF2F","#30A9EB","#07E4E4","#7AE348","#ffffff","#ffffff","#C879E1","#ffffff","#ffffff","#ffffff","#F02025","#F8B9AA",
"#FBAE2B","#BFBFBF","#ffffff","#ffffff","#ffffff","#ffffff","#F02025","#D533DD","#F8CF16","#FDAF2F","#30A9EB","#07E4E4","#7AE348","#F02025","#D533DD","#F8CF16","#FDAF2F","#30A9EB","#07E4E4","#7AE348"];


function gb_crash_gen(crash_my,crash_mx,crash_mtype){
crash_x=gb_map[crash_my][crash_mx].x+16;
crash_y=crash_my*28-gb_top_y+gb_move_down-14+28;
crash_color=crash_mtype;
gb_map[crash_my][crash_mx].type=0;
gb_crash.push(new gb_crash_node(crash_x,crash_y,1,0.2,40,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,0.7,-0.2,40,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,-1,0.2,30,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,-0.6,-0.4,50,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,-0.4,-0.6,55,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,-0.05,0.2,50,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,0.2,0.4,65,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,0.2,-0.3,70,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,-0.2,0.5,70,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,0.1,0.2,70,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,0.1,0.2,70,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,0.1,0.4,70,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,-0.1,0.2,70,crash_color));
gb_crash.push(new gb_crash_node(crash_x,crash_y,-0.1,-0.2,70,crash_color));
if(gb_sound==1){ document.getElementById("gb_bubble_burst_"+gb_crash_audio).play(); }
gb_crash_audio++;
if(gb_crash_audio>3){
gb_crash_audio=1;
}
}


var gb_crash_timer=[];


//____________________ GEN BOMB BOOM ____________________


function gb_boom_node(boom_x,boom_y,boom_px,boom_py,boom_live){
this.x=boom_x;
this.y=boom_y;
this.px=boom_px+(Math.random()*5-3);
this.py=boom_py+(Math.random()*5-3);
this.live=boom_live;
this.size=Math.random()*1+0.5;
this.color=gb_boom_color[Math.floor(Math.random()*2)];
}


function gb_boom_violet_node(boom_x,boom_y){
this.x=boom_x;
this.y=boom_y;
this.w=1;
this.live=40;
this.size=1;
}


var gb_boom=[];
var gb_boom_color=["#F02025","#F8CF16"];
var gb_boom_violet=[];


function gb_boom_gen(boom_x,boom_y){
boom_x+=12;
boom_y+=8;
gb_boom_violet.push(new gb_boom_violet_node(boom_x,boom_y));
gb_boom.push(new gb_boom_node(boom_x,boom_y,1,0.2,40));
gb_boom.push(new gb_boom_node(boom_x,boom_y,0.7,-0.2,40));
gb_boom.push(new gb_boom_node(boom_x,boom_y,-1,0.2,30));
gb_boom.push(new gb_boom_node(boom_x,boom_y,-0.6,-0.4,50));
gb_boom.push(new gb_boom_node(boom_x,boom_y,-0.4,-0.6,55));
gb_boom.push(new gb_boom_node(boom_x,boom_y,-0.05,0.2,50));
gb_boom.push(new gb_boom_node(boom_x,boom_y,0.2,0.4,65));
gb_boom.push(new gb_boom_node(boom_x,boom_y,0.2,-0.3,70));
gb_boom.push(new gb_boom_node(boom_x,boom_y,-0.2,0.5,70));
gb_boom.push(new gb_boom_node(boom_x,boom_y,0.1,0.2,70));
gb_boom.push(new gb_boom_node(boom_x,boom_y,0.1,0.2,70));
gb_boom.push(new gb_boom_node(boom_x,boom_y,0.1,0.4,70));
gb_boom.push(new gb_boom_node(boom_x,boom_y,-0.1,0.2,70));
gb_boom.push(new gb_boom_node(boom_x,boom_y,-0.1,-0.2,70));
gb_boom.push(new gb_boom_node(boom_x,boom_y,1,0.2,40));
if(gb_sound==1){ document.getElementById("gb_boom_sound").play(); }
}


//____________________ GEN FIREBALL BOOM ____________________


function gb_fireball_node(fbb_x,fbb_y){
this.x=fbb_x;
this.y=fbb_y;
this.w=1;
this.live=40;
this.size=1;
if(gb_sound==1){ document.getElementById("gb_fireball_boom_sound").play(); }
}


var gb_fbb=[];


//____________________ GEN RATE WORD ____________________


function gb_rate_node(rate_y,rate_x,rate_num){
this.x=rate_x-gb_rate_sizes[rate_num]/2;
if(this.x<15){ this.x=15; }
if(this.x+gb_rate_sizes[rate_num]>285){ this.x=285-gb_rate_sizes[rate_num]; }
this.y=rate_y;
this.w=Math.floor(Math.random()*19);
this.live=80;
this.num=rate_num;
if(gb_sound==1){ document.getElementById("gb_rate_sound_"+rate_num).play(); }
}


var gb_rate=[];
var gb_rate_sizes=[0,92,86,102,130,160];
var gb_rate_crop_x=[0,0,100,190,300,430];
var gb_rate_move_x=[1,1,1,1,1,1,1,1,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];


//____________________ GEN COMBO ____________________


function gb_combo_node(combo_y,combo_x,combo_num){


if(combo_num==1){ gb_temp_score+=200; }
if(combo_num==2){ gb_temp_score+=400; }
if(combo_num==3){ gb_temp_score+=800; }
if(combo_num==4){ gb_temp_score+=1600; }
if(combo_num==5){ gb_temp_score+=3200; }
if(combo_num==6){ gb_temp_score+=6400; }
if(combo_num==7){ gb_temp_score+=12800; }
if(combo_num==8){ gb_temp_score+=25600; }


this.x=combo_x-40;
if(this.x<15){ this.x=15; }
if(this.x>205){ this.x=205; }
this.y=combo_y;
this.w=Math.floor(Math.random()*19);
this.live=80;
this.num=combo_num;
if(gb_sound==1){ document.getElementById("gb_combo_sound_"+gb_combo_audio).play(); }
gb_combo_audio++;
if(gb_combo_audio>2){
gb_combo_audio=1;
}
}


var gb_combo=[];
var gb_combo_move_x=[1,1,1,1,1,1,1,1,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];
var gb_combo_audio=1;


//____________________ GEN PRICE ____________________


function gb_price_node(price_y,price_x,price_num){
gb_temp_score+=price_num;
this.x=gb_map[price_y][price_x].x;
if(this.x<15){ this.x=15; }
if(this.x>245){ this.x=245; }
this.y=price_y*28-gb_top_y+gb_move_down-14+28;
this.w=Math.floor(Math.random()*19);
this.live=60;
this.num=price_num/100;
}


var gb_price=[];
var gb_price_move_x=[1,1,1,1,1,1,1,1,1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];


//____________________ GEN COIN-FIREBALL-WAVE ____________________


function gb_cfw_node(cfw_x,cfw_y,cfw_type){
this.x=cfw_x;
this.y=cfw_y;
this.spark_n=0;
this.type=cfw_type;
if(cfw_type==1){
this.crop_x=680;
this.crop_y=270;
this.sx=32;
this.sy=32;
this.w=3;
this.p=0;
this.n=0;
this.limit_y=484;
if(cfw_x<13){ this.ax=(13-cfw_x)/100; }
if(cfw_x>=13){ this.ax=-((cfw_x-13)/100); }
this.ay=(490-cfw_y)/100;
if(gb_sound==1){ document.getElementById("gb_coin_bubble_sound").play(); }
}
if(cfw_type==2){
this.crop_x=798;
this.crop_y=296;
this.sx=32;
this.sy=74;
this.w=0;
this.p=0;
this.n=0;
this.limit_y=470;
if(cfw_x<190){ this.ax=(190-cfw_x)/100; }
if(cfw_x>=190){ this.ax=-((cfw_x-190)/100); }
this.ay=(470-cfw_y)/100;
if(gb_sound==1){ document.getElementById("gb_fw_collected").play(); }
}
if(cfw_type==3){
this.crop_x=680;
this.crop_y=330;
this.sx=40;
this.sy=30;
this.w=0;
this.p=0;
this.n=0;
this.limit_y=490;
if(cfw_x<250){ this.ax=(250-cfw_x)/100; }
if(cfw_x>=250){ this.ax=-((cfw_x-250)/100); }
this.ay=(490-cfw_y)/100;
if(gb_sound==1){ document.getElementById("gb_fw_collected").play(); }
}
}


var gb_cfw=[];


//____________________ GEN SPARK ____________________


function gb_spark_node(spark_x,spark_y){
this.x=spark_x+Math.floor(Math.random()*20)-4;
this.y=spark_y-8;
this.size=26;
}


var gb_spark=[];


//____________________ GEN CUTED BALLS ____________________


function gb_cuted_node(cuted_y,cuted_x,cuted_type){
this.y=cuted_y;
this.x=cuted_x;
this.type=cuted_type;
this.s=Math.floor(Math.random()*4)*0.1+1;
this.n=50;
}


var gb_cuted=[];
