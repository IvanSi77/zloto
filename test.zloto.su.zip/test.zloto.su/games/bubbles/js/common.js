//____________________ COMMON ____________________


canvas=document.getElementById("canvas_bubbles");
ctx=canvas.getContext("2d");


function Cache(){
var _imgs=[];
var _addedImageCount=0;
var _loadedImgsCount=0;
this.addSpriteSource=function(src){
var img=new Image();
img.onload= function(){
_loadedImgsCount++;
}
img.src=src;
_imgs[src]=img;
_addedImageCount++;
}
this.getLoadedImagePc=function(){
return _loadedImgsCount*100/_addedImageCount;
}
this.getImage=function(src){
return _imgs[src];
}
}


var Cache=new Cache();


function waitImagesLoading(){
var pc=Cache.getLoadedImagePc();
if(pc<100){ setTimeout(waitImagesLoading,200); }
else{ requestAnimationFrame(gb_logic); }
}


var gb_pic_cannon=new Image();
gb_pic_cannon.src="/games/bubbles/images/gb_cannon.png";
var gb_pic_lamp=new Image();
gb_pic_lamp.src="/games/bubbles/images/gb_lamp.png";
var gb_pic_wings=new Image();
gb_pic_wings.src="/games/bubbles/images/gb_wings.png";
var gb_pic_top=new Image();
gb_pic_top.src="/games/bubbles/images/gb_top.png";
var gb_pic_bottom=new Image();
gb_pic_bottom.src="/games/bubbles/images/gb_bottom.png";
var gb_pic_items=new Image();
gb_pic_items.src="/games/bubbles/images/gb_items.png";
var gb_pic_things=new Image();
gb_pic_things.src="/games/bubbles/images/gb_things.png";


Cache.addSpriteSource("/games/bubbles/images/gb_cannon.png");
Cache.addSpriteSource("/games/bubbles/images/gb_lamp.png");
Cache.addSpriteSource("/games/bubbles/images/gb_wings.png");
Cache.addSpriteSource("/games/bubbles/images/gb_top.png");
Cache.addSpriteSource("/games/bubbles/images/gb_bottom.png");
Cache.addSpriteSource("/games/bubbles/images/gb_items.png");
Cache.addSpriteSource("/games/bubbles/images/gb_things.png");


//____________________ CANNON ANGLE ____________________


function gb_cursor(event){
if(!event){ event=window.event; }
if(event.pageX){ gb_mouse_x=event.pageX; gb_mouse_y=event.pageY; }
else if(event.clientX){
gb_mouse_x=event.clientX+(document.documentElement.scrollLeft || document.body.scrollLeft)-document.documentElement.clientLeft;
gb_mouse_y=event.clientY+(document.documentElement.scrollTop || document.body.scrollTop)-document.documentElement.clientTop;
}
gb_angle=-90-Math.atan2(gb_cannon_x-gb_mouse_x,gb_cannon_y-gb_mouse_y)/gb_radian;
if(gb_angle<0){ gb_angle=360+gb_angle; }
if(gb_angle<0){ gb_angle=360+gb_angle; }
if(gb_ball!=8){
if(gb_angle<205){ gb_angle=205; }
if(gb_angle>335){ gb_angle=335; }
}
else{
if(gb_angle<240){ gb_angle=240; }
if(gb_angle>300){ gb_angle=300; }
}
}


//____________________ OFFSET ____________________


function offset(){
var rect=document.getElementById("game_bubbles_bg").getBoundingClientRect();
var scrollLeft=window.pageXOffset || document.documentElement.scrollLeft;
var scrollTop=window.pageYOffset || document.documentElement.scrollTop;
gb_cannon_x=rect.left+scrollLeft+150;
gb_cannon_y=rect.top+scrollTop+518;
}


document.body.onmousemove=gb_cursor;
