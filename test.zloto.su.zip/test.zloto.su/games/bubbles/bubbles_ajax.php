<?php


require_once('../../config.php');


if(empty($game_bubbles_m)){ echo '������ ��������'; exit; }


require_once('bubbles_config.php');


if(empty($u_id)){ echo 'window.location="/login";'; exit; }
if(!isset($mydm['bubbles_level'])){ echo 'alert("no bubbles_level");'; exit; }
if(empty($_SESSION['bubbles_stime'])){ echo 'alert("��� ������");'; exit; }


if(empty($_POST['score']) || !isset($_POST['coins']) || !isset($_POST['fb']) || !isset($_POST['wave'])){ exit; }


$gb_score=$_POST['score'];
$gb_score=preg_replace('#[^0-9]+#','',$gb_score);
$gb_score=number_format($gb_score,0,'','');
if(empty($gb_score) || !is_numeric($gb_score) || strlen($gb_score)>10){  echo 'alert("wrong score");'; exit; }


$gb_coins=$_POST['coins'];
$gb_coins=preg_replace('#[^0-9]+#','',$gb_coins);
$gb_coins=number_format($gb_coins,0,'','');
if(!isset($gb_coins)){ $gb_coins=0; }
if(!is_numeric($gb_coins) || strlen($gb_coins)>4){ echo 'alert("wrong coins");'; exit; }


$gb_fb=$_POST['fb'];
$gb_fb=preg_replace('#[^0-9]+#','',$gb_fb);
$gb_fb=number_format($gb_fb,0,'','');
if(!isset($gb_fb)){ $gb_fb=0; }
if(!is_numeric($gb_coins) || strlen($gb_fb)>3){ echo 'alert("wrong fb");'; exit; }


$gb_wave=$_POST['wave'];
$gb_wave=preg_replace('#[^0-9]+#','',$gb_wave);
$gb_wave=number_format($gb_wave,0,'','');
if(!isset($gb_wave)){ $gb_wave=0; }
if(!is_numeric($gb_coins) || strlen($gb_wave)>3){ echo 'alert("wrong waves");'; exit; }


// ____________________ ��������� �� �������� �� ������� ������ ____________________


if($gb_coins-$mydm['bubbles_c']>5){ echo 'alert("collected many coins");'; exit; }
if($gb_fb-$mydm['bubbles_fb']>1){ echo 'alert("collected many fb");'; exit; }
if($gb_wave-$mydm['bubbles_w']>1){ echo 'alert("collected many waves");'; exit; }


// ____________________ ����� ������� ������ ____________________


if(!isset($_SESSION['bubbles_can'])){ exit; }
if(!isset($_SESSION['bubbles_n'])){ exit; }


$game_bubbles_level=$_SESSION['bubbles_n'];
$game_bubbles_can=$_SESSION['bubbles_can'];


if(!isset($game_bubbles_level) || $game_bubbles_level>181){ echo 'alert("level");'; exit; }


// ____________________ �������� �������� ����������� ____________________


$used_fb=0;
if($mydm['bubbles_fb']>0 && $mydm['bubbles_fb']>$gb_fb){
$used_fb=$mydm['bubbles_fb']-$gb_fb;
}


if($time-$_SESSION['bubbles_stime']<10+($game_bubbles_level+1)*2-$used_fb*20){
echo 'alert("too fast");';
exit;
}


// ____________________ ������� ____________________


$game_bubbles_ratesq=mysqli_query($db,"SELECT top,last FROM games WHERE name='bubbles' LIMIT 1") or die('cant select games');
$game_bubbles_ratesm=mysqli_fetch_assoc($game_bubbles_ratesq);


if(!isset($game_bubbles_ratesm['top'])){ exit; }


// ____________________ ������ ������ ____________________


$game_bubbles_tops=array();
eval($game_bubbles_ratesm['top']);


$game_bubbles_win_rbonus=0;


if($game_bubbles_can==1){
if(!isset($game_bubbles_tops[$game_bubbles_level]) || $gb_score>$game_bubbles_tops[$game_bubbles_level][2]){
$game_bubbles_win_rbonus=$game_bubbles_for_record;
$game_bubbles_tops[$game_bubbles_level]=array($mydm['avatar'],$mydm['login'],$gb_score);
}
}


$game_bubbles_up_tops='';


foreach($game_bubbles_tops as $gbn=>$gbv){
$game_bubbles_up_tops.=$gbn.'=>array(\''.$gbv[0].'\',\''.$gbv[1].'\','.$gbv[2].'),';
}


$game_bubbles_up_tops=rtrim($game_bubbles_up_tops,',');
$game_bubbles_up_tops='$game_bubbles_tops=array('.$game_bubbles_up_tops.');';


// ____________________ ������� ��������� ____________________


$game_bubbles_win_fbonus=0;
if(!empty($game_bubbles_blevels[$game_bubbles_level])){
$game_bubbles_win_fbonus=$game_bubbles_blevels[$game_bubbles_level][1];
}


$game_bubbles_r=$mydm['bubbles_r']+$game_bubbles_win_fbonus+$game_bubbles_win_rbonus;


// ____________________ ������ ��������� ��� ____________________


$game_bubbles_lasts=array();
eval($game_bubbles_ratesm['last']);
$game_bubbles_up_lasts='array(\''.$mydm['avatar'].'\',\''.$mydm['login'].'\','.$game_bubbles_level.','.$gb_score.','.$game_bubbles_r.'),';
for($n=0;$n!=4;$n++){
if(!empty($game_bubbles_lasts[$n])){
$game_bubbles_up_lasts.='array(\''.$game_bubbles_lasts[$n][0].'\',\''.$game_bubbles_lasts[$n][1].'\','.$game_bubbles_lasts[$n][2].','.$game_bubbles_lasts[$n][3].','.$game_bubbles_lasts[$n][4].'),';
}
}


$game_bubbles_up_lasts=rtrim($game_bubbles_up_lasts,',');
$game_bubbles_up_lasts='$game_bubbles_lasts=array('.$game_bubbles_up_lasts.');';


// ____________________ ������� ____________________


$game_bubbles_up_level=$game_bubbles_level;


if($game_bubbles_up_level>179){
$game_bubbles_up_level=0;
}


mysqli_query($db,"UPDATE users SET $game_bubbles_path=$game_bubbles_path+".($game_bubbles_win_fbonus+$game_bubbles_win_rbonus).",games_r=games_r+".($game_bubbles_win_fbonus+$game_bubbles_win_rbonus).",bubbles_r='$game_bubbles_r',bubbles_level='$game_bubbles_up_level',bubbles_c='$gb_coins',bubbles_fb='$gb_fb',bubbles_w='$gb_wave' WHERE uid='$u_id' LIMIT 1") or die('cant update users');
mysqli_query($db,"UPDATE games SET count=count+1,sum=sum+".(($game_bubbles_win_fbonus+$game_bubbles_win_rbonus)).",top=\"$game_bubbles_up_tops\",last=\"$game_bubbles_up_lasts\" WHERE name='bubbles' LIMIT 1") or die('cant update games');
mysqli_query($db,"UPDATE data SET games_c=games_c+1,games_r=games_r+".(($game_bubbles_win_fbonus+$game_bubbles_win_rbonus))) or die('cant update data');
$_SESSION['bubbles_n']=0;


echo 'document.getElementById("game_bubbles_cash").innerHTML="'.$game_bubbles_r.'";';
echo 'document.getElementById("game_bubbles_win_score").innerHTML="'.$gb_score.'";';
echo 'document.getElementById("game_bubbles_win_coins").innerHTML="'.($gb_coins-$mydm['bubbles_c']).'";';


if($game_bubbles_win_fbonus!=0){
echo 'document.getElementById("game_bubbles_win_fbonus").style.display="block";
document.getElementById("game_bubbles_win_fbonus_s").innerHTML="'.$game_bubbles_win_fbonus.'";';
}


if($game_bubbles_win_rbonus!=0){
echo 'document.getElementById("game_bubbles_win_rbonus").style.display="block";
document.getElementById("game_bubbles_win_rbonus_s").innerHTML="'.$game_bubbles_win_rbonus.'";';
}


echo 'document.getElementById("game_bubbles_win").style.display="block";';


if($game_bubbles_win_fbonus+$game_bubbles_win_rbonus>0){


$mydm[$game_bubbles_path]+=$game_bubbles_win_fbonus+$game_bubbles_win_rbonus;
$mydm[$game_bubbles_path]=number_format($mydm[$game_bubbles_path],4,'.','');


echo 'document.getElementById("my_'.$game_bubbles_path.'").innerHTML="'.$mydm[$game_bubbles_path].'";
document.getElementById("'.$game_bubbles_path.'_coin").style.display="block";
setTimeout(\'document.getElementById("'.$game_bubbles_path.'_coin").style.display="none";\',3000);';


}


?>
