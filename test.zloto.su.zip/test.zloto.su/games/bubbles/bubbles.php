<?php


if(empty($game_bubbles_m)){ echo '������ ��������'; exit; }


if(!isset($_COOKIE['bubbles_music']) || $_COOKIE['bubbles_music']==1){ $music=1; }else{ $music=0; }
if(!isset($_COOKIE['bubbles_sound']) || $_COOKIE['bubbles_sound']==1){ $sound=1; }else{ $sound=0; }
echo '<div class="title">'.$title.'<span id="sound" class="sound_'.$sound.'" onclick="gb_sound_toggle();"></span><span id="music" class="music_'.$music.'" onclick="gb_music_toggle();"></span></div>
<script type="text/javascript">var gb_music='.$music.'; var gb_sound='.$sound.';</script>';


require_once('bubbles_config.php');


$game_bubbles_level=$mydm['bubbles_level']+1;
$game_bubbles_can=1;


if(!empty($game_bubbles_blevels[$game_bubbles_level])){
if($mydm['bubbles_c']<$game_bubbles_blevels[$game_bubbles_level][0]){
$game_bubbles_can=0;
$game_bubbles_level--;
}
}


if(!isset($_SESSION['bubbles_can']) || $_SESSION['bubbles_can']!=$game_bubbles_can){
$_SESSION['bubbles_can']=$game_bubbles_can;
}


if(!isset($_SESSION['bubbles_n']) || $_SESSION['bubbles_n']!=$game_bubbles_level){
$_SESSION['bubbles_n']=$game_bubbles_level;
}


$game_bubbles_rates_q=mysqli_query($db,"SELECT * FROM games WHERE name='bubbles' LIMIT 1") or die('cant top');
$game_bubbles_rates_m=mysqli_fetch_assoc($game_bubbles_rates_q);


if(empty($game_bubbles_rates_m['name'])){ echo 'no game'; exit; }


// ____________________ ��������� ������ ____________________


$now=date('m',$time)+0;


if($now!=$game_bubbles_rates_m['period']){
mysqli_query($db,"UPDATE games SET top='',period='$now' WHERE name='bubbles' LIMIT 1") or die('cant update period');
$game_bubbles_rates_m['top']='';
}


$game_bubbles_tops=array();
eval($game_bubbles_rates_m['top']);


$game_bubbles_lasts=array();
eval($game_bubbles_rates_m['last']);


echo '<link rel="stylesheet" href="/games/bubbles/bubbles.css" type="text/css">';


// ____________________ ������ ____________________


if($mobile==0 && !empty($ads_banner_2_m)){


$ads_banner_2_c='ads_banner_2_c_'.$page;
$ads_banner_2_c=$$ads_banner_2_c;
if(!empty($ads_banner_2_c)){
$ads_value=str_replace('<','$ads_banner_2_last[]=array(',$d['ads_banner_2_last']);
$ads_banner_2_last=array();
eval($ads_value);
for($n=0;$n<sizeof($ads_banner_2_last);$n++){
if($ads_banner_2_last[$n][1]<$time){ array_splice($ads_banner_2_last,$n,1); $n--; }
}
shuffle($ads_banner_2_last);
echo '<div class="games_banner_2">';
for($n=0;$n<$ads_banner_2_c;$n++){
if(!empty($ads_banner_2_last[$n])){ echo '<a target="_blank" href="'.$serf_site.'/?ads=banner_2&id='.$ads_banner_2_last[$n][0].'"><img src="'.$ads_banner_2_last[$n][2].'"></a>'; }
else{ echo '<a target="_blank" href="'.$serf_site.'/ads_banner_2/"><img src="'.$serf_site.'/images/cabinet/ads_is_banner/46860.gif"></a>'; }
}
echo '</div>';
}


}


echo '<script type="text/javascript">


function gb_sound_toggle(){
if(gb_sound==1){ gb_sound=0; }
else{ gb_sound=1; }
document.cookie="bubbles_sound="+gb_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+gb_sound;
}


function gb_music_toggle(){
if(gb_music==1){
gb_music=0;
if(document.getElementById("gb_menu_music")!=null){ document.getElementById("gb_menu_music").pause(); }
if(document.getElementById("gb_play_music")!=null){ document.getElementById("gb_play_music").pause(); }
}
else{
gb_music=1;
if(document.getElementById("gb_menu_music")!=null){ document.getElementById("gb_menu_music").play(); }
if(document.getElementById("gb_play_music")!=null){ document.getElementById("gb_play_music").play(); }
}
document.cookie="bubbles_music="+gb_music+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("music").className="music_"+gb_music;
}


</script>';


echo '<a name="togame"></a>
<div class="game_bubbles_common">';


$game_bubbles_go=0;


if(!empty($_POST['start'])){


if($mydm['up_m']<$game_bubbles_up_m){ $game_bubbles_go=0; }
else{
$game_bubbles_go=1;
$_SESSION['bubbles_stime']=$time;
}


}


if($game_bubbles_go==0){


echo '<table class="game_bubbles_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td align="center" valign="middle">';


if($mydm['up_m']<$game_bubbles_up_m){
$game_bubbles_go=0;


echo '<table class="game_bubbles_tostart_table_active" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td align="center">
<div class="game_bubbles_tostart_active_info">
��������� ������ �� '.$game_bubbles_up_m.' ���.
</div>
</td>
</tr>
</table>';
}
else{
echo '<table id="game_bubbles_tostart_table" class="game_bubbles_tostart_table" style="display:table;" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td align="center">


<div class="game_bubbles_tostart_level">
������� '.$game_bubbles_level.' �� 180
</div>';


if($game_bubbles_can==0){
echo '
<div class="game_bubbles_tostart_toblevel">
��� ���������� ������ ���� ������� '.$game_bubbles_blevels[$game_bubbles_level+1][0].' �����.
</div>
';
}


echo '
<div class="game_bubbles_tostart_my_coins">
������� �����: '.$mydm['bubbles_c'].'
</div>


<div class="game_bubbles_tostart_info">
���������� � ���������� ������� ������ � �������.
<br>�������� ������ � �������� �������� ��� ��� �����.
<br>��������� ������� �� �������� ������ � �������.
<br>��������� �������� � ������ ���� ������� ������.
</div>


<form id="game_bubbles_start_form" action="/bubbles/#togame" method="POST">
<input type="hidden" name="a_time" value="'.$time.'">
<input type="hidden" name="start" value="1">
</form>
<div class="game_bubbles_stat_start" onclick="document.getElementById(\'game_bubbles_start_form\').submit();">������</div>


</td>
</tr>
</table>


<div class="game_bubbles_tostart_record_word">
������ ����� ������:
</div>


<table class="game_bubbles_tostart_record_table" style="display:table;" align="center" cellpadding="0px" cellspacing="0px">
<tr>';
if(empty($game_bubbles_tops[$game_bubbles_level])){
echo '<td align="center"><div class="game_bubbles_tostart_no_record">��� �������</div></td>';
}
else{
echo '<td class="game_bubbles_tostart_record_1"><img class="game_bubbles_tostart_record_img" src="'.$game_bubbles_tops[$game_bubbles_level][0].'"></td>
<td class="game_bubbles_tostart_record_2">'.$game_bubbles_tops[$game_bubbles_level][1].'</td>
<td class="game_bubbles_tostart_record_3">'.$game_bubbles_tops[$game_bubbles_level][2].'</td>';
}
echo '
</tr>
</table>
';


}


echo '
</td>
</tr>
</table>';
}


// ____________________ ���� ������ ____________________
// ____________________ ���� ������ ____________________
// ____________________ ���� ������ ____________________


if($game_bubbles_go==1){


if(!empty($game_bubbles_blevels[$game_bubbles_level])){
$game_bubbles_coins_minus=$game_bubbles_blevels[$game_bubbles_level][0];
mysqli_query($db,"UPDATE users SET bubbles_c=(bubbles_c-$game_bubbles_coins_minus) WHERE uid='$u_id' LIMIT 1") or die('cant update start');
$mydm['bubbles_c']-=$game_bubbles_coins_minus;
}


echo '


<table id="game_bubbles_game_table" class="game_bubbles_game_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td width="200px" valign="top"></td>
<td width="300px" valign="top"><div id="game_bubbles_bg" class="game_bubbles_play_bg"><canvas id="canvas_bubbles" class="game_bubbles_canvas" width="300px" height="550px">CTRL+F5</canvas></div>
<div id="game_bubbles_lose" class="game_bubbles_lose" style="display:none;" onclick="location.reload();">
<div class="game_bubbles_lose_title">�� ���������</div>
</div>
<div id="game_bubbles_win" class="game_bubbles_win" style="display:none;" onclick="location.reload();">
<div class="game_bubbles_win_title">������� '.$game_bubbles_level.' �������!</div>
<div class="game_bubbles_win_score">����� �������: <span id="game_bubbles_win_score">0</span></div>
<div class="game_bubbles_win_coins">����� �������: <span id="game_bubbles_win_coins">0</span></div>
<div id="game_bubbles_win_fbonus" class="game_bubbles_win_fbonus" style="display:none;">�� �����������: <font><span id="game_bubbles_win_fbonus_s">0.00</span> �</font></div>
<div id="game_bubbles_win_rbonus" class="game_bubbles_win_rbonus" style="display:none;">�� ����� ������: <font><span id="game_bubbles_win_rbonus_s">0.00</span> �</font></div>
</div>';
if(!empty($game_bubbles_blevels[$game_bubbles_level])){
echo '<div class="game_bubbles_its_blevel" id="game_bubbles_its_blevel" style="display:block;">�������� �������!<br>������� '.$game_bubbles_blevels[$game_bubbles_level][0].' �����.</div>
<script type="text/javascript">
setTimeout("document.getElementById(\'game_bubbles_its_blevel\').style.display=\'none\';",3000);
</script>
';
}
if($game_bubbles_can==0){
echo '
<div class="game_bubbles_its_nocoins" id="game_bubbles_its_nocoins" style="display:block;">
��� �������� �� �������� �������<br>�������� ������� �����: '.($game_bubbles_blevels[$game_bubbles_level+1][0]-$mydm['bubbles_c']).'
</div>
<script type="text/javascript">
setTimeout("document.getElementById(\'game_bubbles_its_nocoins\').style.display=\'none\';",4000);
</script>
';
}
echo '</td>
<td width="200px" valign="top"></td>
</tr>
</table>
<table width="700px" align="center" cellpadding="0px" cellspacing="0px">
<tr><td><div id="game_bubbles_fireball_div" class="game_bubbles_fireball_div"></div><div id="game_bubbles_wave_div" class="game_bubbles_wave_div"></div></td></tr>
</table>


';
}


if($game_bubbles_show==0){
echo '<table class="game_bubbles_rates_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td class="game_bubbles_rate_title">����������: <font id="game_bubbles_cash">'.$mydm['bubbles_r'].'</font> �</td>
<td class="game_bubbles_rate_cash"></td>
</tr>
</table>';
}
else{
echo '
<table class="game_bubbles_rates_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td class="game_bubbles_rate_title">��������� ����</td>
<td class="game_bubbles_rate_cash">����������: <font id="game_bubbles_cash">'.$mydm['bubbles_r'].'</font> �</td>
</tr>
</table>


<div class="game_bubbles_rate_div">';


foreach($game_bubbles_lasts as $game_bubbles_rm){
echo '<div class="game_bubbles_rate_div_cont">
<table class="game_bubbles_rate_table" align="center" cellpadding="0px" cellspacing="10px">
<tr>
<td><img class="game_bubbles_rate_avatar" src="'.$game_bubbles_rm[0].'"></td>
<td><div class="game_bubbles_rate_login">'.$game_bubbles_rm[1].'</div></td>
<td><div class="game_bubbles_rate_level_num">'.$game_bubbles_rm[2].'</div></td>
<td><div class="game_bubbles_rate_level_word">�������</div></td>
<td><div class="game_bubbles_rate_points_i">&nbsp;</div></td>
<td><div class="game_bubbles_rate_points_a">'.$game_bubbles_rm[3].'</div></td>
<td><div class="game_bubbles_rate_sum_i">&nbsp;</div></td>
<td><div class="game_bubbles_rate_sum_a">'.$game_bubbles_rm[4].'</div></td>
</tr>
</table>
</div>';
}


echo '</div>';
}


echo '</div>


<style>
::selection {background:none;}
</style>
';


if($game_bubbles_go==0){


if(!isset($_COOKIE['bubbles_music']) || $_COOKIE['bubbles_music']==1){ $autoplay='autoplay'; }


echo '<audio id="gb_menu_music" preload loop '.$autoplay.'>
<source src="/games/bubbles/sounds/gb_menu_music.mp3" type="audio/mpeg">
</audio>';


}


if($game_bubbles_go==1){


if(!isset($_COOKIE['bubbles_music']) || $_COOKIE['bubbles_music']==1){ $autoplay='autoplay'; }


echo '
<audio id="gb_play_start" preload '.$autoplay.'>
<source src="/games/bubbles/sounds/gb_play_start.mp3" type="audio/mpeg">
</audio>


<audio id="gb_play_music" preload loop '.$autoplay.'>
<source src="/games/bubbles/sounds/gb_play_music.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bubble_shoot" preload>
<source src="/games/bubbles/sounds/gb_bubble_shoot.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bomb_shoot" preload>
<source src="/games/bubbles/sounds/gb_bomb_shoot.mp3" type="audio/mpeg">
</audio>


<audio id="gb_steel_ball_shoot" preload>
<source src="/games/bubbles/sounds/gb_steel_ball_shoot.mp3" type="audio/mpeg">
</audio>


<audio id="gb_fireball_shoot" preload>
<source src="/games/bubbles/sounds/gb_fireball_shoot.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bomb_burning" preload loop>
<source src="/games/bubbles/sounds/gb_bomb_burning.mp3" type="audio/mpeg">
</audio>


<audio id="gb_fireball_burning" preload loop>
<source src="/games/bubbles/sounds/gb_fireball_burning.mp3" type="audio/mpeg">
</audio>


<audio id="gb_border" preload>
<source src="/games/bubbles/sounds/gb_border.mp3" type="audio/mpeg">
</audio>


<audio id="gb_air_bubble_1" preload>
<source src="/games/bubbles/sounds/gb_air_bubble.mp3" type="audio/mpeg">
</audio>


<audio id="gb_air_bubble_2" preload>
<source src="/games/bubbles/sounds/gb_air_bubble.mp3" type="audio/mpeg">
</audio>


<audio id="gb_air_bubble_3" preload>
<source src="/games/bubbles/sounds/gb_air_bubble.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bubble_burst_1" preload>
<source src="/games/bubbles/sounds/gb_bubble_burst.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bubble_burst_2" preload>
<source src="/games/bubbles/sounds/gb_bubble_burst.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bubble_burst_3" preload>
<source src="/games/bubbles/sounds/gb_bubble_burst.mp3" type="audio/mpeg">
</audio>


<audio id="gb_wave_blast" preload>
<source src="/games/bubbles/sounds/gb_wave_blast.mp3" type="audio/mpeg">
</audio>


<audio id="gb_no_ammo" preload>
<source src="/games/bubbles/sounds/gb_no_ammo.mp3" type="audio/mpeg">
</audio>


<audio id="gb_boom_sound" preload>
<source src="/games/bubbles/sounds/gb_boom_sound.mp3" type="audio/mpeg">
</audio>


<audio id="gb_fireball_boom_sound" preload>
<source src="/games/bubbles/sounds/gb_fireball_boom_sound.mp3" type="audio/mpeg">
</audio>


<audio id="gb_rate_sound_1" preload>
<source src="/games/bubbles/sounds/gb_rate_sound_1.mp3" type="audio/mpeg">
</audio>


<audio id="gb_rate_sound_2" preload>
<source src="/games/bubbles/sounds/gb_rate_sound_2.mp3" type="audio/mpeg">
</audio>


<audio id="gb_rate_sound_3" preload>
<source src="/games/bubbles/sounds/gb_rate_sound_3.mp3" type="audio/mpeg">
</audio>


<audio id="gb_rate_sound_4" preload>
<source src="/games/bubbles/sounds/gb_rate_sound_4.mp3" type="audio/mpeg">
</audio>


<audio id="gb_rate_sound_5" preload>
<source src="/games/bubbles/sounds/gb_rate_sound_5.mp3" type="audio/mpeg">
</audio>


<audio id="gb_combo_sound_1" preload>
<source src="/games/bubbles/sounds/gb_combo_sound.mp3" type="audio/mpeg">
</audio>


<audio id="gb_combo_sound_2" preload>
<source src="/games/bubbles/sounds/gb_combo_sound.mp3" type="audio/mpeg">
</audio>


<audio id="gb_coin_bubble_sound" preload>
<source src="/games/bubbles/sounds/gb_coin_bubble_sound.mp3" type="audio/mpeg">
</audio>


<audio id="gb_fw_collected" preload>
<source src="/games/bubbles/sounds/gb_fw_collected.mp3" type="audio/mpeg">
</audio>


<audio id="gb_alert_sound" preload>
<source src="/games/bubbles/sounds/gb_alert_sound.mp3" type="audio/mpeg">
</audio>


<audio id="gb_lose_sound" preload>
<source src="/games/bubbles/sounds/gb_lose_sound.mp3" type="audio/mpeg">
</audio>


<audio id="gb_move_down_mine" preload>
<source src="/games/bubbles/sounds/gb_move_down_mine.mp3" type="audio/mpeg">
</audio>


<audio id="gb_horror" preload>
<source src="/games/bubbles/sounds/gb_horror.mp3" type="audio/mpeg">
</audio>


<audio id="gb_brick_collide" preload>
<source src="/games/bubbles/sounds/gb_brick_collide.mp3" type="audio/mpeg">
</audio>


<audio id="gb_wood_collide" preload>
<source src="/games/bubbles/sounds/gb_wood_collide.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bubble_collide" preload>
<source src="/games/bubbles/sounds/gb_bubble_collide.mp3" type="audio/mpeg">
</audio>


<audio id="gb_bubble_expand" preload>
<source src="/games/bubbles/sounds/gb_bubble_expand.mp3" type="audio/mpeg">
</audio>


<audio id="gb_color_bubble" preload>
<source src="/games/bubbles/sounds/gb_color_bubble.mp3" type="audio/mpeg">
</audio>


<audio id="gb_win_sound" preload>
<source src="/games/bubbles/sounds/gb_win_sound.mp3" type="audio/mpeg">
</audio>';


$game_bubbles_mq=mysqli_query($db,"SELECT map FROM game_bubbles WHERE id=".$game_bubbles_level." LIMIT 1");
$game_bubbles_mm=mysqli_fetch_row($game_bubbles_mq);
if(empty($game_bubbles_mm[0])){
exit;
}


$game_bubbles_mm[0]=trim($game_bubbles_mm[0]);
$gb_lines=explode("\r\n",$game_bubbles_mm[0]);
$gb_str_map='';


foreach($gb_lines as $gb_lin){
preg_match_all('# ?([^ $]+)#',$gb_lin,$gb_lin_m);
foreach($gb_lin_m[1] as $gb_lm){
$gb_str_map.=$gb_lm.',';
}
}


$gb_str_map=rtrim($gb_str_map,',');


echo '
<script type="text/javascript" src="/games/bubbles/js/common.js"></script>
<script type="text/javascript" src="/games/bubbles/js/gen_speceffects.js"></script>
<script type="text/javascript" src="/games/bubbles/js/draw_speceffects.js"></script>


<script type="text/javascript">


var gb_height='.sizeof($gb_lines).';
var gb_all_balls=new Array('.$gb_str_map.');
var gb_level='.$game_bubbles_level.';
var gb_record_amount=';
if(!empty($game_bubbles_tops[$game_bubbles_level][2])){
echo $game_bubbles_tops[$game_bubbles_level][2];
}
else{ echo '0'; }
echo ';
var gb_coins_amount='.$mydm['bubbles_c'].';
var gb_fireball_amount='.$mydm['bubbles_fb'].';
var gb_wave_amount='.$mydm['bubbles_w'].';
var gb_width=9;
var gb_top_y=gb_height*28;
var gb_map=new Array();


</script>


<script type="text/javascript" src="/games/bubbles/js/bubbles.js"></script>';


}


?>
