<?php


require_once('config.php');


// ____________________ ��������� ____________________


$bot_up=3; // 1 - ���� ����� ��������� ������ � PAYEER, 2 - ������ � FREE-KASSA, 3 - � PAYEER � FREE-KASSA
$bot_w_payeer=1; // 1 - ���� ����� �������� �� PAYEER, 0 - �� �����
$bot_w_qiwi=1; // 1 - ���� ����� �������� �� QIWI, 0 - �� �����
$bot_w_yandex=1; // 1 - ���� ����� �������� �� YANDEX, 0 - �� �����
$bot_w_limit=1000; // ������ ���� ����� ������� ����������� �� �����. ������ 1000 ������� �� ���� �����
$bot_online=10; // ����� ������� ����� ������� ���� �� ������ ������
$bot_uw=0; // 0 - ���� �� ����� ��������� � ��������, ���� �� ���� ������ �������������, 1 - �����


// ____________________ ������ �� ������� ____________________


$s_q=mysqli_query($db,"SELECT * FROM data LIMIT 1") or die('cant select data');
$d=mysqli_fetch_assoc($s_q);
if(!isset($d['users'])){ exit('data error'); }

if(isset($d['deps_start'])){


$d['deps_start']=strtotime($d['deps_start']);
if($d['deps_start']==''){
$d['deps_start']=$time+31536000;
}
if($time<$d['deps_start']){
$d['deps_stop_dep']=1;
$d['deps_stop_take']=1;
}


}


$bot_online*=60;
$bot_atime=3600*4;


$up_sum=number_format($d['up_payeer_s']+$d['up_fk_s']+$d['pseudo_up'],2,'.','');
$w_sum=number_format($d['w_payeer_s']+$d['w_fk_s']+$d['pseudo_w'],2,'.','');
$kassa=number_format($up_sum-$w_sum,0,'','');


if($auth_m==1){
$auth=array();
eval($d['auth']);
}


// ____________________ ��������� ������ ������ ____________________


if($d['add_user_m']==1 && $d['add_user_t']<$time && $d['add_user_p1']!=0 && $d['add_user_p2']!=0 && $d['add_user_p2']>=$d['add_user_p1']){
$s_q=mysqli_query($db,"SHOW TABLE STATUS LIKE 'users'") or die('cant status users');
$s_m=mysqli_fetch_assoc($s_q);
if(!empty($s_m['Auto_increment'])){
mysqli_query($db,"ALTER TABLE users AUTO_INCREMENT=".($s_m['Auto_increment']+1)) or die('cant ai users maybe is innodb no myisam');
$add_user_t=$time+rand($d['add_user_p1'],$d['add_user_p2'])*60;
mysqli_query($db,"UPDATE data SET users_total=".$s_m['Auto_increment'].",users_pseudo_today=users_pseudo_today+1,add_user_t='$add_user_t'") or die('cant users_total');
echo '���� ���������������: '.date('d.m.y H:i:s',$time).'<br>';
}
}


// ____________________ ��������� ����� �� ��������� ____________________


if(!empty($up_m_m) && ($time>$d['deps_start']+600 || $bot_uw==1) && ($bot_up==1 || $bot_up==2 || $bot_up==3) && $d['add_up_m']==1 && $d['add_up_m']==1 && $d['add_up_t']<$time && $d['add_up_p1']!=0 && $d['add_up_p2']!=0 && $d['add_up_p2']>=$d['add_up_p1'] && $d['add_up_min']>0 && $d['add_up_max']>0){
$need_up=1;
}


// ____________________ ��������� ����� �� �������� ____________________


if(!empty($w_m) && ($time>$d['deps_start']+600 || $bot_uw==1) && $kassa>$bot_w_limit && (($bot_w_payeer==1 && $d['payeer_mode']!=3) || ($bot_w_qiwi==1 && $d['qiwi_mode']!=3) || ($bot_w_yandex==1 && $d['yandex_mode']!=3)) && $d['add_w_m']==1 && $d['add_w_t']<$time && $d['add_w_p1']!=0 && $d['add_w_p2']!=0 && $d['add_w_p2']>=$d['add_w_p1']){
$need_w=1;
}


// ____________________ ��������� ����� �� �������� ____________________


if($time>$d['deps_start']+600 && $d['deps_stop_take']==0 && $d['add_dr_m']==1 && $d['add_dr_t']<$time && $d['add_dr_p1']!=0 && $d['add_dr_p2']!=0 && $d['add_dr_p2']>=$d['add_dr_p1'] && isset($d['add_dr_min']) && isset($d['add_dr_max'])){
$need_take=1;
}


$bots=array();


if(!empty($need_up) || !empty($need_w) || !empty($need_take)){
$s_q=mysqli_query($db,"SELECT * FROM users WHERE bot=1");
while($s_m=mysqli_fetch_assoc($s_q)){
if(empty($s_m['avatar']) || empty($s_m['login']) || empty($s_m['p_payeer']) || empty($s_m['p_qiwi']) || empty($s_m['p_yandex'])){
continue;
}
$bots[]=$s_m;
}
}


if(empty($bots)){ exit; }


// ____________________ ��������� ������ ���������� ____________________


if($need_up==1){


$need_clean_up=1;
$rnd_up=array();


for($n=0;$n<sizeof($bots);$n++){
if($bots[$n]['sp_ban_1']==0){ $need_clean_up=0; $rnd_up[]=$bots[$n]; }
}


if($need_clean_up==1){
for($n=0;$n<sizeof($bots);$n++){ $rnd_up[]=$bots[$n]; }
}


if(empty($rnd_up)){ echo 'empty $rnd_up'; exit; }


shuffle($rnd_up);


$pseudo_up=rand($d['add_up_min'],$d['add_up_max']);
// ��������� ������� ������
if(rand(1,5)==1){ $pseudo_up+=rand(1,9)/10; }
$pseudo_up=number_format($pseudo_up,2,'.','');
$add_up_t=$time+rand($d['add_up_p1'],$d['add_up_p2'])*60;
if($bot_up==1){ $up_purse='p'; }
if($bot_up==2){ $up_purse='fk'; }
if($bot_up==3){ if(rand(1,2)==1){ $up_purse='p'; } else{ $up_purse='fk'; } }


// ��� �������� ����������


$contest_up='';


$contest_up_d_1=strtotime($d['contest_up_d_1']);
$contest_up_d_2=strtotime($d['contest_up_d_2']);


if(!empty($contest_up_m) && $time>$contest_up_d_1 && $time<$contest_up_d_2 && date('Y',$contest_up_d_1)!=2000){ $contest_up=',contest_up=contest_up+'.$pseudo_up; }


if($auth_m==1 && $rnd_up[0]['nrc']+$bot_atime<$time){
$auth_up=',nrc='.$time;
$auth_f=0;
$auth_t='';
for($n=0;$n<sizeof($auth);$n++){ if($auth[$n][0]==$rnd_up[0]['uid']){ $auth_f=1; break; } }
if($auth_f==0){
array_unshift($auth,array($rnd_up[0]['uid'],$rnd_up[0]['avatar'],$rnd_up[0]['login']));
for($n=0;$n<$auth_c;$n++){
if(empty($auth[$n])){ break; }
$auth_t.='$auth[]=array('.$auth[$n][0].',"'.$auth[$n][1].'","'.$auth[$n][2].'");';
}
$auth_t=',auth=\''.$auth_t.'\'';
}
}


if($need_clean_up==0){
mysqli_query($db,"UPDATE users SET date_2='$time',date_2_word='".date('d.m.y H:i:s',$time)."',up_m=up_m+$pseudo_up,sp_ban_1=5 $contest_up $auth_up WHERE uid='".$rnd_up[0]['uid']."' LIMIT 1") or die('cant up 0');
}


if($need_clean_up==1){
for($n=0;$n<sizeof($bots);$n++){
if($bots[$n]['uid']!=$rnd_up[0]['uid']){
mysqli_query($db,"UPDATE users SET sp_ban_1=0 WHERE uid='".$bots[$n]['uid']."' LIMIT 1") or die('cant up 1');
}
}
mysqli_query($db,"UPDATE users SET date_2='$time',date_2_word='".date('d.m.y H:i:s',$time)."',up_m=up_m+$pseudo_up $contest_up $auth_up WHERE uid='".$rnd_up[0]['uid']."' LIMIT 1") or die('cant up 2');
}


$up_last_t='';
$up_last=array();
eval($d['up_last']);


array_unshift($up_last,array($time,$rnd_up[0]['uid'],$rnd_up[0]['avatar'],$rnd_up[0]['login'],$up_purse,$pseudo_up));


for($n=0;$n<$up_last_c;$n++){
if(empty($up_last[$n])){ break; }
$up_last_t.='$up_last[]=array("'.$up_last[$n][0].'","'.$up_last[$n][1].'","'.$up_last[$n][2].'","'.$up_last[$n][3].'","'.$up_last[$n][4].'","'.$up_last[$n][5].'","'.$up_last[$n][6].'");';
}


mysqli_query($db,"UPDATE data SET add_up_t='$add_up_t',pseudo_up=pseudo_up+$pseudo_up,up_last='$up_last_t' $auth_t LIMIT 1") or die('cant up 3');


mysqli_query($db,"INSERT INTO online (ip,last_time,uid,login,avatar) VALUES ('bot','".($time+$bot_online)."','".$rnd_up[0]['uid']."','".$rnd_up[0]['login']."','".$rnd_up[0]['avatar']."')");


// ____________________ ��� ������������� �� ����������� ____________________


$top_up_m_t='';


$s_q=mysqli_query($db,"SELECT uid,avatar,login,up_m FROM users WHERE ban=0 ORDER BY up_m DESC LIMIT ".$top_up_m_c) or die ('cant select top_up_m');
while($s_m=mysqli_fetch_assoc($s_q)){
$top_up_m_t.='$top_up_m[]=array("'.$s_m['uid'].'","'.$s_m['avatar'].'","'.$s_m['login'].'","'.$s_m['up_m'].'");';
}


mysqli_query($db,"UPDATE data SET top_up_m='$top_up_m_t' LIMIT 1") or die('cant update data top_up_m');


echo date('d.m.y H:i:s',$time).' ��� ['.$rnd_up[0]['uid'].'] �������� '.$pseudo_up.' ���.<br>';


}


// ____________________ ��������� ������ ������� ____________________


if($need_w==1){


$need_clean_w=1;
$rnd_w=array();


for($n=0;$n<sizeof($bots);$n++){
if($bots[$n]['sp_ban_2']==0){ $need_clean_w=0; $rnd_w[]=$bots[$n]; }
}


if($need_clean_w==1){
for($n=0;$n<sizeof($bots);$n++){ $rnd_w[]=$bots[$n]; }
}


if(empty($rnd_w)){ echo 'empty $rnd_w'; exit; }


shuffle($rnd_w);


$purse_a=array();


if($bot_w_payeer==1 && $d['payeer_mode']!=3){ $purse_a[]='payeer'; }
if($bot_w_qiwi==1 && $d['qiwi_mode']!=3){ $purse_a[]='qiwi'; }
if($bot_w_yandex==1 && $d['yandex_mode']!=3){ $purse_a[]='yandex'; }


if(empty($purse_a)){
echo '�� �� ��� ��������';
exit;
}


shuffle($purse_a);


$purse_name=$purse_a[0];


$w_min=number_format($d[$purse_name.'_min'],0,'','');
$w_max=$w_min+10;
$pseudo_w=rand($w_min,$w_max);
// ��������� ������� ������
if(rand(1,5)==1){ $pseudo_w+=rand(1,9)/10; }
$pseudo_w=number_format($pseudo_w,2,'.','');
$add_w_t=$time+rand($d['add_w_p1'],$d['add_w_p2'])*60;


if($auth_m==1 && $rnd_w[0]['nrc']+$bot_atime<$time){
$auth_w=',nrc='.$time;
$auth_f=0;
$auth_t='';
for($n=0;$n<sizeof($auth);$n++){ if($auth[$n][0]==$rnd_w[0]['uid']){ $auth_f=1; break; } }
if($auth_f==0){
array_unshift($auth,array($rnd_w[0]['uid'],$rnd_w[0]['avatar'],$rnd_w[0]['login']));
for($n=0;$n<$auth_c;$n++){
if(empty($auth[$n])){ break; }
$auth_t.='$auth[]=array('.$auth[$n][0].',"'.$auth[$n][1].'","'.$auth[$n][2].'");';
}
$auth_t=',auth=\''.$auth_t.'\'';
}
}


if($need_clean_w==0){
mysqli_query($db,"UPDATE users SET date_2='$time',date_2_word='".date('d.m.y H:i:s',$time)."',w_s=w_s+$pseudo_w,sp_ban_2=5 $auth_w WHERE uid='".$rnd_w[0]['uid']."' LIMIT 1") or die('cant w 0');
}


if($need_clean_w==1){
for($n=0;$n<sizeof($bots);$n++){
if($bots[$n]['uid']!=$rnd_w[0]['uid']){
mysqli_query($db,"UPDATE users SET sp_ban_2=0 WHERE uid='".$bots[$n]['uid']."' LIMIT 1") or die('cant w 1');
}
}
mysqli_query($db,"UPDATE users SET date_2='$time',date_2_word='".date('d.m.y H:i:s',$time)."',w_s=w_s+$pseudo_w $auth_w WHERE uid='".$rnd_w[0]['uid']."' LIMIT 1") or die('cant w 2');
}


$w_last_t='';
$w_last=array();
eval($d['w_last']);


array_unshift($w_last,array($time,$rnd_w[0]['uid'],$rnd_w[0]['avatar'],$rnd_w[0]['login'],$purse_name,$pseudo_w,substr_replace($rnd_w[0]['p_'.$purse_name],'XXX',-3)));


for($n=0;$n<$w_last_c;$n++){
if(empty($w_last[$n])){ break; }
$w_last_t.='$w_last[]=array("'.$w_last[$n][0].'","'.$w_last[$n][1].'","'.$w_last[$n][2].'","'.$w_last[$n][3].'","'.$w_last[$n][4].'","'.$w_last[$n][5].'","'.$w_last[$n][6].'");';
}


mysqli_query($db,"UPDATE data SET add_w_t='$add_w_t',pseudo_w=pseudo_w+$pseudo_w,w_last='$w_last_t' LIMIT 1") or die('cant w 3');


mysqli_query($db,"INSERT INTO online (ip,last_time,uid,login,avatar) VALUES ('bot','".($time+$bot_online)."','".$rnd_w[0]['uid']."','".$rnd_w[0]['login']."','".$rnd_w[0]['avatar']."')");


echo date('d.m.y H:i:s',$time).' ��� ['.$rnd_w[0]['uid'].'] ����� '.$pseudo_w.' ���.<br>';


}


// ____________________ ��������� ������ ���� ____________________


if($need_take==1){


$need_clean_take=1;
$rnd_take=array();


for($n=0;$n<sizeof($bots);$n++){
if($bots[$n]['sp_ban_3']==0){ $need_clean_take=0; $rnd_take[]=$bots[$n]; }
}


if($need_clean_take==1){
for($n=0;$n<sizeof($bots);$n++){ $rnd_take[]=$bots[$n]; }
}


if(empty($rnd_take)){ echo 'empty $rnd_take'; exit; }


shuffle($rnd_take);


$pseudo_dr=rand($d['add_dr_min'],$d['add_dr_max']);
// ��������� �������
$pseudo_dr+=rand(1,9999)/10000;
$pseudo_dr=number_format($pseudo_dr,4,'.','');
$add_dr_t=$time+rand($d['add_dr_p1'],$d['add_dr_p2'])*60;


if($auth_m==1 && $rnd_take[0]['nrc']+$bot_atime<$time){
$auth_take=',nrc='.$time;
$auth_f=0;
$auth_t='';
for($n=0;$n<sizeof($auth);$n++){ if($auth[$n][0]==$rnd_take[0]['uid']){ $auth_f=1; break; } }
if($auth_f==0){
array_unshift($auth,array($rnd_take[0]['uid'],$rnd_take[0]['avatar'],$rnd_take[0]['login']));
for($n=0;$n<$auth_c;$n++){
if(empty($auth[$n])){ break; }
$auth_t.='$auth[]=array('.$auth[$n][0].',"'.$auth[$n][1].'","'.$auth[$n][2].'");';
}
$auth_t=',auth=\''.$auth_t.'\'';
}
}


if($need_clean_take==0){
mysqli_query($db,"UPDATE users SET date_2='$time',date_2_word='".date('d.m.y H:i:s',$time)."',deps_r=deps_r+$pseudo_dr,sp_ban_3=5 $auth_take WHERE uid='".$rnd_take[0]['uid']."' LIMIT 1") or die('cant take 0');
}


if($need_clean_take==1){
for($n=0;$n<sizeof($bots);$n++){
if($bots[$n]['uid']!=$rnd_take[0]['uid']){
mysqli_query($db,"UPDATE users SET sp_ban_3=0 WHERE uid='".$bots[$n]['uid']."' LIMIT 1") or die('cant take 1');
}
}
mysqli_query($db,"UPDATE users SET date_2='$time',date_2_word='".date('d.m.y H:i:s',$time)."',deps_r=deps_r+$pseudo_dr $auth_take WHERE uid='".$rnd_take[0]['uid']."' LIMIT 1") or die('cant take 2');
}


mysqli_query($db,"INSERT INTO deps_take (uid,login,avatar,sum,date,date_word) VALUES ('".$rnd_take[0]['uid']."','".$rnd_take[0]['login']."','".$rnd_take[0]['avatar']."','$pseudo_dr','$time','".date('d.m.y H:i:s',$time)."')") or die('cant insert deps_take');
$last_id=0+mysqli_insert_id($db);
mysqli_query($db,"DELETE FROM deps_take WHERE id<".($last_id-20));
mysqli_query($db,"OPTIMIZE TABLE deps_take") or die('cant optimize deps_take');


mysqli_query($db,"UPDATE data SET add_dr_t='$add_dr_t',pseudo_dr=pseudo_dr+$pseudo_dr $auth_t LIMIT 1") or die('cant take 3');


mysqli_query($db,"INSERT INTO online (ip,last_time,uid,login,avatar) VALUES ('bot','".($time+$bot_online)."','".$rnd_take[0]['uid']."','".$rnd_take[0]['login']."','".$rnd_take[0]['avatar']."')");


echo date('d.m.y H:i:s',$time).' ��� ['.$rnd_take[0]['uid'].'] ������ '.$pseudo_dr.' ���.<br>';


}


?>
