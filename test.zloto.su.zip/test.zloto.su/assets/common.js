"use strict";


if(!window.requestAnimationFrame){
window.requestAnimationFrame=(function() {
return window.webkitRequestAnimationFrame ||
window.mozRequestAnimationFrame ||
window.oRequestAnimationFrame ||
window.msRequestAnimationFrame ||
function(callback,element){
window.setTimeout(callback,1000/60);
};
})();
}


// ____________________ ���� ������������ �� ��������� ������ ____________________


if(((window!=undefined && window.innerWidth!=undefined && window.innerWidth<1024) || (screen!=undefined && screen.width!=undefined && screen.width<1024)) && !document.cookie.match(/mobile_asked/g)){
document.cookie="mobile_asked=1;path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
if(confirm("������� �� ��������� ������ ?")){
location.href="/?mobile=1";
}
}


// ____________________ �������� ���������� ������� ____________________


function ads_block_check(){
if(window==window.top){
var ads_block_v=0;
if(document.getElementById("ads_banner")==null){ ads_block_v=1; }
else{
var ablock_c=document.getElementById("ads_banner");
try{
var ablock_computed=getComputedStyle(ablock_c);
if(ablock_computed.display.match(/none/g)){ ads_block_v=1; }
if(ablock_computed.visibility.match(/hidden/g)){ ads_block_v=1; }
}
catch(e){}
try{
if(ablock_c.className==undefined || ablock_c.className!="ads banner" || ablock_c.style==undefined || ablock_c.style.display==undefined
|| ablock_c.style.display.match(/none/g) || ablock_c.style.height==undefined || ablock_c.style.height!="1px"){ ads_block_v=1; }
}
catch(e){}
}
if(ads_block_v==1){ alert("����������, ��������� ����������� �������.");
}}}


// ____________________ � ������� - ��� � ������ ____________________


function ban(ban_mode,ban_id){
var ban_text="����� ��������?";
if(ban_mode==0){ ban_text="����� ���������?"; }
if(confirm(ban_text)){
document.getElementById("ban_mode").value=ban_mode;
document.getElementById("ban_id").value=ban_id;
document.getElementById("form_ban").submit();
}
}


// ____________________ ����� �������� ������� �������� �� ���� ��������� ____________________


if(typeof HTMLElement!="undefined" && !HTMLElement.prototype.insertAdjacentElement){
HTMLElement.prototype.insertAdjacentElement=function(where,parsedNode){
switch(where){
case 'beforeBegin':
this.parentNode.insertBefore(parsedNode,this)
break;
case 'afterBegin':
this.insertBefore(parsedNode,this.firstChild);
break;
case 'beforeEnd':
this.appendChild(parsedNode);
break;
case 'afterEnd':
if(this.nextSibling) this.parentNode.insertBefore(parsedNode,this.nextSibling);
else this.parentNode.appendChild(parsedNode);
break;
}
}


HTMLElement.prototype.insertAdjacentHTML=function(where,htmlStr){
var r=this.ownerDocument.createRange();
r.setStartBefore(this);
var parsedHTML=r.createContextualFragment(htmlStr);
this.insertAdjacentElement(where,parsedHTML)
}


HTMLElement.prototype.insertAdjacentText=function(where,txtStr){
var parsedText=document.createTextNode(txtStr)
this.insertAdjacentElement(where,parsedText)
}
}


// ____________________ ��������� ���� ____________________


function left_menu(){
if(document.getElementById("left_menu_common").style.display=="none"){
document.getElementById("left_menu_title").innerHTML="�������� ����";
document.getElementById("left_menu_common").style.display="block";
}
else{
document.getElementById("left_menu_title").innerHTML="�������� ����";
document.getElementById("left_menu_common").style.display="none";
}
}


// ____________________ �������� ������ ____________________


function view(view_name){
if(document.getElementById(view_name).style.display=="none"){ document.getElementById(view_name).style.display="block"; }
else{ document.getElementById(view_name).style.display="none"; }
}


// ____________________ ������ �� ������� ____________________


var timer_word_d_1=new Array(2,3,4,22,23,24,32,33,34,42,43,44,52,53,54,62,63,64,72,73,74,82,83,84,92,93,94);
var timer_word_d_2=new Array(1,21,31,41,51,61,71,81,91);


function timer_word_text(digits,text_1,text_2,text_3){
var found=0;
for(var n=0;n<timer_word_d_1.length;n++){
if(digits==timer_word_d_1[n]){ text_1=text_2; found=1; break; }
}
if(found==0){
for(var n=0;n<timer_word_d_2.length;n++){
if(digits==timer_word_d_2[n]){ text_1=text_3; break; }
}
}
return text_1;
}


function timer_word(){


var timer_word_seconds=timer_word_total-((new Date().getTime().toString().substr(0,10))-timer_word_st);


if(timer_word_seconds>=1){
var dd=parseInt(timer_word_seconds/86400);
var dt=timer_word_text(dd.toString().substr(-2)," ���� "," ��� "," ���� ");
var hh=parseInt((timer_word_seconds-dd*86400)/3600);
var ht=timer_word_text(hh," ����� "," ���� "," ��� ");
var mm=parseInt((timer_word_seconds-dd*86400-hh*3600)/60);
if(hh<10 && dd!="0"){ hh="0"+hh };
if(mm<10 && hh!="0"){ mm="0"+mm };
var mt=timer_word_text(mm," ����� "," ������ "," ������ ");
var ss=parseInt(timer_word_seconds-dd*86400-hh*3600-mm*60);
if(ss<10 && (hh!="0" || mm!="00")){ ss="0"+ss; }
var st=timer_word_text(ss," ������"," �������"," �������");


if(dd=="0"){ dd=""; dt=""; }
if(dd=="" && hh=="0"){ hh=""; ht=""; }
if(hh=="" && mm=="00"){ mm=""; mt="" }


document.getElementById("timer_word_id").innerHTML=dd+dt+hh+ht+mm+mt+ss+st;
setTimeout("timer_word()",100);
}
else{
location.href=location.href;
}
}


// ____________________ ������ "����������" SHARE42 ____________________


/* share42.com | 22.08.2016 | (c) Dimox */
window.addEventListener('load',function(){var e=document.getElementsByTagName('div');for(var k=0;k<e.length;k++){if(e[k].className.indexOf('share42init')!=-1){if(e[k].getAttribute('data-url')!=-1)var u=e[k].getAttribute('data-url');if(e[k].getAttribute('data-title')!=-1)var t=e[k].getAttribute('data-title');if(e[k].getAttribute('data-image')!=-1)var i=e[k].getAttribute('data-image');if(e[k].getAttribute('data-description')!=-1)var d=e[k].getAttribute('data-description');if(e[k].getAttribute('data-path')!=-1)var f=e[k].getAttribute('data-path');if(e[k].getAttribute('data-icons-file')!=-1)var fn=e[k].getAttribute('data-icons-file');if(!f){function path(name){var sc=document.getElementsByTagName('script'),sr=new RegExp('^(.*/|)('+name+')([#?]|$)');for(var p=0,scL=sc.length;p<scL;p++){var m=String(sc[p].src).match(sr);if(m){if(m[1].match(/^((https?|file)\:\/{2,}|\w:[\/\\])/))return m[1];if(m[1].indexOf("/")==0)return m[1];b=document.getElementsByTagName('base');if(b[0]&&b[0].href)return b[0].href+m[1];else return document.location.pathname.match(/(.*[\/\\])/)[0]+m[1];}}return null;}f=path('share42.js');}if(!u)u=location.href;if(!t)t=document.title;if(!fn)fn='cabinet/refs/refs_share_icons.png';function desc(){var meta=document.getElementsByTagName('meta');for(var m=0;m<meta.length;m++){if(meta[m].name.toLowerCase()=='description'){return meta[m].content;}}return'';}if(!d)d=desc();u=encodeURIComponent(u);t=encodeURIComponent(t);t=t.replace(/\'/g,'%27');i=encodeURIComponent(i);d=encodeURIComponent(d);d=d.replace(/\'/g,'%27');var fbQuery='u='+u;if(i!='null'&&i!='')fbQuery='s=100&p[url]='+u+'&p[title]='+t+'&p[summary]='+d+'&p[images][0]='+i;var vkImage='';if(i!='null'&&i!='')vkImage='&image='+i;var s=new Array('"#" data-count="vk" onclick="window.open(\'//vk.com/share.php?url='+u+'&title='+t+vkImage+'&description='+d+'\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0\');return false" title="���������� � ��������"','"#" data-count="odkl" onclick="window.open(\'//ok.ru/dk?st.cmd=addShare&st._surl='+u+'&title='+t+'\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0\');return false" title="�������� � �������������"','"#" data-count="fb" onclick="window.open(\'//www.facebook.com/sharer/sharer.php?u='+u+'\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0\');return false" title="���������� � Facebook"','"#" data-count="mail" onclick="window.open(\'//connect.mail.ru/share?url='+u+'&title='+t+'&description='+d+'&imageurl='+i+'\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0\');return false" title="���������� � ���� ����@Mail.Ru"','"#" data-count="twi" onclick="window.open(\'//twitter.com/intent/tweet?text='+t+'&url='+u+'\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=100, top=100, width=550, height=440, toolbar=0, status=0\');return false" title="�������� � Twitter"');var l='';for(var j=0;j<s.length;j++)l+='<span class="share42-item" style="display:inline-block;margin:0 0px 0px 0;height:32px;"><a rel="nofollow" style="display:inline-block;width:32px;height:32px;margin:0;padding:0;outline:none;background:url(/images/'+fn+') -'+32*j+'px 0 no-repeat" href='+s[j]+' target="_blank"></a></span>';e[k].innerHTML='<span id="share42">'+l+'</span>';}};},false);
