<?php


if(!isset($_COOKIE['deps_sound']) || $_COOKIE['deps_sound']==1){ $sound=1; }else{ $sound=0; }
echo '<div class="title">'.$title.'<span id="sound" class="sound_'.$sound.'" onclick="deps_sound_toggle();"></span></div>
<script type="text/javascript">var deps_sound='.$sound.';</script>';


echo '<audio id="sound_take" preload>
<source src="/assets/deps_take.mp3" type="audio/mpeg">
</audio>';


// ____________________ ������ ____________________


if($mobile==0 && !empty($ads_banner_2_m)){


$ads_banner_2_c='ads_banner_2_c_'.$page;
$ads_banner_2_c=$$ads_banner_2_c;
if(!empty($ads_banner_2_c)){
$ads_value=str_replace('<','$ads_banner_2_last[]=array(',$d['ads_banner_2_last']);
$ads_banner_2_last=array();
eval($ads_value);
for($n=0;$n<sizeof($ads_banner_2_last);$n++){
if($ads_banner_2_last[$n][1]<$time){ array_splice($ads_banner_2_last,$n,1); $n--; }
}
shuffle($ads_banner_2_last);
echo '<div class="deps_banner_2">';
for($n=0;$n<$ads_banner_2_c;$n++){
if(!empty($ads_banner_2_last[$n])){ echo '<a target="_blank" href="'.$serf_site.'/?ads=banner_2&id='.$ads_banner_2_last[$n][0].'"><img src="'.$ads_banner_2_last[$n][2].'"></a>'; }
else{ echo '<a target="_blank" href="'.$serf_site.'/ads_banner_2/"><img src="'.$serf_site.'/images/cabinet/ads_is_banner/46860.gif"></a>'; }
}
echo '</div>';
}


}


$deps_buy_timer=0;


$d['deps_start']=strtotime($d['deps_start']);


if($d['deps_start']==''){ $d['deps_start']=$time+31536000; }


$deps_until=$d['deps_start']-$time;


// ����� �� ������ ������ �� ������
if($deps_until>0){ $_POST=array(); }
// ����� �� ���������� ��� ����������
if($mydm['up_m']<$deps_up_m){ $_POST=array(); }


$deps_a=array(); // ������ �������
$deps_my_plans=array(); // ���������� ����� ������� � ������� � �� �����
$deps_my_act=array(); // ���������� �������� ������� � ������� � �� �����
$deps_at_sorted=array(); // ������� ������� �������� �� ���������� �������� �������
$deps_ap_sorted=array(); // ������� ������� �������� �� ���������� �������� ������� � �������
$deps_dp=array(); // ������� ������� ������ � �������� ���������� ������ � ������ ������
$deps_tc=0; // ���������� �������
$deps_ts=0; // ����� �������
$deps_ac=0; // ���������� �������� �������
$deps_as=0; // ����� �������� �������
$deps_fc=0; // ���������� �����ب���� �������
$deps_fs=0; // ����� �����ب���� �������
$deps_take_sum=0; // ���������


$s_q=mysqli_query($db,"SELECT * FROM deps_list WHERE uid=$u_id ORDER BY id DESC") or die('cant select deps_list');
while($s_m=mysqli_fetch_assoc($s_q)){
if(empty($mydm['deps_t'])){
echo '���� ����� �� ����������� deps_t';
exit;
}
if(!isset($deps_dp[$s_m['plan']])){ $deps_dp[$s_m['plan']]=$time-$s_m['date']; }
if(!isset($deps_my_plans[$s_m['plan']])){ $deps_my_plans[$s_m['plan']]=array(0,0); }
$deps_my_plans[$s_m['plan']][0]++;
$deps_my_plans[$s_m['plan']][1]+=$s_m['sum'];
if($deps_buy_timer==0 && $s_m['plan']!=777){
$deps_buy_timer=$time-$s_m['date'];
}
$deps_a[]=$s_m;
$deps_tc++;
$deps_ts+=$s_m['sum'];
if($s_m['date_2']>$time){
if(!isset($deps_my_act[$s_m['plan']])){ $deps_my_act[$s_m['plan']]=array(0,0); }
$deps_my_act[$s_m['plan']][0]++;
$deps_my_act[$s_m['plan']][1]+=$s_m['sum'];
$deps_ac++;
$deps_as+=$s_m['sum'];
$deps_at_sorted[]=$s_m['date_2']-$time;
$deps_ap_sorted[$s_m['plan']][]=$s_m['date_2']-$time;
}
else{
$deps_fc++;
$deps_fs+=$s_m['sum'];
}
if($mydm['deps_t']>=$s_m['date'] && $mydm['deps_t']<$s_m['date_2']){
if($time>$s_m['date_2']){ $deps_end=$s_m['date_2']; }
else{ $deps_end=$time; }
$deps_elapsed=$deps_end-$mydm['deps_t'];
$deps_take_sum+=$s_m['sum']*$s_m['percent']/100/($s_m['date_2']-$s_m['date'])*$deps_elapsed;
}
}


// ����� �������� ����� ��������


if($deps_buy_timer>0 && $deps_buy_timer<$deps_buy_interval){
$deps_buy_timer=$deps_buy_interval-$deps_buy_timer;
}
else{
$deps_buy_timer=0;
}


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


// ____________________ ������������ ������ ____________________


if($d['deps_stop_dep']==0 && $deps_buy_timer==0 && ($deps_buy_active==0 || $deps_ac<$deps_buy_active) && !empty($_POST['plan']) && $_POST['plan']!='a' && !empty($_POST['sum'])){


$plan=preg_replace("#[^0-9]+#",'',$_POST['plan']);
$plan=number_format($plan,0,'','')+0;
$sum=preg_replace("#[^0-9\.]+#",'',$_POST['sum']);
$sum=number_format($sum,2,'.','');


if(empty($plan) || !is_numeric($plan) || strlen($plan)>10){ $message_error='�������� ����� ������'; }
if(empty($message_error) && empty($deps_plan[$plan])){ $message_error='������ ������ ���'; }
if(empty($message_error) && !empty($deps_plan[$plan][4]) && !empty($deps_my_plans[$plan]) && $deps_my_plans[$plan][0]>=$deps_plan[$plan][4]){
$message_error='����� ������� ������: '.$deps_plan[$plan][4];
}
if(empty($message_error) && $deps_plan[$plan][5]!=0 && !empty($deps_ap_sorted[$plan]) && sizeof($deps_ap_sorted[$plan])>=$deps_plan[$plan][5]){
$message_error='����� �������� ������� ������: '.$deps_plan[$plan][5];
}
if(empty($message_error) && $deps_plan[$plan][6]>0 && isset($deps_dp[$plan]) && $deps_plan[$plan][6]-$deps_dp[$plan]>0){
$message_error='����� �� �������';
}
if(empty($message_error) && !empty($deps_plan[$plan][7])){
$deps_not_enought=array();
foreach($deps_plan[$plan][7] as $v){
if(empty($deps_my_plans[$v])){
$deps_not_enought[]=$v;
}
}
if(!empty($deps_not_enought)){
if(sizeof($deps_not_enought)==1){ $message_error='������ ������: � '.$deps_not_enought[0]; }
else{ $message_error='������ ������: � '.implode(' � ', $deps_not_enought); }
}
}
if(empty($message_error) && $deps_plan[$plan][3]<100){ $message_error='�������� �������'; }
if(empty($message_error) && (empty($sum) || !is_numeric($sum) || strlen($sum)>14)){ $message_error='�������� �����'.$sum; }
if(empty($message_error) && $mydm['balance']<$sum){ $message_error='������������ �����'; }
if(empty($message_error) && $sum<$deps_plan[$plan][0]){ $message_error='����������� ����� '.$deps_plan[$plan][0].' �'; }
if(empty($message_error) && $sum>$deps_plan[$plan][1]){ $message_error='������������ ����� '.$deps_plan[$plan][1].' �'; }


if(empty($message_error)){ $make_dep=1; $bm_text='balance=(balance-'.$sum.'),'; }


}


// ____________________ ���� ���������� ____________________


if(($d['deps_stop_take']==0 && !empty($_POST['take']) && (empty($_SESSION['deps_t']) || $_SESSION['deps_t']+$deps_can_take<$time)) || !empty($make_dep)){


$pre_deps_take_sum=number_format($deps_take_sum,4,'.','');


$deps_to_m=$pre_deps_take_sum*$deps_bm/100;
$deps_to_m=number_format($deps_to_m,4,'.','');
$deps_to_b=$pre_deps_take_sum-$deps_to_m;
$deps_to_b=number_format($deps_to_b,4,'.','');


$update_path_and_deps_r='';
if($pre_deps_take_sum>0){
$update_path_and_deps_r='deps_r=(deps_r+'.$pre_deps_take_sum.'),';
if($deps_to_m>0){ $update_path_and_deps_r.='money=(money+'.$deps_to_m.'),'; }
if($deps_to_b>0){ $update_path_and_deps_r.='balance=(balance+'.$deps_to_b.'),'; }
}


$to_sp_1=0;
$to_sp_2=0;
$to_sp_3=0;


if($mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){ $to_sp_1=number_format(($pre_deps_take_sum/100*$deps_r_1),4,'.','')+0; }
if($mydm['sp_uid_2']>0 && $mydm['sp_ban_2']==0){ $to_sp_2=number_format(($pre_deps_take_sum/100*$deps_r_2),4,'.','')+0; }
if($mydm['sp_uid_3']>0 && $mydm['sp_ban_3']==0){ $to_sp_3=number_format(($pre_deps_take_sum/100*$deps_r_3),4,'.','')+0; }


$update_ref_sum='';
$update_deps_ref_r='';
$ref_sum=number_format($to_sp_1+$to_sp_2+$to_sp_3,4,'.','')+0;
if($ref_sum>0){
$update_ref_sum=',ref_sum=(ref_sum+'.$ref_sum.')';
$update_deps_ref_r=',deps_ref_r=(deps_ref_r+'.$ref_sum.')';
}


$update_admin_deps_r='';
$to_admin=number_format($pre_deps_take_sum/100*$deps_admin,4,'.','')+0;
if($to_admin>0){ $update_admin_deps_r=',admin_deps_r=(admin_deps_r+'.$to_admin.')'; }


$refback=0;
$to_rb_other='';


if(!empty($deps_refback_m) && $to_sp_1>0 && !empty($_SESSION['deps_rb']) && is_numeric($_SESSION['deps_rb']) && $_SESSION['deps_rb']<=100){
$refback=$to_sp_1*$_SESSION['deps_rb']/100;
$refback=number_format($refback,4,'.','')+0;
if($refback>0){
$to_rb_other='to_rb_other=(to_rb_other+'.$refback.'),';
if(!empty($bm_text)){
if($deps_refback_to=='balance'){ $bm_text='balance=(balance-'.number_format($sum-$refback,4,'.','').'),'; }
else{ $bm_text='balance=(balance-'.$sum.'),money=(money+'.$refback.'),'; }
}
else{
$bm_text=$deps_refback_to.'=('.$deps_refback_to.'+'.$refback.'),';
}
}
$to_sp_1=$to_sp_1-$refback;
$to_sp_1=number_format($to_sp_1,4,'.','')+0;
if($to_sp_1<0){ $to_sp_1=0; }
}


$to_sp_1_t='';
$to_sp_2_t='';
$to_sp_3_t='';


if($to_sp_1>0){ $to_sp_1_t='to_sp_1=(to_sp_1+'.$to_sp_1.'),'; }
if($to_sp_2>0){ $to_sp_2_t='to_sp_2=(to_sp_2+'.$to_sp_2.'),'; }
if($to_sp_3>0){ $to_sp_3_t='to_sp_3=(to_sp_3+'.$to_sp_3.'),'; }


if($pre_deps_take_sum>=$deps_take_min || !empty($make_dep)){
mysqli_query($db,"UPDATE users SET $bm_text $to_rb_other $to_sp_1_t $to_sp_2_t $to_sp_3_t $update_path_and_deps_r deps_t=$time WHERE uid=$u_id LIMIT 1") or die('cant update users');
}


$mydm[$deps_refback_to]=number_format($mydm[$deps_refback_to]+$refback,4,'.','');


if($pre_deps_take_sum>=$deps_take_min){
$_SESSION['deps_t']=$time;
mysqli_query($db,"UPDATE data SET deps_r=(deps_r+$pre_deps_take_sum) $update_ref_sum $update_admin_deps_r $update_deps_ref_r LIMIT 1") or die('cant update data 1');
mysqli_query($db,"INSERT INTO deps_take (uid,login,avatar,sum,date,date_word) VALUES ('$u_id','".$mydm['login']."','".$mydm['avatar']."','$pre_deps_take_sum','$time','".date('d.m.y H:i:s',$time)."')") or die('cant insert deps_take');
$last_id=0+mysqli_insert_id($db);
mysqli_query($db,"DELETE FROM deps_take WHERE id<".($last_id-20));
mysqli_query($db,"OPTIMIZE TABLE deps_take") or die('cant optimize deps_take');
$mydm['balance']+=$deps_to_b;
$mydm['balance']=number_format($mydm['balance'],4,'.','');
$mydm['money']+=$deps_to_m;
$mydm['money']=number_format($mydm['money'],4,'.','');
$mydm['deps_r']+=$pre_deps_take_sum;
$mydm['deps_r']=number_format($mydm['deps_r'],4,'.','');
if(empty($make_dep)){
$message_success_take='+'.$pre_deps_take_sum;
}
}


if($pre_deps_take_sum>=$deps_take_min || !empty($make_dep)){
$deps_take_sum=0;
}


if($pre_deps_take_sum<$deps_take_min && empty($make_dep)){
$message_error='���� �� +'.$deps_take_min;
}


}


// ____________________ �������� ������ ____________________


if(!empty($make_dep)){
$date_2=$time+$deps_plan[$plan][2];
$date_2_word=date('d.m.y H:i:s',$date_2);
$deps_last_t=''; $deps_last=array(); eval($d['deps_last']);
array_unshift($deps_last,array($time,$mydm['uid'],$mydm['avatar'],$mydm['login'],$sum,$plan));
for($n=0;$n<$deps_last_c;$n++){
if(empty($deps_last[$n])){ break; }
$deps_last_t.='$deps_last[]=array("'.$deps_last[$n][0].'","'.$deps_last[$n][1].'","'.$deps_last[$n][2].'","'.$deps_last[$n][3].'","'.$deps_last[$n][4].'","'.$deps_last[$n][5].'");';
}
$deps_last_t=',deps_last=\''.$deps_last_t.'\'';
mysqli_query($db,"INSERT INTO deps_list (date,date_word,date_2,date_2_word,uid,login,sum,percent,plan) VALUES ('$time','".date('d.m.y H:i:s',$time)."','$date_2','$date_2_word','$u_id','".$mydm['login']."','$sum','".$deps_plan[$plan][3]."','$plan')") or die('cant insert deps_list');
mysqli_query($db,"UPDATE data SET deps_c=deps_c+1,deps_s=deps_s+$sum $deps_last_t LIMIT 1") or die('cant update data 2');


array_unshift($deps_a,array('date'=>$time,'date_2'=>$date_2,'sum'=>$sum,'percent'=>$deps_plan[$plan][3],'plan'=>$plan));
$deps_tc++;
$deps_ts+=$sum;
$deps_ac++;
$deps_as+=$sum;
$deps_buy_timer=$deps_buy_interval;
if(empty($deps_my_plans[$plan])){ $deps_my_plans[$plan][0]=0; }
$deps_my_plans[$plan][0]++;
$deps_my_plans[$plan][1]+=$sum;
if(!isset($deps_my_act[$plan])){ $deps_my_act[$plan]=array(0,0); }
$deps_my_act[$plan][0]++;
$deps_my_act[$plan][1]+=$sum;
$deps_at_sorted[]=$date_2-$time;
$deps_ap_sorted[$plan][]=$date_2-$time;
$deps_dp[$plan]=0;


$mydm['balance']-=$sum;
$mydm['balance']=number_format($mydm['balance'],4,'.','');
$message_success_dep='����� ������� ������!';
}


// ____________________ ������� ����������� ____________________


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"UPDATE users SET $deps_way=($deps_way+$to_sp_1),nrs=(nrs+$to_sp_1),refs_r_1=(refs_r_1+$to_sp_1),rb_other=(rb_other+$refback) WHERE uid='".$mydm['sp_uid_1']."' LIMIT 1") or die('cant update sp balance 1'); }
if($to_sp_2>0){ mysqli_query($db,"UPDATE users SET $deps_way=($deps_way+$to_sp_2),nrs=(nrs+$to_sp_2),refs_r_2=(refs_r_2+$to_sp_2) WHERE uid='".$mydm['sp_uid_2']."' LIMIT 1") or die('cant update sp balance 2'); }
if($to_sp_3>0){ mysqli_query($db,"UPDATE users SET $deps_way=($deps_way+$to_sp_3),nrs=(nrs+$to_sp_3),refs_r_3=(refs_r_3+$to_sp_3) WHERE uid='".$mydm['sp_uid_3']."' LIMIT 1") or die('cant update sp balance 3'); }


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=1,sum='$to_sp_1',sp_uid='".$mydm['sp_uid_1']."',info='������������ - �������',refback='$refback'") or die('cant insert refs_profit 1'); }
if($to_sp_2>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=2,sum='$to_sp_2',sp_uid='".$mydm['sp_uid_2']."',info='������������ - �������'") or die('cant insert refs_profit 2'); }
if($to_sp_3>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=3,sum='$to_sp_3',sp_uid='".$mydm['sp_uid_3']."',info='������������ - �������'") or die('cant insert refs_profit 3'); }


}


// ____________________ ���������� ____________________


$deps_ts=number_format($deps_ts,2,'.','');
$deps_as=number_format($deps_as,2,'.','');
$deps_fs=number_format($deps_fs,2,'.','');


$deps_in_s=0;
$deps_in_h=0;
$deps_in_d=0;
$deps_in_m=0;
$deps_in_y=0;


foreach($deps_a as $m){
if($m['date_2']>$time){
$deps_in_s_sum=$m['sum']*$m['percent']/100/($m['date_2']-$m['date']);
$deps_in_s+=$deps_in_s_sum;
$deps_in_h+=$deps_in_s_sum*3600;
$deps_in_d+=$deps_in_s_sum*86400;
$deps_in_m+=$deps_in_s_sum*2592000;
$deps_in_y+=$deps_in_s_sum*31536000;
}
}


$deps_in_s=number_format($deps_in_s,12,'.','');
$deps_in_h=number_format($deps_in_h,12,'.','');
$deps_in_d=number_format($deps_in_d,12,'.','');
$deps_in_m=number_format($deps_in_m,12,'.','');
$deps_in_y=number_format($deps_in_y,12,'.','');


if($deps_until>0){
echo '<div class="deps_until">�� ������ ��������: <span id="timer_word_id"></span></div>
<script type="text/javascript">
var deps_take_cant=1;
var deps_dep_cant=1;
var timer_word_st=new Date().getTime().toString().substr(0,10);
var timer_word_total='.$deps_until.';
timer_word();
</script>';
}
else{
echo '<script type="text/javascript">
var deps_take_cant=0;
var deps_dep_cant=0;
</script>';
}


if($mydm['up_m']<$deps_up_m){
echo '<div class="deps_up_m">��� ������� ���������� ��������� ������ � �������� ������� �� '.$deps_up_m.' ���.</div>';
}


if(empty($mobile)){


echo '<table class="deps_top_table" cellpadding="0px" cellspacing="0px">
<tr>
<td width="33%">';


}


echo '<table class="deps_info_table" cellpadding="0px" cellspacing="10px">
<tr>
<td class="deps_info_dep">
<span>�������:</span> <span>('.$deps_tc.') '.$deps_ts.' �</span>
<br><span>��������:</span> <span>'.$mydm['deps_r'].' �</span>
</td>
</tr>
<tr>
<td class="deps_info_act">
<span>�������:</span> <span>('.$deps_ac.') '.$deps_as.' �</span>
<br><span>���������:</span> <span>('.$deps_fc.') '.$deps_fs.' �</span>
</td>
</tr>
<tr>
<td class="deps_info_profit">';


$deps_r=$mydm['deps_r']+$deps_take_sum-$deps_ts;


if($deps_r<0){


// ����������� ����� ����� �������, ���� ��� ����


$deps_need=0;
$deps_other_sum=0;
$deps_bt=0;
$deps_act=array();


foreach($deps_a as $m){
if($m['date_2']>$time){
$deps_other_sum+=($m['sum']*$m['percent']/100/($m['date_2']-$m['date']))*($m['date_2']-$time);
$deps_act[]=$m;
if($m['date_2']>$deps_bt){
$deps_bt=$m['date_2'];
}
}
}



if($deps_r+$deps_other_sum>=0){
if($deps_bt-$time>=-1 && $deps_bt-$time<2){ $deps_to=2; }
else{ $deps_need=1; }
}
else{
$deps_to=0;
}


$deps_left=$time;
$deps_right=$deps_bt;
$n=0;
$right=1;


if($deps_need==1){


while($n<100){
$n++;
$deps_here=0;


$deps_mid=round(($deps_right-$deps_left)/2);
$deps_to=$deps_left+$deps_mid;


foreach($deps_act as $m){
if($deps_to>$m['date'] && $deps_to<=$m['date_2']){
$deps_here+=($m['sum']*$m['percent']/100/($m['date_2']-$m['date']))*($deps_to-$time);
}
if($deps_to>$m['date_2']){
$deps_here+=($m['sum']*$m['percent']/100/($m['date_2']-$m['date']))*($m['date_2']-$time);
}
}


if($deps_r+$deps_here<0){ $deps_left=$deps_to; $deps_right=$deps_to+$deps_mid; }
else{ $deps_left=$deps_to-$deps_mid; $deps_right=$deps_to; }


}


$deps_to-=$time-1;

}


if($deps_to>0){
$t_seconds=$deps_to;
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='00�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='00�'){ $t_m=''; }
$t_w=$t_d.$t_h.$t_m.$t_s;
$t_w=preg_replace('#^0#','',$t_w);
}


if(!empty($deps_to)){
echo '<span>�����:</span> <span id="to_s">'.number_format($deps_r,8,'.','').' �</span><br><span id="to_w">�� �������:</span> <span id="to_t">'.$t_w.'</span>';
}
else{
echo '<span>�����:</span> <span id="to_s">'.number_format($deps_r,8,'.','').' �</span><br><span id="to_w">���� �� ��������</span> <span id="to_t"></span>';
}


}
else{
$deps_to=0;
echo '<span>�����:</span> <span id="to_s">+'.number_format($deps_r,8,'.','').' �</span><br><span id="to_w">� � �����</span><span id="to_t"></span>';
}
echo '</td>
</tr>
</table>';


if(empty($mobile)){ echo '</td><td width="34%" valign="top">'; }


echo '
<form id="deps_take_form" method="POST">
<input type="hidden" name="a_time" value="'.$time.'">
<input type="hidden" name="take" value="1">
</form>


<div class="deps_take_start">�����: '.date('d.m.Y � H:i',$d['deps_start']).'</div>
<div class="deps_take_word">���������:</div>
<div class="deps_take_sum"><span>+</span><span id="take">'.number_format($deps_take_sum,12,'.','').'</span></div>';


if(!empty($_SESSION['deps_t']) && $_SESSION['deps_t']+$deps_can_take>$time){
$t_seconds=$_SESSION['deps_t']+$deps_can_take-$time;
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.=':'; $t_m.=':';
if($t_h=='0:'){ $t_h=''; } if($t_h=='' && $t_m=='00:'){ $t_m=''; }
$t_w=$t_h.$t_m.$t_s;
$t_w=preg_replace('#^0#','',$t_w);
echo '<div id="deps_take_timer_common" class="deps_take_timer">�� �����: <span id="deps_take_timer">'.$t_w.'</span></div>
<script type="text/javascript">
"use strict";
var deps_take_cant=1;
var t_take_start=Math.round(new Date().getTime()/1000);
function deps_take_timer(){
var t_seconds='.$t_seconds.'-(Math.round(new Date().getTime()/1000)-t_take_start);
if(t_seconds<1){ deps_take_cant=0; document.getElementById("deps_take_timer_common").innerHTML=""; }
else{
var t_h=parseInt(t_seconds/3600); var t_m=parseInt((t_seconds-t_h*3600)/60); var t_s=parseInt(t_seconds-t_h*3600-t_m*60);
if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_h+=":"; t_m+=":";
if(t_h=="0:"){ t_h=""; } if(t_h=="" && t_m=="00:"){ t_m=""; }
var t_w=t_h+t_m+t_s;
t_w=t_w.replace(/^0/,"");
document.getElementById("deps_take_timer").innerHTML=t_w;
}}
setInterval("deps_take_timer();",1000);
</script>';
}
else{
echo '<div class="deps_take_timer"></div>
<script type="text/javascript">
if(deps_dep_cant!=1){
deps_take_cant=0;
}
</script>';
}


if($d['deps_stop_take']==0){
echo '<div class="deps_take_button" onclick="if(deps_take_cant==0){ document.getElementById(\'deps_take_form\').submit(); }">�������</div>';
}
else{
echo '<div class="deps_take_button" onclick="alert(\'���� �������� ��������\');">�������</div>';
}


if(!empty($message_success_dep)){
echo '<div id="message_success" class="deps_success">'.$message_success_dep.'</div>
<script type="text/javascript">
setTimeout("if(document.getElementById(\'message_success\')!=null){ document.getElementById(\'message_success\').remove(); }",5000);
</script>';
}


if(!empty($message_success_take)){
echo '<div id="message_success" class="deps_success">'.$message_success_take.'</div>
<script type="text/javascript">
setTimeout("if(document.getElementById(\'message_success\')!=null){ document.getElementById(\'message_success\').remove(); }",5000);
</script>';
}


echo '<script type="text/javascript">
document.getElementById("my_balance").innerHTML="'.$mydm['balance'].'";
document.getElementById("my_money").innerHTML="'.$mydm['money'].'";
</script>';


echo '<script type="text/javascript">';
if(!empty($deps_to_b) && $deps_to_b>0 || (!empty($refback) && $deps_refback_to=='balance')){
echo 'if(deps_sound==1){ document.getElementById("sound_take").play(); }
document.getElementById("balance_coin").style.display="block";
setTimeout(\'document.getElementById("balance_coin").style.display="none";\',3000);';
}
if(!empty($deps_to_m) && $deps_to_m>0 || (!empty($refback) && $deps_refback_to=='money')){
echo 'if(deps_sound==1){ document.getElementById("sound_take").play(); }
document.getElementById("money_coin").style.display="block";
setTimeout(\'document.getElementById("money_coin").style.display="none";\',3000);';
}
echo '</script>';


if(!empty($message_error)){
echo '<div id="message_error" class="deps_error">'.$message_error.'</div>
<script type="text/javascript">
setTimeout("if(document.getElementById(\'message_error\')!=null){ document.getElementById(\'message_error\').remove(); }",5000);
</script>';
}


echo '<div id="deps_calc" class="deps_calc"></div>';


if(empty($mobile)){ echo '</td><td width="33%">'; }


if(empty($mobile)){


echo '<table align="center" class="deps_speed_table" cellpadding="0px" cellspacing="0px">
<tr><td class="deps_speed_left">'.$deps_in_s.'</td><td class="deps_speed_right"> � �������</td></tr>
<tr><td class="deps_speed_left">'.$deps_in_h.'</td><td class="deps_speed_right"> � ���</td></tr>
<tr><td class="deps_speed_left">'.$deps_in_d.'</td><td class="deps_speed_right"> � ����</td></tr>
<tr><td class="deps_speed_left">'.$deps_in_m.'</td><td class="deps_speed_right"> � �����</td></tr>
<tr><td class="deps_speed_left">'.$deps_in_y.'</td><td class="deps_speed_right"> � ���</td>
</table>';


}


if($deps_buy_active!=0 && $deps_ac>=$deps_buy_active){
sort($deps_at_sorted);
$deps_buy_a_or_i=$deps_at_sorted[$deps_ac-$deps_buy_active];
echo '<div class="deps_buy_timer">
<div class="deps_buy_timer_word">����� �������� �������: '.$deps_buy_active.'
<br>��������� ����� �����:</div>';
}


if($deps_buy_timer>0 && !isset($deps_buy_a_or_i)){
$deps_buy_a_or_i=$deps_buy_timer;
echo '<div class="deps_buy_timer">
<div class="deps_buy_timer_word">��������� ����� �����:</div>';
}


if(isset($deps_buy_a_or_i)){


$t_seconds=$deps_buy_a_or_i;
$t_h=(int)($t_seconds/3600); $t_m=(int)(($t_seconds-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_h*3600-$t_m*60);
if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_h=='0�'){ $t_h=''; } if($t_h=='' && $t_m=='00�'){ $t_m=''; }
$t_w=$t_h.$t_m.$t_s;
$t_w=preg_replace('#^0#','',$t_w);
echo '<div id="deps_buy_timer_amount" class="deps_buy_timer_amount">'.$t_w.'</div>
</div>
<script type="text/javascript">
"use strict";
var t_buy_timer_start=Math.round(new Date().getTime()/1000);
function deps_buy_timer(){
var t_seconds='.$t_seconds.'-(Math.round(new Date().getTime()/1000)-t_buy_timer_start);
if(t_seconds<1){ location.href=location.href; }
else{
var t_h=parseInt(t_seconds/3600); var t_m=parseInt((t_seconds-t_h*3600)/60); var t_s=parseInt(t_seconds-t_h*3600-t_m*60);
if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_h+="�"; t_m+="�"; t_s+="�";
if(t_h=="0�"){ t_h=""; } if(t_h=="" && t_m=="00�"){ t_m=""; }
var t_w=t_h+t_m+t_s;
t_w=t_w.replace(/^0/,"");
document.getElementById("deps_buy_timer_amount").innerHTML=t_w;
}}
setInterval("deps_buy_timer();",1000);
</script>';


}



$deps_big_plan=array();
$deps_big_when=array();
$js_big='';


if(!isset($deps_buy_a_or_i)){
$deps_buy_display='block';
}
else{
$deps_buy_display='none';
}


echo '<div class="deps_buy" style="display:'.$deps_buy_display.'">
<form id="deps_buy_form" method="POST">
<table align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td><select id="deps_plan_num" name="plan" onChange="deps_select(this.value);">
<option value="a">�������� �����</option>';


$js_select='';
$js_plans='';


foreach($deps_plan as $i=>$v){


// ������ �� ����������


if(!empty($v[4]) && !empty($deps_my_plans[$i]) && $deps_my_plans[$i][0]>=$v[4]){
echo '<option value="a">'.$i.'. ����� �������: '.$v[4].'</option>';
$deps_big_plan[$i]=array('a','<div class="deps_big_plan_limit_total">����� �������: <span>'.$v[4].'</span></div>');
}
else{


// ����� �������� ������� � ������� ������� �� ���������� ���������� ������ ��� �������


$deps_buy_p_ai='';


if($deps_plan[$i][5]!=0 && !empty($deps_ap_sorted[$i]) && sizeof($deps_ap_sorted[$i])>=$deps_plan[$i][5]){
sort($deps_ap_sorted[$i]);
$deps_buy_p_ai=$deps_ap_sorted[$i][sizeof($deps_ap_sorted[$i])-$deps_plan[$i][5]];
}


// �������� ����� �������� ������


if($deps_plan[$i][6]>0 && $deps_buy_p_ai=='' && isset($deps_dp[$i]) && $deps_plan[$i][6]-$deps_dp[$i]>0){
$deps_buy_p_ai=$deps_plan[$i][6]-$deps_dp[$i];
}


if($deps_buy_p_ai!=''){
$t_seconds=$deps_buy_p_ai;
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='0�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='0�'){ $t_m=''; }
if($t_s=='0�'){ $t_s=''; } if($t_s=='' && $t_m=='0�'){ $t_m=''; } if($t_s=='' && $t_m=='' && $t_h=='0�'){ $t_h=''; }
echo '<option value="a">'.$i.'. ����� ������� �����: '.$t_d.$t_h.$t_m.$t_s.'</option>';
$deps_big_plan[$i]=array('a','<div class="deps_big_plan_limit_ai">����� ������� �����:<div id="deps_big_timer_'.$i.'">'.$t_d.$t_h.$t_m.$t_s.'</div></div>');
$js_big.='deps_big.push(['.$i.','.$t_seconds.']);';
}


if($deps_buy_p_ai==''){
$t_seconds=$v[2];
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='0�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='0�'){ $t_m=''; }
if($t_s=='0�'){ $t_s=''; } if($t_s=='' && $t_m=='0�'){ $t_m=''; } if($t_s=='' && $t_m=='' && $t_h=='0�'){ $t_h=''; }
echo '<option value="'.$i.'">'.$i.'. '.$deps_name[$i].' �� '.$v[0].' �� '.$v[1].' � / �� '.$t_d.$t_h.$t_m.$t_s.' / ��� '.$v[3].'%</option>';
$deps_big_plan[$i]=array($i);
}


}


$js_plans.='deps_plan['.$i.']=['.$v[0].','.$v[1].','.$v[3].'];';


// ���ר� ����������� ������


$deps_pr_in_s=$v[3]/$v[2];
$t_seconds=ceil(100/$deps_pr_in_s);
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='0�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='0�'){ $t_m=''; }
if($t_s=='0�'){ $t_s=''; } if($t_s=='' && $t_m=='0�'){ $t_m=''; } if($t_s=='' && $t_m=='' && $t_h=='0�'){ $t_h=''; }


$js_select.='if(dsv=='.$i.'){ document.getElementById("deps_sum").placeholder="����������� '.$t_d.$t_h.$t_m.$t_s.'"; }';
$deps_big_when[$i]=$t_d.$t_h.$t_m.$t_s;


}
echo '</select>
</td>
</tr>
<tr>
<td>
<input type="hidden" name="a_time" value="'.$time.'">
<input id="deps_sum" type="text" name="sum" maxlength="8" placeholder="�����" autocomplete="off" value="" oninput="this.value=this.value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{2}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');deps_calc();"/>
</td>
</tr>';
if($d['deps_stop_dep']==0){
echo '<tr><td><div onclick="if(deps_dep_cant==0){ document.getElementById(\'deps_buy_form\').submit(); }">�������</div></td></tr>';
}
else{
echo '<tr><td><div onclick="alert(\'������ �������� ���������\');">�������</div></td></tr>';
}
echo '</table></form></div>';


if(empty($mobile)){ echo '</td></tr></table>'; }


if($deps_desc>0){
if($deps_desc==1){ $deps_desc_text='none'; }
else{ $deps_desc_text='block'; }


echo '<div class="deps_desc_title" onclick="deps_desc_text();">������� �������</div>
<div id="deps_desc_text" class="deps_desc_text" style="display:'.$deps_desc_text.'">';


if($deps_bm==100){ echo '<div>��� ����� �� ����� ��� �� ������ ��� ������.</div>'; }
if($deps_bm==0){ echo '<div>��� ����� �� ����� ��� �� ������ ��� �������.</div>'; }
if($deps_bm!=0 && $deps_bm!=100){ echo '<div>�� ����� ����� '.$deps_bm.'% ��� �� ����� � '.(100-$deps_bm).'% �� �������.</div>'; }


if(!empty($deps_r_1) || !empty($deps_r_2) || !empty($deps_r_3)){
if($deps_way=='balance'){ echo '<div>� ����� ����� �������� �������� ����������� �� �������:</div>'; }
else{ echo '<div>� ����� ����� �������� �������� ����������� �� �����:</div>'; }
if(!empty($deps_r_1)){ echo '<div><span>'.$deps_r_1.'%</span> �������� 1-�� ������</div>'; }
if(!empty($deps_r_2)){ echo '<div><span>'.$deps_r_2.'%</span> �������� 2-�� ������</div>'; }
if(!empty($deps_r_3)){ echo '<div><span>'.$deps_r_3.'%</span> �������� 3-�� ������</div>'; }
}


if($deps_buy_interval>0){
$t_seconds=$deps_buy_interval;
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='0�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='0�'){ $t_m=''; }
if($t_s=='0�'){ $t_s=''; } if($t_s=='' && $t_m=='0�'){ $t_m=''; } if($t_s=='' && $t_m=='' && $t_h=='0�'){ $t_h=''; }
echo '<div>�������� ����� ��������: '.$t_d.$t_h.$t_m.$t_s.'</div>';
}


if($deps_buy_active>0){
echo '<div>����� ����� �������� �������: '.$deps_buy_active.'</div>';
}


echo '<br>';


foreach($deps_plan as $i=>$v){
if($deps_plan[$i][4]==0 && $deps_plan[$i][5]==0 && $deps_plan[$i][6]==0 && sizeof($deps_plan[$i][7])==0){
echo '<div>����� '.$i.'. "'.$deps_name[$i].'". �������������� ������� ���.</div>';
}
else{
$deps_condition='';
if($deps_plan[$i][4]>0){ $deps_condition.='����� ��������� �������: '.$deps_plan[$i][4].'. '; }
if($deps_plan[$i][5]>0){ $deps_condition.='����� �������� �������: '.$deps_plan[$i][5].'. '; }
if($deps_plan[$i][6]>0){
$t_seconds=$deps_plan[$i][6];
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='0�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='0�'){ $t_m=''; }
if($t_s=='0�'){ $t_s=''; } if($t_s=='' && $t_m=='0�'){ $t_m=''; } if($t_s=='' && $t_m=='' && $t_h=='0�'){ $t_h=''; }
$deps_condition.='�������� �������: '.$t_d.$t_h.$t_m.$t_s.'. ';
}
if(sizeof($deps_plan[$i][7])>0){
if(sizeof($deps_plan[$i][7])==1){ $deps_condition.='������ ������ �����: � '.$deps_plan[$i][7][0].'. '; }
else{ $deps_condition.='������ ������ ������: � '.implode(' � ', $deps_plan[$i][7]).'. '; }
}
echo '<div>����� '.$i.'. "'.$deps_name[$i].'". '.$deps_condition.'</div>';
}
}


echo '</div>';


}


if(empty($mobile) && !empty($deps_big_plan)){


echo '<div class="deps_big_plan_common">';


foreach($deps_big_plan as $i=>$v){
if(!isset($deps_buy_a_or_i)){ $deps_big_onclick='document.getElementById(\'deps_plan_num\').value=\''.$deps_big_plan[$i][0].'\';deps_select('.$i.');'; }
else{ $deps_big_onclick=''; }


$t_seconds=$deps_plan[$i][2];
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='0�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='0�'){ $t_m=''; }
if($t_s=='0�'){ $t_s=''; } if($t_s=='' && $t_m=='0�'){ $t_m=''; } if($t_s=='' && $t_m=='' && $t_h=='0�'){ $t_h=''; }


echo '<span id="deps_big_'.$i.'" class="deps_big_plan_block" style="border:1px solid '.$deps_border_0.'" onclick="'.$deps_big_onclick.'">
<div class="deps_big_plan_name"><span>'.$deps_name[$i].'</span></div>';
if($deps_big_plan[$i][0]=='a'){ echo $deps_big_plan[$i][1]; }
else{ echo '<div class="deps_big_plan_img"><img src="/images/cabinet/deps/deps_plan_'.$i.'.png"></div>'; }
echo '<div class="deps_big_plan_percent">�����: '.$deps_plan[$i][3].' %</div>';
echo '<div class="deps_big_plan_time">����: '.$t_d.$t_h.$t_m.$t_s.'</div>';
echo '<div class="deps_big_plan_when">�����������: '.$deps_big_when[$i].'</div>';
echo '<div class="deps_big_plan_sum">�����: �� '.$deps_plan[$i][0].'� �� '.$deps_plan[$i][1].'�</div>';
if(empty($deps_my_plans[$i])){ echo '<div class="deps_big_plan_amount">�������: (0) 0.00 �</div>'; }
else{ echo '<div class="deps_big_plan_amount">�������: ('.$deps_my_plans[$i][0].') '.$deps_my_plans[$i][1].' �</div>'; }
if(empty($deps_my_act[$i])){ echo '<div class="deps_big_plan_active">�������: (0) 0.00 �</div>'; }
else{ echo '<div class="deps_big_plan_active">�������: ('.$deps_my_act[$i][0].') '.$deps_my_act[$i][1].' �</div>'; }
echo '</span>';
}


echo '</div>';


}


if(sizeof($deps_a)>$deps_show_my){ echo '<div class="deps_s_button"><span id="deps_s_button" onclick="show_my_deps();">�������� ��� ��� �������</span></div>'; }
else{ echo '<div class="deps_s_my"><span>��� �������</span></div>'; }


if(!empty($mobile)){ $size=33; }
else{ $size=25; }


echo '<div class="deps_s_div">
<table class="deps_s_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td width="'.$size.'%" class="deps_s_title" style="padding-left:20px;">������<br>���������</td>
<td width="'.$size.'%" class="deps_s_title">�����<br>�������</td>
<td width="'.$size.'%" class="deps_s_title">������<br>���������</td>';
if(empty($mobile)){
echo '<td width="'.$size.'%" class="deps_s_title" style="padding-left:40px;">������</td>';
}
echo '</tr>';


$js_a='';
$n=0;
$row_tr_n=0;


foreach($deps_a as $m){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
$n++;
$id_style='';
if($n>$deps_show_my){ $id_style='id="d_'.$n.'" style="display:none;"'; }
echo '<tr class="deps_s_tr_'.$row_tr_n.'" '.$id_style.'>
<td class="deps_s_date">'.date('d.m.y H:i',$m['date']).'<br><span>'.date('d.m.y H:i',$m['date_2']).'</span></td>
<td class="deps_s_sum"><font>'.$m['sum'].'</font><br><span>'.$m['percent'].'%</span></td>
<td class="deps_s_profit"><font>'.number_format($m['sum']*$m['percent']/100,4,'.','').' (+'.number_format($m['sum']*$m['percent']/100-$m['sum'],4,'.','').')</font><br><span id="deps_s_take_'.$n.'">+';
if($m['date_2']>$time){
echo number_format($m['sum']*$m['percent']/100/($m['date_2']-$m['date'])*($time-$m['date']),12,'.','');
}
else{
echo number_format($m['sum']*$m['percent']/100,4,'.','');
}
echo '</span></td>';


if($m['date_2']>$time){
$js_a.='deps.push(['.$n.','.($m['date_2']-$time).','.($m['date_2']-$m['date']).','.number_format($m['sum']*$m['percent']/100/($m['date_2']-$m['date'])*($time-$m['date']),12,'.','').','.(number_format($m['sum']*$m['percent']/100/($m['date_2']-$m['date']),20,'.','')).']);';
$deps_pr=number_format(($time-$m['date'])/($m['date_2']-$m['date'])*100,4,'.','');
$t_seconds=$m['date_2']-$time;
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='00�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='00�'){ $t_m=''; }
$t_w=$t_d.$t_h.$t_m.$t_s;
$t_w=preg_replace('#^0#','',$t_w);
$deps_s_status='<div><span id="deps_s_pr_'.$n.'" style="width:'.$deps_pr.'%;"><b>'.$deps_pr.'%&nbsp;'.$t_w.'</b></span></div>';
}
else{
$deps_s_status='<font>���������</font>';
}


if(empty($mobile)){
echo '<td class="deps_s_status">
<table cellpadding="0" cellspacing="0">
<tr><td class="deps_s_status_img"><img src="/images/cabinet/deps/deps_plan_'.$m['plan'].'.png"></td><td>'.$deps_s_status.'</td></tr></table></td>';
}
echo '</tr>';
}


echo '</table></div>';


echo '<div class="deps_t_word">��������� 10 ������</div>';


echo '<table class="deps_t_table" cellpadding="0" cellspacing="0">
<tr>
<td class="deps_t_title" colspan="2" style="padding-left:20px;">������������</td>
<td class="deps_t_title" style="padding-left:30px;">�����</td>';
if(empty($mobile)){
echo '<td class="deps_t_title">����</td>';
}
echo '</tr>';


$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT * FROM deps_take ORDER BY id DESC LIMIT 10") or die('cant select deps_take');
while($s_m=mysqli_fetch_assoc($s_q)){
if($row_tr_n==1){ $row_tr_n=0; } else { $row_tr_n++; }
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<tr class="deps_t_tr_'.$row_tr_n.'">';
if($u_id==$admin_uid){
echo '<td class="deps_t_avatar"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>
<td class="deps_t_login"><a target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a></td>';
}
else{
echo '<td class="deps_t_avatar"><img src="'.$s_m['avatar'].'"></td>
<td class="deps_t_login">'.$s_m['login'].'</td>';
}
echo '<td class="deps_t_sum">+'.$s_m['sum'].' �.</td>';
if(empty($mobile)){
echo '<td class="deps_t_date">'.$s_m['date_word'].'</td>';
}
echo '</tr>';
}
echo '</table>';


echo '<script type="text/javascript">


"use strict";


function deps_sound_toggle(){
if(deps_sound==1){ deps_sound=0; }
else{ deps_sound=1; }
document.cookie="deps_sound="+deps_sound+";path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.getElementById("sound").className="sound_"+deps_sound;
}


function deps_desc_text(){
if(document.getElementById("deps_desc_text").style.display=="none"){
document.getElementById("deps_desc_text").style.display="block";
}
else{
document.getElementById("deps_desc_text").style.display="none";
}
}


var deps_selected_last="";


function deps_select(dsv){
'.$js_select.'
if(deps_selected_last!="" && deps_selected_last!="a"){
document.getElementById("deps_big_"+deps_selected_last).style.border="1px solid '.$deps_border_0.'";
}
if(document.getElementById("deps_plan_num").value!="a" && document.getElementById("deps_big_"+dsv)!=null){
deps_selected_last=dsv;
document.getElementById("deps_big_"+dsv).style.border="1px solid '.$deps_border_1.'";
}
if(document.getElementById("message_success")!=null){ document.getElementById("message_success").remove(); }
if(document.getElementById("message_error")!=null){ document.getElementById("message_error").remove(); }
document.getElementById("deps_sum").value="";
deps_calc();
}


var deps_plan=[]; '.$js_plans.'


function deps_calc(){


var deps_sum=document.getElementById("deps_sum").value;
var deps_plan_num=document.getElementById("deps_plan_num").value;
var deps_calculated=0;


if(deps_plan_num=="a" || deps_sum=="." || deps_sum<deps_plan[deps_plan_num][0] || deps_sum>deps_plan[deps_plan_num][1]){
deps_calculated=0;
}
else{
deps_calculated=(deps_sum*deps_plan[deps_plan_num][2]/100).toFixed(4);
}


if(deps_plan_num!="a"){
document.getElementById("deps_calc").innerHTML="������: "+deps_calculated;
}
else{
document.getElementById("deps_calc").innerHTML="";
}

}


var show=0;
var display="";
var deps_tc='.$deps_tc.';


function show_my_deps(){
if(deps_tc<='.$deps_show_my.'){ return; }
if(show==0){ show=1; display="table-row"; document.getElementById("deps_s_button").innerHTML="�������� '.$deps_show_my.' �������"; }
else{ show=0; display="none"; document.getElementById("deps_s_button").innerHTML="�������� ��� ��� �������"; }
for(var n='.($deps_show_my+1).';n<=deps_tc;n++){
document.getElementById("d_"+n).style.display=display;
}
}


var deps_big=[]; '.$js_big.'
var t_start=Math.round(new Date().getTime()/1000);


function deps_big_f(){
try{
for(var n=0;n<deps_big.length;n++){
var t_seconds=deps_big[n][1]-(Math.round(new Date().getTime()/1000)-t_start);
if(t_seconds<0){ setTimeout("location.href=location.href;",2000); return; }
var t_d=parseInt(t_seconds/86400); var t_h=parseInt((t_seconds-t_d*86400)/3600); var t_m=parseInt((t_seconds-t_d*86400-t_h*3600)/60); var t_s=parseInt(t_seconds-t_d*86400-t_h*3600-t_m*60);
if(t_h<10){ t_h="0"+t_h; } if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_d+="�"; t_h+="�"; t_m+="�"; t_s+="�";
if(t_d=="0�"){ t_d=""; } if(t_d=="" && t_h=="00�"){ t_h=""; } if(t_d=="" && t_h=="" && t_m=="00�"){ t_m=""; }
var t_w=t_d+t_h+t_m+t_s;
t_w=t_w.replace(/^0/,"");
document.getElementById("deps_big_timer_"+deps_big[n][0]).innerHTML=t_w;
}
setTimeout("deps_big_f();",100);
}
catch(e){}
}


deps_big_f();


var deps=[]; '.$js_a.'


var refresh=0;
var take='.$deps_take_sum.';
var plused=0;
var t_ms_s=new Date().getTime();
var deps_to='.$deps_to.';


function deps_f(){
try{
plused=0;
for(var n=0;n<deps.length;n++){
var t_seconds=deps[n][1]-(Math.round(new Date().getTime()/1000)-t_start);
var t_elapsed=(Math.round(new Date().getTime()/1000)-t_start);
var t_ms=deps[n][1]*1000-(new Date().getTime()-t_ms_s);
var t_ms_e=new Date().getTime()-t_ms_s;
if(t_seconds<2){ refresh=1; setTimeout("location.href=location.href",2000); }
else{
var t_d=parseInt(t_seconds/86400); var t_h=parseInt((t_seconds-t_d*86400)/3600); var t_m=parseInt((t_seconds-t_d*86400-t_h*3600)/60); var t_s=parseInt(t_seconds-t_d*86400-t_h*3600-t_m*60);
if(t_h<10){ t_h="0"+t_h; } if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_d+="�"; t_h+="�"; t_m+="�"; t_s+="�";
if(t_d=="0�"){ t_d=""; } if(t_d=="" && t_h=="00�"){ t_h=""; } if(t_d=="" && t_h=="" && t_m=="00�"){ t_m=""; }
var t_w=t_d+t_h+t_m+t_s;
t_w=t_w.replace(/^0/,"");
var deps_pr=((deps[n][2]*1000-t_ms)/(deps[n][2]*1000)*100).toFixed(4);
if(deps_pr>100){ deps_pr=100; }
plused+=deps[n][4]/1000*t_ms_e;
document.getElementById("deps_s_take_"+deps[n][0]).innerHTML="+"+(deps[n][3]+(deps[n][4]/1000)*t_ms_e).toFixed(12);
if(document.getElementById("deps_s_pr_"+deps[n][0])!=null){
document.getElementById("deps_s_pr_"+deps[n][0]).style.width=deps_pr+"%";
document.getElementById("deps_s_pr_"+deps[n][0]).innerHTML="<b>"+deps_pr+"%&nbsp;"+t_w+"</b>";
}
}
}
if(refresh==0){
var deps_r='.$deps_r.'+plused;
if(deps_r<0){ document.getElementById("to_s").innerHTML=deps_r.toFixed(8)+" �"; document.getElementById("to_w").innerHTML="���� �� ��������"; document.getElementById("to_t").innerHTML=""; }
else{ document.getElementById("to_s").innerHTML="+"+deps_r.toFixed(8)+" �"; document.getElementById("to_w").innerHTML="� � �����"; document.getElementById("to_t").innerHTML=""; }


t_seconds=deps_to-t_elapsed;
if(t_seconds>0 && deps_r<0){
var t_d=parseInt(t_seconds/86400); var t_h=parseInt((t_seconds-t_d*86400)/3600); var t_m=parseInt((t_seconds-t_d*86400-t_h*3600)/60); var t_s=parseInt(t_seconds-t_d*86400-t_h*3600-t_m*60);
if(t_h<10){ t_h="0"+t_h; } if(t_m<10){ t_m="0"+t_m; } if(t_s<10){ t_s="0"+t_s; }
t_d+="�"; t_h+="�"; t_m+="�"; t_s+="�";
if(t_d=="0�"){ t_d=""; } if(t_d=="" && t_h=="00�"){ t_h=""; } if(t_d=="" && t_h=="" && t_m=="00�"){ t_m=""; }
var t_w=t_d+t_h+t_m+t_s;
t_w=t_w.replace(/^0/,"");
document.getElementById("to_w").innerHTML="�� �������:";
document.getElementById("to_t").innerHTML=t_w;
}


document.getElementById("take").innerHTML=(take+plused).toFixed(12);
requestAnimationFrame(deps_f);
}
}
catch(e){}
}


if(deps.length>0){
deps_f();
}


</script>';


?>
