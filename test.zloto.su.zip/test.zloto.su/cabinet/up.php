<?php


// ____________________ � ������� ��� ������ ____________________


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time'] && !empty($_POST['sum_up_w']) && $up_w_mode==1){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


$sum=preg_replace("#[^0-9\.]+#",'',$_POST['sum_up_w']);
$sum=number_format($sum,4,'.','');


if(empty($message_error) && $sum_balance>$b_tot){ $message_error='�� ����� ������� ������������ �������'; }


if(empty($sum) || !is_numeric($sum) || strlen($sum)>16){ $message_error='����� ������� �������'; }
if(empty($message_error) && $sum<0.0001){ $message_error='����� �� ������ 0.0001 ���.'; }
if(empty($message_error) && $sum>$mydm['money']){ $message_error='�� ����� ������� ������������ �������'; }


if(empty($message_error)){


mysqli_query($db,"UPDATE users SET money=money-$sum,balance=balance+$sum,up_w=up_w+$sum WHERE uid=$u_id LIMIT 1") or die('cant update users money');
mysqli_query($db,"INSERT INTO balance_up_w (date,date_word,uid,login,sum) VALUES ('$time','".date("d.m.y H:i:s",$time)."','$u_id','".$mydm['login']."','$sum')") or die('inserting balance_up_w');
mysqli_query($db,"UPDATE data SET up_w=up_w+$sum LIMIT 1") or die('cant update data up_w');


$mydm['money']-=$sum;
$mydm['money']=number_format($mydm['money'],4,'.','');
$mydm['balance']+=$sum;
$mydm['balance']=number_format($mydm['balance'],4,'.','');


$message_success=1;


}


}


// ____________________ ��������� ____________________


if(!empty($_POST['type']) && ($_POST['type']=='payeer' || $_POST['type']=='fk')){


// ���� ���� config.php ��� ��� ���������
if(!empty($admin_uid)){ die('wrong sign'); }
require_once('../config.php');


if(empty($_POST['sum'])){ echo 'preorder_can=0;alert("������� ���������� �����");'; exit; }


$sum=preg_replace("#[^0-9\.]+#",'',$_POST['sum']);
$sum=number_format($sum,2,'.','');


if(empty($sum) || !is_numeric($sum) || strlen($sum)>17){ echo 'preorder_can=0;alert("������� ���������� �����");'; exit; }
if($sum<$up_m_min_sum){ echo 'preorder_can=0;alert("����� �� ������ '.$up_m_min_sum.'");'; exit; }
if($sum>20000){ echo 'preorder_can=0;alert("����� �� ������ 20000");'; exit; }


// ____________________ ��������� PAYEER ____________________





// ____________________ ��������� FREE-KASSA ____________________


if($_POST['type']=='fk'){
echo 'document.getElementById("fk_amount").value="'.($sum+0).'";
document.getElementById("fk_sign").value="'.md5($fk_id.':'.($sum+0).':'.$fk_secret_1.':RUB:'.$u_id).'";
document.getElementById("fk_up_form").submit();';
}


exit;
}


$update=0;


// ____________________ ���������� ���������� PAYEER ____________________





// ���� ���� config.php ��� ��� ���������

if(isset($_POST['txn'])){
    $txn = intval($_POST['txn']);
    $R = mysqli_fetch_assoc(mysqli_query($db,"SELECT COUNT(`id`) as 'count' FROM `balance_up_m` WHERE `batch` = '$txn'"));
    if($R['count'] == 0){
        require('cpayeer.php');
        $payeer = new CPayeer($accountNumber, $apiId, $apiKey);
        if ($payeer->isAuth()){
            $data = $payeer->getHistoryInfo($txn);
            if(empty($data['auth_error'])){
                if($accountNumber == $data['info']['to']){
                    if($data['info']['status'] == 'execute'){
                        if($data['info']['type'] == 'transfer'){
                            if($data['info']['protect'] == 'N'){
                                if($data['info']['curOut'] == 'RUB'){
                                    $payeer_sum = $data['info']['sumOut'];
                                    if($payeer_sum >= $up_m_min_sum){
                                        $R = mysqli_fetch_assoc(mysqli_query($db,"SELECT COUNT(`id`) as 'count' FROM `balance_up_m` WHERE `batch` = '$txn'"));
                                        if($R['count'] == 0){
                                            $time = strtotime($data['info']['dateCreate']);
                                            $R = mysqli_fetch_assoc(mysqli_query($db,"SELECT COUNT(`id`) as 'count' FROM `balance_up_m` WHERE `uid` = '$u_id'"));

    
    $batch=preg_replace('#[^0-9]+#','',$txn);
    $batch=number_format($batch,0,'','');
    if(empty($batch) || !is_numeric($batch) || strlen($batch)>30){ echo 'wrong sign'; exit; }

    $sum=preg_replace("#[^0-9\.]+#",'',$payeer_sum);
    $sum=number_format($sum,2,'.','')+0;
    if(empty($sum) || !is_numeric($sum) || strlen($sum)>17 || $sum<$up_m_min_sum){ echo 'wrong sign'; exit; } 


echo '��� ������� � ������� ' .$sum; echo ' ����� ��� ��������, ��� ������������� �������� ' .$batch; echo ' ��� ����������� ����� PAYEER.';

echo '������������� ���� ����, ����� ������� ���� ����� ������';
$update=1;

}}}}}}}}}}}

// ____________________ ���������� ���������� FREE-KASSA ____________________


if(!empty($_GET['pay']) && $_GET['pay']==2){


if(isset($_SERVER['HTTP_X_REAL_IP'])){ $up_ip=$_SERVER['HTTP_X_REAL_IP']; }
if(isset($_SERVER['REMOTE_ADDR'])){ $up_ip=$_SERVER['REMOTE_ADDR']; }
if(empty($up_ip) || !in_array($up_ip,array('168.119.157.136','168.119.60.227','138.201.88.124','178.154.197.79'))){
echo 'hacking attempt! HTTP_X_REAL_IP='.$_SERVER['HTTP_X_REAL_IP'].'; REMOTE_ADDR='.$_SERVER['REMOTE_ADDR'];
exit;
}


if(empty($_POST['AMOUNT']) || empty($_POST['SIGN']) || empty($_POST['intid']) || empty($_POST['MERCHANT_ORDER_ID'])){ echo 'wrong sign'; exit; }


// ���� ���� config.php ��� ��� ���������
if(!empty($admin_uid)){ echo 'wrong sign'; exit; }
require_once("../config.php");


if(empty($up_m_type_fk)){ exit; }


$batch=preg_replace('#[^0-9]+#','',$_POST['intid']);
$batch=number_format($batch,0,'','');
if(empty($batch) || !is_numeric($batch) || strlen($batch)>30){ echo 'wrong sign'; exit; }


$sum=preg_replace("#[^0-9\.]+#",'',$_POST['AMOUNT']);
$sum=number_format($sum,2,'.','')+0;
if(empty($sum) || !is_numeric($sum) || strlen($sum)>17 || $sum<$up_m_min_sum){ echo 'wrong sign'; exit; }


$sign=md5($fk_id.':'.$sum.':'.$fk_secret_2.':'.$_POST['MERCHANT_ORDER_ID']);


if($sign!=$_POST['SIGN']){ echo 'wrong sign'; exit; }


$u_id=$_POST['MERCHANT_ORDER_ID'];
$text_success='YES';
$text_error='wrong sign';
$update=2;
}


// ____________________ ��������� ���������� ____________________


if($update==1 || $update==2){


$s_q=mysqli_query($db,"SELECT id FROM balance_up_m WHERE batch='$batch' AND type=$update LIMIT 1") or die('cant check same');
if(mysqli_num_rows($s_q)>0){ echo $text_success; exit; }


$u_id=preg_replace('#[^0-9]+#','',$u_id);
$u_id=number_format($u_id,0,'','');
if(empty($u_id) || !is_numeric($u_id) || strlen($u_id)>10){ echo $text_error; exit; }


$mydq=mysqli_query($db,"SELECT * FROM users WHERE uid='$u_id' LIMIT 1") or die('cant get mydm');
$mydm=mysqli_fetch_assoc($mydq);
if(empty($mydm)){ echo $text_error; exit; }


// ____________________ ������ ������� ____________________


$admin_up_m_r='';
$admin_s=0;
if(!empty($up_m_com)){
if($update==1){ $pre_sum=$sum*(100-$kassa_pr_p)/100; }
if($update==2){ $pre_sum=$sum*(100-$kassa_pr_fk)/100; }
$pre_up_m_r=number_format($sum/100*$up_m_com,4,'.','')+0;
if($pre_up_m_r>0 && is_numeric($pre_up_m_r)){
$admin_s=$pre_up_m_r;
$admin_up_m_r=',admin_up_m_r=(admin_up_m_r+'.$pre_up_m_r.')';
}
}


$to_sp_1=0;
$to_sp_2=0;
$to_sp_3=0;


if($mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){ $to_sp_1=number_format(($sum/100*$up_m_r_1),4,'.','')+0; }
if($mydm['sp_uid_2']>0 && $mydm['sp_ban_2']==0){ $to_sp_2=number_format(($sum/100*$up_m_r_2),4,'.','')+0; }
if($mydm['sp_uid_3']>0 && $mydm['sp_ban_3']==0){ $to_sp_3=number_format(($sum/100*$up_m_r_3),4,'.','')+0; }


if($to_sp_1>0){
$s_q=mysqli_query($db,"SELECT up_m,up_m_rb FROM users WHERE uid=".$mydm['sp_uid_1']." AND ban=0 LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(isset($s_m['up_m']) && !empty($s_m['up_m_rb']) && is_numeric($s_m['up_m_rb']) && $s_m['up_m_rb']<=100){
if($up_m_refback_m==0.5){ $up_m_rb=$s_m['up_m_rb']; }
if($up_m_refback_m>=1 && $s_m['up_m']>=$up_m_refback_m){ $up_m_rb=$s_m['up_m_rb']; }
}
}


$update_ref_sum='';
$ref_sum=number_format($to_sp_1+$to_sp_2+$to_sp_3,4,'.','')+0;
if($ref_sum>0 && is_numeric($ref_sum)){
$update_ref_sum=',ref_sum=(ref_sum+'.$ref_sum.')';
}


$bonus_p=0;
$bonus_s=0;


if(!empty($up_m_bonus_d_1) && !empty($up_m_bonus_d_2) && is_numeric($up_m_bonus_d_1) && is_numeric($up_m_bonus_d_2) && $up_m_bonus_d_1<$up_m_bonus_d_2 && $time>$up_m_bonus_d_1 && $time<$up_m_bonus_d_2){


if($mydm['up_m']==0 && $up_m_bonus_f>0){
$pre_bonus_f=number_format($sum/100*$up_m_bonus_f,4,'.','')+0;
if($pre_bonus_f>0){
$bonus_p=$up_m_bonus_f;
$bonus_s=$pre_bonus_f;
}
}


$bonus_s_now=0;


if(!empty($up_m_bonus_a)){
foreach($up_m_bonus_a as $i=>$v){
if(!empty($v) && $sum>=$i){
$bonus_s_now=$v;
}
}
}


if(!empty($bonus_s_now)){
$pre_bonus_s=number_format($sum/100*$bonus_s_now,4,'.','')+0;
if($pre_bonus_s>0){
$bonus_p+=$bonus_s_now;
$bonus_s+=$pre_bonus_s;
}
}


$bonus_p=number_format($bonus_p,4,'.','')+0;
$bonus_s=number_format($bonus_s,4,'.','')+0;


}


$bonus_up_m_r='';


if(!empty($bonus_s)){
$bonus_up_m_r=',bonus_up_m_r=(bonus_up_m_r+'.$bonus_s.')';
}


$bm_text='balance=(balance+'.number_format($sum+$bonus_s,4,'.','').'),';


$refback=0;
$to_rb_up_m='';


if(!empty($up_m_rb)){
$refback=$to_sp_1*$up_m_rb/100;
$refback=number_format($refback,4,'.','')+0;
if($refback>0){
$to_rb_up_m='to_rb_up_m=(to_rb_up_m+'.$refback.'),';
if($up_m_refback_to=='balance'){ $bm_text='balance=(balance+'.number_format($sum+$bonus_s+$refback,4,'.','').'),'; }
else{ $bm_text='balance=(balance+'.number_format($sum+$bonus_s,4,'.','').'),money=(money+'.$refback.'),'; }
}
$to_sp_1=$to_sp_1-$refback;
$to_sp_1=number_format($to_sp_1,4,'.','')+0;
if($to_sp_1<0){ $to_sp_1=0; }
}


$to_sp_1_t='';
$to_sp_2_t='';
$to_sp_3_t='';


if($to_sp_1>0){ $to_sp_1_t='to_sp_1=(to_sp_1+'.$to_sp_1.'),'; }
if($to_sp_2>0){ $to_sp_2_t='to_sp_2=(to_sp_2+'.$to_sp_2.'),'; }
if($to_sp_3>0){ $to_sp_3_t='to_sp_3=(to_sp_3+'.$to_sp_3.'),'; }


mysqli_query($db,"INSERT INTO balance_up_m (date,date_word,uid,login,sum,admin_s,bonus_p,bonus_s,refback,to_sp_1,to_sp_2,to_sp_3,batch,type) VALUES ('$time','".date("d.m.y H:i:s",$time)."','$u_id','".$mydm['login']."','$sum','$admin_s','$bonus_p','$bonus_s','$refback','$to_sp_1','$to_sp_2','$to_sp_3','$batch','$update')") or die('inserting error');


$s_q=mysqli_query($db,"SELECT * FROM data LIMIT 1") or die('cant select data');
$d=mysqli_fetch_assoc($s_q);
if(!isset($d['users'])){ exit('data error'); }


// ��� �������� ����������


$contest_up='';


$contest_up_d_1=strtotime($d['contest_up_d_1']);
$contest_up_d_2=strtotime($d['contest_up_d_2']);


if(!empty($contest_up_m) && $time>$contest_up_d_1 && $time<$contest_up_d_2 && date('Y',$contest_up_d_1)!=2000){ $contest_up=',contest_up=contest_up+'.$sum; }


mysqli_query($db,"UPDATE users SET $bm_text $to_rb_up_m $to_sp_1_t $to_sp_2_t $to_sp_3_t up_m=up_m+$sum,up_m_time=$time,bonus_up_m_r=(bonus_up_m_r+$bonus_s) $contest_up WHERE uid=$u_id LIMIT 1") or die('cant update user up_m');


$p_datas_q=mysqli_query($db,"SELECT COUNT(*) FROM users WHERE up_m>0 AND bot=0") or die('cant count');
$p_datas_m=mysqli_fetch_row($p_datas_q);
$update_active=0+$p_datas_m[0];


$update_last_t='';
$up_last=array();
eval($d['up_last']);
$sum=number_format($sum,2,'.','');


if($update==1){ array_unshift($up_last,array($time,$mydm['uid'],$mydm['avatar'],$mydm['login'],"p",$sum)); }
if($update==2){ array_unshift($up_last,array($time,$mydm['uid'],$mydm['avatar'],$mydm['login'],"fk",$sum)); }


for($n=0;$n<$up_last_c;$n++){
if(empty($up_last[$n])){ break; }
$update_last_t.='$up_last[]=array("'.$up_last[$n][0].'","'.$up_last[$n][1].'","'.$up_last[$n][2].'","'.$up_last[$n][3].'","'.$up_last[$n][4].'","'.$up_last[$n][5].'","'.$up_last[$n][6].'");';
}


if($update==1){
mysqli_query($db,"UPDATE data SET active='$update_active',up_payeer_s=up_payeer_s+$sum,up_payeer_c=up_payeer_c+1,up_last='$update_last_t' $bonus_up_m_r $admin_up_m_r $update_ref_sum") or die('cant data');
}


if($update==2){
mysqli_query($db,"UPDATE data SET active='$update_active',up_fk_s=up_fk_s+$sum,up_fk_c=up_fk_c+1,up_last='$update_last_t' $bonus_up_m_r $admin_up_m_r $update_ref_sum") or die('cant data');


// ____________________ FREE-KASSA ������ ������� ��� �������� �� F ����˨� ____________________


if($fk_m==1){


if(!isset($_SESSION['f_time'])){ $_SESSION['f_time']=0; }


if($_SESSION['f_time']<$time){
$_SESSION['f_time']=$time+600;


$data=array('shopId'=>$fk_id,'nonce'=>time());
ksort($data);
$sign=hash_hmac('sha256',implode('|',$data),$fk_api_key);
$data['signature']=$sign;
$data=json_encode($data);


$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,'https://api.freekassa.ru/v1/balance');
curl_setopt($curl,CURLOPT_HEADER,0);
curl_setopt($curl,CURLOPT_FAILONERROR,0);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_TIMEOUT,10);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
$result=trim(curl_exec($curl));
curl_close($curl);
$result=json_decode($result,true);


if(!empty($result['balance'])){
foreach($result['balance'] as $m){
if(!empty($m['currency']) && $m['currency']=='RUB' && !empty($m['value']) && is_numeric($m['value']) && strlen($m['value'])<16 && $m['value']>=10){
mysqli_query($db,"UPDATE data SET fk_b='".$m['value']."',fk_time='".($time+60)."' LIMIT 1");
break;
}
}
}


}
}


}


echo $text_success;


// ��� �������� ���������


if(!empty($contest_ref_m) && $mydm['date']>strtotime($d['contest_ref_d_1']) && $mydm['date']<strtotime($d['contest_ref_d_2']) && $mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){
mysqli_query($db,"UPDATE users SET contest_ref=contest_ref+".$sum." WHERE uid='".$mydm['sp_uid_1']."' AND ban=0 LIMIT 1") or die('cant update contest_ref');
}


// ____________________ ������� ����������� ____________________


if($to_sp_1>0 || $refback>0){  mysqli_query($db,"UPDATE users SET $up_m_way=($up_m_way+$to_sp_1),nrs=(nrs+$to_sp_1),refs_r_1=(refs_r_1+$to_sp_1),rb_up_m=(rb_up_m+$refback) WHERE uid='".$mydm['sp_uid_1']."' LIMIT 1") or die('cant update sp balance 1'); }
if($to_sp_2>0){ mysqli_query($db,"UPDATE users SET $up_m_way=($up_m_way+$to_sp_2),nrs=(nrs+$to_sp_2),refs_r_2=(refs_r_2+$to_sp_2) WHERE uid='".$mydm['sp_uid_2']."' LIMIT 1") or die('cant update sp balance 2'); }
if($to_sp_3>0){ mysqli_query($db,"UPDATE users SET $up_m_way=($up_m_way+$to_sp_3),nrs=(nrs+$to_sp_3),refs_r_3=(refs_r_3+$to_sp_3) WHERE uid='".$mydm['sp_uid_3']."' LIMIT 1") or die('cant update sp balance 3'); }


if($to_sp_1>0 || $refback>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=1,sum='$to_sp_1',sp_uid='".$mydm['sp_uid_1']."',info='���������� �������',refback='$refback'") or die('cant insert refs_profit 1'); }
if($to_sp_2>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=2,sum='$to_sp_2',sp_uid='".$mydm['sp_uid_2']."',info='���������� �������'") or die('cant insert refs_profit 2'); }
if($to_sp_3>0){ mysqli_query($db,"INSERT INTO refs_profit SET date='$time',date_word='".date("d.m.y H:i:s",$time)."',ref_uid='$u_id',ref_login='".$mydm['login']."',ref_avatar='".$mydm['avatar']."',ref_level=3,sum='$to_sp_3',sp_uid='".$mydm['sp_uid_3']."',info='���������� �������'") or die('cant insert refs_profit 3'); }


// ____________________ ������������ �������� ��������� ____________________


if($mydm['up_m']==0){


$where='';
$count_if='';


if($mydm['sp_uid_1']>0 && $mydm['sp_ban_1']==0){
$where="sp_uid_1='".$mydm['sp_uid_1']."'";
$count_if='COUNT(IF(up_m!=0 AND sp_uid_1=\''.$mydm['sp_uid_1'].'\',1,null)) AS refs_a_1';
}


if($mydm['sp_uid_2']>0 && $mydm['sp_ban_2']==0){
if(!empty($where)){ $where.=' OR '; }
$where.="sp_uid_2='".$mydm['sp_uid_2']."'";
if(!empty($count_if)){ $count_if.=','; }
$count_if.='COUNT(IF(up_m!=0 AND sp_uid_2=\''.$mydm['sp_uid_2'].'\',1,null)) AS refs_a_2';
}


if($mydm['sp_uid_3']>0 && $mydm['sp_ban_3']==0){
if(!empty($where)){ $where.=' OR '; }
$where.="sp_uid_3='".$mydm['sp_uid_3']."'";
if(!empty($count_if)){ $count_if.=','; }
$count_if.='COUNT(IF(up_m!=0 AND sp_uid_3=\''.$mydm['sp_uid_3'].'\',1,null)) AS refs_a_3';
}


if(!empty($where) && !empty($count_if)){
$s_a_q=mysqli_query($db,"SELECT $count_if FROM users WHERE $where") or die('cant get refs_a');
$s_a_m=mysqli_fetch_assoc($s_a_q);
}


if(!empty($s_a_m['refs_a_1'])){ mysqli_query($db,"UPDATE users SET refs_a_1='".$s_a_m['refs_a_1']."' WHERE uid='".$mydm['sp_uid_1']."' LIMIT 1"); }
if(!empty($s_a_m['refs_a_2'])){ mysqli_query($db,"UPDATE users SET refs_a_2='".$s_a_m['refs_a_2']."' WHERE uid='".$mydm['sp_uid_2']."' LIMIT 1"); }
if(!empty($s_a_m['refs_a_3'])){ mysqli_query($db,"UPDATE users SET refs_a_3='".$s_a_m['refs_a_3']."' WHERE uid='".$mydm['sp_uid_3']."' LIMIT 1"); }


}


// ____________________ ��� ��������� �� �������� ��������� ____________________


$top_sp_a_t='';


$s_q=mysqli_query($db,"SELECT uid,avatar,login,refs_a_1 FROM users WHERE ban=0 ORDER BY refs_a_1 DESC LIMIT ".$top_sp_a_c) or die ('cant select refs_a_1');
while($s_m=mysqli_fetch_assoc($s_q)){
$top_sp_a_t.='$top_sp_a[]=array("'.$s_m['uid'].'","'.$s_m['avatar'].'","'.$s_m['login'].'","'.$s_m['refs_a_1'].'");';
}


// ____________________ ��� ������������� �� ����������� ____________________


$top_up_m_t='';


$s_q=mysqli_query($db,"SELECT uid,avatar,login,up_m FROM users WHERE ban=0 ORDER BY up_m DESC LIMIT ".$top_up_m_c) or die ('cant select top_up_m');
while($s_m=mysqli_fetch_assoc($s_q)){
$top_up_m_t.='$top_up_m[]=array("'.$s_m['uid'].'","'.$s_m['avatar'].'","'.$s_m['login'].'","'.$s_m['up_m'].'");';
}


mysqli_query($db,"UPDATE data SET top_sp_a='$top_sp_a_t',top_up_m='$top_up_m_t' LIMIT 1") or die('cant update data top_sp_a top_up_m');


exit;
}


echo '<div class="title">'.$title.'</div>';


if(!empty($_GET['success'])){
echo '<div id="message_success" class="up_success">������ ��������</div>
<script type="text/javascript">
document.getElementById("balance_coin").style.display="block";
setTimeout(\'document.getElementById("balance_coin").style.display="none";\',3000);
setTimeout("document.getElementById(\'message_success\').remove();",5000);
</script>';
}


if(!empty($_GET['fail'])){
echo '<div id="message_error" class="up_error">���������� ��������</div>
<script type="text/javascript">setTimeout("document.getElementById(\'message_error\').remove();",5000);</script>';
}


if(!empty($message_success)){
echo '<div id="message_success" class="up_success">������ �������� �� '.$sum.' ���.</div>
<script type="text/javascript">
document.getElementById("my_balance").innerHTML="'.$mydm['balance'].'";
document.getElementById("my_money").innerHTML="'.$mydm['money'].'";
document.getElementById("balance_coin").style.display="block";
setTimeout(\'document.getElementById("balance_coin").style.display="none";\',3000);
setTimeout("document.getElementById(\'message_success\').remove();",5000);
</script>';
}


if(!empty($message_error)){
echo '<div id="message_error" class="up_error">'.$message_error.'</div>
<script type="text/javascript">setTimeout("document.getElementById(\'message_error\').remove();",5000);</script>';
}


echo '

<form id="fk_up_form" method="GET" style="display:none;" action="https://pay.freekassa.ru/">
<input type="hidden" name="m" value="'.$fk_id.'">
<input id="fk_amount" type="hidden" name="oa" value="0">
<input type="hidden" name="currency" value="RUB">
<input type="hidden" name="o" value="'.$u_id.'">
<input id="fk_sign" type="hidden" name="s" value="0">
</form>';




$bonus_f_setted=0;


if($mydm['up_m']==0 && $up_m_bonus_f>0){
$bonus_f_setted=1;
}


$bonus_s_setted=0;


if(!empty($up_m_bonus_a)){
foreach($up_m_bonus_a as $i=>$v){
if(!empty($v)){
$bonus_s_setted=1;
break;
}
}
}


if($bonus_f_setted==1 || $bonus_s_setted==1){
if(!empty($up_m_bonus_d_1) && !empty($up_m_bonus_d_2) && is_numeric($up_m_bonus_d_1) && is_numeric($up_m_bonus_d_2) && $up_m_bonus_d_1<$up_m_bonus_d_2){
echo '<div class="up_bonus_common">
<div class="up_bonus_title">����� ���������� � '.date('d.m.y H:i',$up_m_bonus_d_1).' �� '.date('d.m.y H:i',$up_m_bonus_d_2).'</div>';
if($time>$up_m_bonus_d_1 && $time<$up_m_bonus_d_2){
echo '<div class="up_bonus_untill">�� ��������� ��������: <span id="timer_word_id"></span></div>
<script type="text/javascript">
var timer_word_st=new Date().getTime().toString().substr(0,10);
var timer_word_total='.($up_m_bonus_d_2-$time).';
timer_word();
</script>';
}
echo '<br>';
if($bonus_f_setted==1){
echo '<div class="up_bonus_1">����� �� ������ ���������� ������� � ��������: <span>'.$up_m_bonus_f.'%</span></div>';
}
if($bonus_s_setted==1){
$vv=array();
echo '<div class="up_bonus_2">������ �� ����� ���������� � ��������: ';
foreach($up_m_bonus_a as $i=>$v){
if(!empty($v)){
$vv[]='�� '.$i.' �. � ���� '.$v.'%';
}
}
echo implode(', ', $vv);
echo '</div>';
}
if($bonus_f_setted==1 && $bonus_s_setted==1){
echo '<div class="up_bonus_3">����� �� ������ ���������� � ����� �� ����� ���������� �����������.</div>';
}
echo '</div>';
}
}


echo '<div class="up_common">';


if(!empty($up_m_type_p) || !empty($up_m_type_fk)){


echo '<table class="up_m_table" align="center" cellpadding="6px" cellspacing="0px">
<tr>
<td colspan="2"><div class="up_m_title">��������� � ��������</div></td>
</tr>
<tr>
<td>
<select id="up_m_type" class="up_m_select" name="up_m_type">';

if(!empty($up_m_type_fk)){ echo '<option value="fk">Free-Kassa</option>'; }
echo '</select>
</td>
<td><input id="up_m_sum" class="up_m_input" type="text" name="sum" autocomplete="off" placeholder="����� �� '.$up_m_min_sum.' �" value="" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,\'\').replace(/^0([0-9]+)/,\'$1\').replace(/^0/,\'\');"></td>
</tr>
<tr>
<td colspan="2"><div class="up_m_button" onclick="preorder_ajax_send();">���������</div></td>

<center> <p><br /></p><p><span style="font-size: medium;">����� ��������� ������, ��������� ���� ������� �� ��������� ������� PAYEER: <span style="color: red;">P123456</span> � �������� �����������.</span></p><p>1) ��� ������ ������ ������ �� ������� ���������� ����, ���� �� ��� ������� ���, ������������� ��� ��������, �� �� ���� ��� ��� ��������.</p><p>2) ��������� �� ����� 1 ����� �� ������� <span style="color: red; font-size: medium;">P1058002169</span></p><p><span>3) ����������� ������������� ���������� �� ������������ (#) ������: 1555180391</span></p><p>4) ������� ������������� ���������� � ��������� ���� � �������������� ���������</p>
</tr>
<form method="POST" action="">
<tr>
<td colspan="2"><div class="up_m_title">��������� � PAYEER: P1058002169</div></td>
</tr>
<tr>
<td>
<input class="up_m_select" type="text" name="txn" placeholder="����� ID ��������">
</td>
</tr>
<tr>
<td><div><input  class="up_m_input" type="submit" id="submit" value="���������"></div></td>
</tr>
</form>
</table>';
}


if($up_w_mode==1){


echo '<form id="form_up_w" method="POST">
<table class="up_w_table" align="center" cellpadding="6px" cellspacing="0px">
<tr>
<td><div class="up_w_title">��������� � ������</div></td>
</tr>
<tr>
<td><input type="hidden" name="a_time" value="'.$time.'"><input id="up_w_sum" class="up_w_input" type="text" name="sum_up_w" autocomplete="off" placeholder="�� ������� �� �����: '.$mydm['money'].' �" value="'.$mydm['money'].'" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,\'.\').replace(/(\..*)\./g,\'$1\').replace(/(\..{4}).*/,\'$1\').replace(/^0([0-9]+)/,\'$1\');"></td>
</tr>
<tr>
<td><div class="up_w_button" onclick="if(document.getElementById(\'up_w_sum\').value==0){ return; } if(document.getElementById(\'up_w_sum\').value=='.$mydm['money'].'){ if(confirm(\'��������� ��� ����� ?\')){ document.getElementById(\'form_up_w\').submit(); } }else{ document.getElementById(\'form_up_w\').submit(); }">���������</div></td>
</tr>
</table>
</form>';


}


echo '</div>


<div class="up_title_from_m">���������� � ��������:</div>';


$np_pp=4;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str'])){ $np_num=$_GET['str']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM balance_up_m WHERE uid='$u_id'") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="np_def" href="/up/1/1#np_a">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="np_def" href="/up/1/1#np_a">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="np_now" href="/up/1/'.($n+1).'#np_a">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="np_def" href="/up/1/'.($n+1).'#np_a">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="np_def" href="/up/1/'.$n.'#np_a">'.$n.'</a>'; }
else{ $np_links.='<a class="np_def" href="/up/1/'.$n.'#np_a">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


if(!empty($np_links)){ echo '<a name="np_a" class="np_a"></a><div class="np_div">'.$np_links.'</div><br>'; }


echo '<div class="up_s_div">
<table class="up_s_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td width="25%" class="up_s_title" style="padding-left:20px;">����</td>
<td width="25%" class="up_s_title">�����</td>';
if(empty($mobile)){ echo '<td width="25%" class="up_s_title">����������</td>'; }
echo '<td width="25%" class="up_s_title">������</td>
</tr>';


$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT * FROM balance_up_m WHERE uid=$u_id ORDER BY id DESC LIMIT $np_start,$np_pp");


while($s_m=mysqli_fetch_assoc($s_q)){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
echo '<tr class="up_s_tr_'.$row_tr_n.'">
<td class="up_s_date">'.date('d.m.y H:i:s',$s_m['date']).'</td>
<td class="up_s_sum">'.$s_m['sum'];
if($s_m['bonus_s']>0){ echo ' (+'.($s_m['bonus_s']+0).')'; }
if($s_m['refback']>0){ echo ' (+'.($s_m['refback']+0).')'; }
echo '</td>';
if(empty($mobile)){ echo '<td class="up_s_batch">'.$s_m['batch'].'</td>'; }
echo '<td class="up_s_type"><div class="up_s_type_'.$s_m['type'].'"></div></td>
</tr>';
}


echo '</table></div>


<div class="up_title_from_w">���������� � ������� �� �����:</div>';


$np_pp=4;
$np_ss=10;


$np_num=1;
if(!empty($_GET['str_2'])){ $np_num=$_GET['str_2']; }
$np_num=preg_replace('#[^0-9]+#','',$np_num);
$np_num=(int)$np_num;
if(empty($np_num) || !is_numeric($np_num) || strlen($np_num)>10){ $np_num=1; }
$np_q=mysqli_query($db,"SELECT COUNT(*) FROM balance_up_w WHERE uid='$u_id'") or die('cant select np_q');
$np_m=mysqli_fetch_row($np_q);
$np_real=0+$np_m[0];
$np_max=ceil($np_real/$np_pp);
$np_links='';
if($np_num>$np_max){ $np_num=1; }
$np_start=$np_num*$np_pp-$np_pp;
if($np_max>1){
if($np_num-$np_ss>0 && $np_num-$np_ss!=1){ $np_links.='<a class="np_def" href="/up/2/1#np_a_2">1-'.($np_num-$np_ss).'</a>'; }
if($np_num-$np_ss==1){ $np_links.='<a class="np_def" href="/up/2/1#np_a_2">1</a>'; }
for($n=0;$n<$np_max;$n++){
if($np_num==($n+1)){ $np_links.='<a class="np_now" href="/up/2/'.($n+1).'#np_a_2">'.($n+1).'</a>'; }
elseif($n-1>$np_num-2-$np_ss && $n<$np_num+1+$np_ss){ $np_links.='<a class="np_def" href="/up/2/'.($n+1).'#np_a_2">'.($n+1).'</a>'; }
}
if($np_num+$np_ss<$n-1){
if($np_num+$np_ss+2==$n){ $np_links.='<a class="np_def" href="/up/2/'.$n.'#np_a_2">'.$n.'</a>'; }
else{ $np_links.='<a class="np_def" href="/up/2/'.$n.'#np_a_2">'.($np_num+$np_ss+2).'-'.$n.'</a>'; }
}
}


if(!empty($np_links)){ echo '<a name="np_a_2" class="np_a"></a><div class="np_div" style="margin-top:20px;">'.$np_links.'</div><br>'; }


echo '<div class="up_s_div">
<table class="up_s_table" align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td width="25%" class="up_s_title" style="padding-left:20px;">����</td>
<td width="25%" class="up_s_title">�����</td>';
if(empty($mobile)){ echo '<td width="25%" class="up_s_title">&nbsp;</td>'; }
echo '<td width="25%" class="up_s_title">������</td>
</tr>';


$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT * FROM balance_up_w WHERE uid=$u_id ORDER BY id DESC LIMIT $np_start,$np_pp");


while($s_m=mysqli_fetch_assoc($s_q)){
if($row_tr_n==1){ $row_tr_n=0; }else{ $row_tr_n++; }
echo '<tr class="up_s_tr_'.$row_tr_n.'">
<td class="up_s_date">'.date('d.m.y H:i:s',$s_m['date']).'</td>
<td class="up_s_sum">'.$s_m['sum'].'</td>';
if(empty($mobile)){ echo '<td class="up_s_batch"></td>'; }
echo '<td class="up_s_type"><div class="up_s_type_0">� ������</div></td>
</tr>';
}


echo '</table></div>


<script type="text/javascript">


var preorder_ajax=new XMLHttpRequest();
var preorder_can=0;


function preorder_ajax_send(){


if(preorder_can==1){ return; }
preorder_can=1;


var preorder_ajax_vars="sum="+document.getElementById("up_m_sum").value+"&type="+document.getElementById("up_m_type").value;


preorder_ajax.onreadystatechange=function(){
if(preorder_ajax.readyState==4){
if(preorder_ajax.status==200){
try{ eval(preorder_ajax.responseText); }
catch(e){}
}
preorder_can=0;
}
}
preorder_ajax.open("POST","/cabinet/up.php",true);
preorder_ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
preorder_ajax.send(preorder_ajax_vars);
}


</script>';


?>
