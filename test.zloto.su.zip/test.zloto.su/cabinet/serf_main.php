<?php


if(empty($serf_m)){ echo '������ ��������'; exit; }


echo '<table class="serf_head_menu_table" align="center" cellpadding="0px" cellspacing="10px">
<tr>
<td width="33%"><a href="/serf_main/">Ѩ�����</a></td>
<td width="34%"><a href="/serf_buy/">������</a></td>
<td width="33%"><a href="/serf_edit_list/">��� ������</a></td>
</tr>
</table>


<div id="serf_head_message" class="serf_head_message"><div class="serf_main_profit">���������� ������: <span id="serf_profit">+0.0000</span> ���.</div></div>';


if($u_id==$admin_uid && !empty($d['serf_need'])){
mysqli_query($db,"UPDATE data SET serf_need=0") or die('cant serf_need');
echo '<script type="text/javascript">if(document.getElementById("left_menu_serf")!=null){ document.getElementById("left_menu_serf").className="left_menu_def"; }</script>';
}


// ____________________ �����������, �������� ������ ������ � Ѩ������ ____________________


if($d['serf_opt']<$time){
$serf_d_old=$time-86400*$serf_d_old;
mysqli_query($db,"UPDATE data SET serf_opt='".($time+3600)."'") or die('cant update data');
mysqli_query($db,'DELETE FROM serf_clicks WHERE date_2<'.$time);
mysqli_query($db,'DELETE FROM serf_list WHERE balance<0.10 AND date_2!=0 AND date_2<'.$serf_d_old);
mysqli_query($db,"OPTIMIZE TABLE serf_clicks,serf_list") or die('cant optimize serf');
}


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if($u_id==$admin_uid && empty($is_admin) && !empty($_POST)){
$_POST=array();
echo '<script type="text/javascript">alert("������������� � �������");</script>';
}


if($u_id==$admin_uid && !empty($is_admin) && !empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


// ____________________ �������� ____________________


if(!empty($_POST['d_id']) && !empty($_POST['d_type']) && ($_POST['d_type']==1 || $_POST['d_type']==2)){


$d_id=preg_replace('#[^0-9]+#','',$_POST['d_id']);
$d_id=number_format($d_id,0,'','');
if(empty($d_id) || !is_numeric($d_id) || strlen($d_id)>10){ exit; }


$s_q=mysqli_query($db,"SELECT * FROM serf_list WHERE id=$d_id LIMIT 1");
$s_m=mysqli_fetch_assoc($s_q);
if(empty($s_m['id']) || empty($s_m['uid'])){ exit; }


if($_POST['d_type']==1){ $message='Ѹ����� �� ������ ���������.<br>������ ���������� �� ������.'; }
else{ $message='Ѹ����� �����.<br>������ ���������� �� ������.'; }


mysqli_query($db,"DELETE FROM serf_list WHERE id=$d_id LIMIT 1") or die('cant delete');
mysqli_query($db,"UPDATE users SET balance=(balance+".$s_m['balance']."),message=CONCAT('".date('d.m.y H:i:s',$time)."<br>$message<hr>',message) WHERE uid='".$s_m['uid']."' LIMIT 1") or die('cant update user balance');


}


// ____________________ ����� � ������������� ____________________


if(!empty($_POST['pause_id']) && isset($_POST['pause_v'])){
$pause_id=preg_replace('#[^0-9]+#','',$_POST['pause_id']);
$pause_id=number_format($pause_id,0,'','');
$pause_v=preg_replace('#[^01]+#','',$_POST['pause_v']);
$pause_v=number_format($pause_v,0,'','');
if(empty($pause_id) || !is_numeric($pause_id) || strlen($pause_id)>10){ exit; }
if(is_numeric($pause_v) && strlen($pause_v)==1 && ($pause_v==0 || $pause_v==1)){
mysqli_query($db,"UPDATE serf_list SET pause=$pause_v WHERE id=$pause_id LIMIT 1") or die('cant pause');
}
}


// ____________________ ��������� ____________________


if(!empty($_POST['accept_id'])){
$accept_id=preg_replace('#[^0-9]+#','',$_POST['accept_id']);
$accept_id=number_format($accept_id,0,'','');
if(empty($accept_id) || !is_numeric($accept_id) || strlen($accept_id)>10){ exit; }
mysqli_query($db,"UPDATE serf_list SET modering=0 WHERE id=$accept_id LIMIT 1") or die('cant modering');
}


}


// ____________________ ��������� ����������� ____________________


$serf_up_ban=0;


if($mydm['up_m']<$serf_must_up_m){
$serf_up_ban=1;
echo '<div class="serf_main_must_up_m">��� ��������� �� ������� ��������� ������ � �������� �� '.$serf_must_up_m.' ���.</div>';
}


// ____________________ ������ ���� ������ ����� ��� ____________________


$serf_time_ban=0;


if($mydm['serf_ban']>$time){
$serf_time_ban=1;
echo '<div class="serf_main_banned">�� �������� '.$serf_mistake_c.' ���. Ѹ����� ��������.<br>�� ������ ������� ��������: <span id="timer_word_id"></span></div>
<script type="text/javascript">
var timer_word_st=new Date().getTime().toString().substr(0,10);
var timer_word_total='.($mydm['serf_ban']-$time).';
timer_word();
</script>';
}


if($serf_up_ban==1 || $serf_time_ban==1 && (!isset($_SESSION['serf_cant']) || $_SESSION['serf_cant']!=1)){ $_SESSION['serf_cant']=1; }
if($serf_up_ban==0 && $serf_time_ban==0 && (isset($_SESSION['serf_cant']) && $_SESSION['serf_cant']==1)){ $_SESSION['serf_cant']=0; }
if(!isset($_SESSION['serf_cant'])){ $_SESSION['serf_cant']=0; }


echo '<script type="text/javascript">


var serf_psum=0.0000;


var eventMethod=window.addEventListener?"addEventListener":"attachEvent";
var eventer=window[eventMethod];
var messageEvent=eventMethod=="attachEvent"?"onmessage":"message";


eventer(messageEvent,function(event){


var serf_profit_found=event.data.match(/sp([0-9\.]{1,15})/);


if(serf_profit_found!=undefined && serf_profit_found[1]!=undefined){
serf_psum=Number(serf_psum);
serf_psum=(serf_psum+Number(serf_profit_found[1])).toFixed(4);
document.getElementById("serf_profit").innerHTML="+"+serf_psum;
}


var serf_my_balance_found=event.data.match(/my\_balance([0-9\.]{1,15})/);


if(serf_my_balance_found!=undefined && serf_my_balance_found[1]!=undefined){
document.getElementById("my_balance").innerHTML=serf_my_balance_found[1];
}


var serf_my_money_found=event.data.match(/my\_money([0-9\.]{1,15})/);


if(serf_my_money_found!=undefined && serf_my_money_found[1]!=undefined){
document.getElementById("my_money").innerHTML=serf_my_money_found[1];
}


if(event.data.match(/reload/)!=undefined){
location.href=location.href;
}


});


function serfing(serf_id){
document.getElementById("serf_"+serf_id).remove();
document.cookie="serf_act=1;domain=.'.$_SERVER['HTTP_HOST'].';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.cookie="serf_url=;domain=.'.$_SERVER['HTTP_HOST'].';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.cookie="serf_id="+serf_id+";domain=.'.$_SERVER['HTTP_HOST'].';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
window.open("'.$serf_frame.'/serf_view/","_blank");
}


</script>';


echo '<div class="serf_main_notice">������������ ����� ������������� ������ ���� ������</div>';


$serf_links=0;


// ____________________ ������������ ____________________


if($u_id!=$admin_uid){
$s_q=mysqli_query($db,"SELECT * FROM serf_list WHERE pause=0 AND modering=0 AND uid!=$u_id ORDER BY to_sort DESC");
while($s_m=mysqli_fetch_assoc($s_q)){
$price=number_format(($s_m['cost']+$s_m['admin']+$s_m['to_sp_1']+$s_m['to_sp_2']+$s_m['to_sp_3']),4,'.','')+0;
$amount=preg_replace('#\..*#','',$s_m['balance']/$price+0);
if($amount>0 && !in_array($s_m['id'],$serf_my_clicks)){
$serf_links=1;


$cost=$s_m['cost']+0;


if($serf_refback_m==1 && !empty($_SESSION['serf_rb'])){
$cost=$s_m['cost']+$s_m['to_sp_1']*$_SESSION['serf_rb']/100;
$cost=number_format($cost,4,'.','')+0;
}


echo '<table id="serf_'.$s_m['id'].'" class="serf_main_table" cellpadding="0px" cellspacing="10px">
<tr>
<td class="serf_main_description"><div onclick="serfing('.$s_m['id'].');">'.$s_m['description'].'</div></td>
</tr>
<tr>
<td class="serf_main_info">
<span class="serf_main_info_price">'.$cost.'</span>
<span class="serf_main_info_view_time">'.$s_m['view_time'].'</span>
<span class="serf_main_info_amount">'.$amount.'</span>';
if($s_m['active']==1){ echo '<span class="serf_main_info_active" title="�������� ����">A</span>'; }
else{ echo '<span class="serf_main_info_noactive"></span>'; }
echo '<a class="serf_main_check" target="_blank" href="https://online.drweb.com/result/?url='.$s_m['url'].'" title="��������� �� ������"></a>';
echo '</td>
</tr>
</table>';


}
}
}


if($u_id!=$admin_uid && $serf_links==0){ echo '<div class="serf_main_no_links"><span class="serf_main_no_links_img"></span>��������� � ��������� ������ ���. ������� �����.</div>'; }


// ____________________ ����� ____________________


$premod=array();
$simple=array();
$paused=array();
$nobalance=array();


if($u_id==$admin_uid){
$s_q=mysqli_query($db,"SELECT * FROM serf_list ORDER BY to_sort DESC");
while($s_m=mysqli_fetch_assoc($s_q)){
$price=number_format(($s_m['cost']+$s_m['admin']+$s_m['to_sp_1']+$s_m['to_sp_2']+$s_m['to_sp_3']),4,'.','')+0;
$amount=preg_replace('#\..*#','',$s_m['balance']/$price+0);
if($s_m['modering']==1){ $premod[]=$s_m; continue; }
if($s_m['pause']==0 && $amount>0 && $serf_simple==0){ continue; }
if($s_m['pause']==0 && $amount>0 && $s_m['uid']!=$admin_uid){ $simple[]=$s_m; continue; }
if($s_m['pause']==0 && $amount>0 && $s_m['uid']==$admin_uid && $serf_own==1 && !in_array($s_m['id'],$serf_my_clicks)){ $simple[]=$s_m; continue; }
if($s_m['pause']==1 && $serf_paused==1 && $s_m['uid']!=$admin_uid){ $paused[]=$s_m; continue; }
if($s_m['pause']==0 && $serf_nobalance==1 && $amount==0 && $s_m['uid']!=$admin_uid){ $nobalance[]=$s_m; continue; }
}


echo '
<form id="d_form" method="POST">
<input type="hidden" name="a_time" value="'.$time.'">
<input id="d_id" type="hidden" name="d_id" value="">
<input id="d_type" type="hidden" name="d_type" value="">
</form>


<form id="pause_form" method="POST">
<input type="hidden" name="a_time" value="'.$time.'">
<input id="pause_id" type="hidden" name="pause_id" value="">
<input id="pause_v" type="hidden" name="pause_v" value="">
</form>


<form id="accept_form" method="POST">
<input type="hidden" name="a_time" value="'.$time.'">
<input id="accept_id" type="hidden" name="accept_id" value="">
</form>


<script language="javascript">


function preview(url){
document.cookie="serf_act=0;domain=.'.$_SERVER['HTTP_HOST'].';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
document.cookie="serf_url="+url+";domain=.'.$_SERVER['HTTP_HOST'].';path=/;expires=Fri,31 Dec 9999 23:59:59 GMT";
window.open("'.$serf_frame.'/serf_view/","_blank");
}


function del(d_id,d_type){
if(!confirm("����� ������� ?")){ return; }
document.getElementById("d_id").value=d_id;
document.getElementById("d_type").value=d_type;
document.getElementById("d_form").submit();
}


function pause(pause_id,pause_v){
if(pause_v==0 && !confirm("����� ����� ?")){ return; }
if(pause_v==1 && !confirm("����� ��������� ?")){ return; }
document.getElementById("pause_id").value=pause_id;
document.getElementById("pause_v").value=pause_v;
document.getElementById("pause_form").submit();
}


function accept(accept_id){
if(!confirm("����� �������� ?")){ return; }
document.getElementById("accept_id").value=accept_id;
document.getElementById("accept_form").submit();
}


</script>';


}


// ____________________ �� ������������ ____________________


if(!empty($premod)){ echo '<div class="serf_main_premod_title">������ ��� ��������</div>'; }


foreach($premod as $s_m){
$price=number_format(($s_m['cost']+$s_m['admin']+$s_m['to_sp_1']+$s_m['to_sp_2']+$s_m['to_sp_3']),4,'.','')+0;
$amount=preg_replace('#\..*#','',$s_m['balance']/$price+0);


echo '<table id="serf_'.$s_m['id'].'" class="serf_main_table" cellpadding="0px" cellspacing="10px">
<tr><td class="serf_main_description" colspan="4"><div onclick="preview(\''.$s_m['url'].'\');">'.$s_m['description'].'</div></td></tr>
<tr><td class="serf_main_url" colspan="4"><a target="_blank" href="'.$s_m['url'].'">'.$s_m['url'].'</a></td></tr>
<tr>
<td class="serf_main_date" colspan="4">
<span>�������:</span> <font>'.date('d.m.y H:i',$s_m['date']).'</font> <span>��������:</span> <font>';
if(!empty($s_m['date_2'])){ echo date('d.m.y H:i',$s_m['date_2']); }
else{ echo '��� �� ����'; }
echo '</font>
</td>
</tr>
<tr>
<td class="serf_main_info" colspan="4">
<span class="serf_main_info_price">'.($s_m['cost']+0).'</span>
<span class="serf_main_info_view_time">'.$s_m['view_time'].'</span>
<span class="serf_main_info_amount">'.$amount.'</span>';
if($s_m['active']==1){ echo '<span class="serf_main_info_active" title="�������� ����">A</span>'; }
else{ echo '<span class="serf_main_info_noactive"></span>'; }
echo '<a class="serf_main_check" target="_blank" href="https://online.drweb.com/result/?url='.$s_m['url'].'" title="��������� �� ������"></a>';
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<span class="serf_main_views">'.$s_m['views'].'</span>
<span class="serf_main_id">�'.$s_m['id'].'</span>
<span class="serf_main_balance">'.($s_m['balance']+0).'</span>
<img class="serf_main_avatar" src="'.$s_m['avatar'].'">
<a class="serf_main_login" target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a>
</td>
</tr>
<tr>
<td class="serf_main_delete"><div onclick="del('.$s_m['id'].',1);">�������</div></td>';
if($s_m['pause']==0){ echo '<td class="serf_main_pause_0"><div onclick="pause('.$s_m['id'].',1);">�����&nbsp;���</div></td>'; }
else{ echo '<td class="serf_main_pause_1"><div onclick="pause('.$s_m['id'].',0);">�����&nbsp;����</div></td>'; }
echo '<td class="serf_main_accept"><div onclick="accept('.$s_m['id'].');">��������</div></td>';
if($s_m['uid']==$admin_uid){ echo '<td class="serf_main_edit"><a href="/serf_edit_form/'.$s_m['id'].'">�������������</a></td>'; }
else{ echo '<td class="serf_main_edit"><a href="/serf_edit_admin/'.$s_m['id'].'">�������������</a></td>'; }
echo '</tr></table>';


}


if(!empty($simple)){ echo '<div class="serf_main_simple_title">������� ������</div>'; }


foreach($simple as $s_m){
$price=number_format(($s_m['cost']+$s_m['admin']+$s_m['to_sp_1']+$s_m['to_sp_2']+$s_m['to_sp_3']),4,'.','')+0;
$amount=preg_replace('#\..*#','',$s_m['balance']/$price+0);


echo '<table id="serf_'.$s_m['id'].'" class="serf_main_table" cellpadding="0px" cellspacing="10px">
<tr><td class="serf_main_description" colspan="4"><div onclick="serfing('.$s_m['id'].');">'.$s_m['description'].'</div></td></tr>
<tr><td class="serf_main_url" colspan="4"><a target="_blank" href="'.$s_m['url'].'">'.$s_m['url'].'</a></td></tr>
<tr>
<td class="serf_main_date" colspan="4">
<span>�������:</span> <font>'.date('d.m.y H:i',$s_m['date']).'</font> <span>��������:</span> <font>';
if(!empty($s_m['date_2'])){ echo date('d.m.y H:i',$s_m['date_2']); }
else{ echo '��� �� ����'; }
echo '</font>
</td>
</tr>
<tr>
<td class="serf_main_info" colspan="4">
<span class="serf_main_info_price">'.($s_m['cost']+0).'</span>
<span class="serf_main_info_view_time">'.$s_m['view_time'].'</span>
<span class="serf_main_info_amount">'.$amount.'</span>';
if($s_m['active']==1){ echo '<span class="serf_main_info_active" title="�������� ����">A</span>'; }
else{ echo '<span class="serf_main_info_noactive"></span>'; }
echo '<a class="serf_main_check" target="_blank" href="https://online.drweb.com/result/?url='.$s_m['url'].'" title="��������� �� ������"></a>';
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<span class="serf_main_views">'.$s_m['views'].'</span>
<span class="serf_main_id">�'.$s_m['id'].'</span>
<span class="serf_main_balance">'.($s_m['balance']+0).'</span>
<img class="serf_main_avatar" src="'.$s_m['avatar'].'">
<a class="serf_main_login" target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a>
</td>
</tr>
<tr>
<td class="serf_main_delete"><div onclick="del('.$s_m['id'].',2);">�������</div></td>';
if($s_m['pause']==0){ echo '<td class="serf_main_pause_0"><div onclick="pause('.$s_m['id'].',1);">�����&nbsp;���</div></td>'; }
else{ echo '<td class="serf_main_pause_1"><div onclick="pause('.$s_m['id'].',0);">�����&nbsp;����</div></td>'; }
echo '<td></td>';
if($s_m['uid']==$admin_uid){ echo '<td class="serf_main_edit"><a href="/serf_edit_form/'.$s_m['id'].'">�������������</a></td>'; }
else{ echo '<td class="serf_main_edit"><a href="/serf_edit_admin/'.$s_m['id'].'">�������������</a></td>'; }
echo '</tr></table>';


}


if(!empty($paused)){ echo '<div class="serf_main_paused_title">������ �� �����</div>'; }


foreach($paused as $s_m){
$price=number_format(($s_m['cost']+$s_m['admin']+$s_m['to_sp_1']+$s_m['to_sp_2']+$s_m['to_sp_3']),4,'.','')+0;
$amount=preg_replace('#\..*#','',$s_m['balance']/$price+0);


echo '<table id="serf_'.$s_m['id'].'" class="serf_main_table" cellpadding="0px" cellspacing="10px">
<tr><td class="serf_main_description" colspan="4"><div onclick="preview(\''.$s_m['url'].'\');">'.$s_m['description'].'</div></td></tr>
<tr><td class="serf_main_url" colspan="4"><a target="_blank" href="'.$s_m['url'].'">'.$s_m['url'].'</a></td></tr>
<tr>
<td class="serf_main_date" colspan="4">
<span>�������:</span> <font>'.date('d.m.y H:i',$s_m['date']).'</font> <span>��������:</span> <font>';
if(!empty($s_m['date_2'])){ echo date('d.m.y H:i',$s_m['date_2']); }
else{ echo '��� �� ����'; }
echo '</font>
</td>
</tr>
<tr>
<td class="serf_main_info" colspan="4">
<span class="serf_main_info_price">'.($s_m['cost']+0).'</span>
<span class="serf_main_info_view_time">'.$s_m['view_time'].'</span>
<span class="serf_main_info_amount">'.$amount.'</span>';
if($s_m['active']==1){ echo '<span class="serf_main_info_active" title="�������� ����">A</span>'; }
else{ echo '<span class="serf_main_info_noactive"></span>'; }
echo '<a class="serf_main_check" target="_blank" href="https://online.drweb.com/result/?url='.$s_m['url'].'" title="��������� �� ������"></a>';
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<span class="serf_main_views">'.$s_m['views'].'</span>
<span class="serf_main_id">�'.$s_m['id'].'</span>
<span class="serf_main_balance">'.($s_m['balance']+0).'</span>
<img class="serf_main_avatar" src="'.$s_m['avatar'].'">
<a class="serf_main_login" target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a>
</td>
</tr>
<tr>
<td class="serf_main_delete"><div onclick="del('.$s_m['id'].',2);">�������</div></td>';
if($s_m['pause']==0){ echo '<td class="serf_main_pause_0"><div onclick="pause('.$s_m['id'].',1);">�����&nbsp;���</div></td>'; }
else{ echo '<td class="serf_main_pause_1"><div onclick="pause('.$s_m['id'].',0);">�����&nbsp;����</div></td>'; }
echo '<td></td>';
if($s_m['uid']==$admin_uid){ echo '<td class="serf_main_edit"><a href="/serf_edit_form/'.$s_m['id'].'">�������������</a></td>'; }
else{ echo '<td class="serf_main_edit"><a href="/serf_edit_admin/'.$s_m['id'].'">�������������</a></td>'; }
echo '</tr></table>';


}


if(!empty($nobalance)){ echo '<div class="serf_main_nobalance_title">������ ��� �����</div>'; }


foreach($nobalance as $s_m){
$price=number_format(($s_m['cost']+$s_m['admin']+$s_m['to_sp_1']+$s_m['to_sp_2']+$s_m['to_sp_3']),4,'.','')+0;
$amount=preg_replace('#\..*#','',$s_m['balance']/$price+0);


echo '<table id="serf_'.$s_m['id'].'" class="serf_main_table" cellpadding="0px" cellspacing="10px">
<tr><td class="serf_main_description" colspan="4"><div onclick="preview(\''.$s_m['url'].'\');">'.$s_m['description'].'</div></td></tr>
<tr><td class="serf_main_url" colspan="4"><a target="_blank" href="'.$s_m['url'].'">'.$s_m['url'].'</a></td></tr>
<tr>
<td class="serf_main_date" colspan="4">
<span>�������:</span> <font>'.date('d.m.y H:i',$s_m['date']).'</font> <span>��������:</span> <font>';
if(!empty($s_m['date_2'])){ echo date('d.m.y H:i',$s_m['date_2']); }
else{ echo '��� �� ����'; }
echo '</font>
</td>
</tr>
<tr>
<td class="serf_main_info" colspan="4">
<span class="serf_main_info_price">'.($s_m['cost']+0).'</span>
<span class="serf_main_info_view_time">'.$s_m['view_time'].'</span>
<span class="serf_main_info_amount">'.$amount.'</span>';
if($s_m['active']==1){ echo '<span class="serf_main_info_active" title="�������� ����">A</span>'; }
else{ echo '<span class="serf_main_info_noactive"></span>'; }
echo '<a class="serf_main_check" target="_blank" href="https://online.drweb.com/result/?url='.$s_m['url'].'" title="��������� �� ������"></a>';
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<span class="serf_main_views">'.$s_m['views'].'</span>
<span class="serf_main_id">�'.$s_m['id'].'</span>
<span class="serf_main_balance">'.($s_m['balance']+0).'</span>
<img class="serf_main_avatar" src="'.$s_m['avatar'].'">
<a class="serf_main_login" target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a>
</td>
</tr>
<tr>
<td class="serf_main_delete"><div onclick="del('.$s_m['id'].',2);">�������</div></td>';
if($s_m['pause']==0){ echo '<td class="serf_main_pause_0"><div onclick="pause('.$s_m['id'].',1);">�����&nbsp;���</div></td>'; }
else{ echo '<td class="serf_main_pause_1"><div onclick="pause('.$s_m['id'].',0);">�����&nbsp;����</div></td>'; }
echo '<td></td>';
if($s_m['uid']==$admin_uid){ echo '<td class="serf_main_edit"><a href="/serf_edit_form/'.$s_m['id'].'">�������������</a></td>'; }
else{ echo '<td class="serf_main_edit"><a href="/serf_edit_admin/'.$s_m['id'].'">�������������</a></td>'; }
echo '</tr></table>';


}


?>
