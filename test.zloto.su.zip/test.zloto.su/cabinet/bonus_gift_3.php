<?php


if(empty($bonus_gift_3_m)){ echo '������ ��������';  exit; }


echo '<div class="title">'.$bonus_gift_3_title.'</div>';


// ____________________ ������ � ������ ____________________



if($mobile==0 && !empty($ads_banner_2_m)){


$ads_banner_2_c='ads_banner_2_c_'.$page;
$ads_banner_2_c=$$ads_banner_2_c;
if(!empty($ads_banner_2_c)){
$ads_value=str_replace('<','$ads_banner_2_last[]=array(',$d['ads_banner_2_last']);
$ads_banner_2_last=array();
eval($ads_value);
for($n=0;$n<sizeof($ads_banner_2_last);$n++){
if($ads_banner_2_last[$n][1]<$time){ array_splice($ads_banner_2_last,$n,1); $n--; }
}
shuffle($ads_banner_2_last);
echo '<div class="bonus_gift_3_banner_2">';
for($n=0;$n<$ads_banner_2_c;$n++){
if(!empty($ads_banner_2_last[$n])){ echo '<a onclick="bonus_gift_3_show();" target="_blank" href="'.$serf_site.'/?ads=banner_2&id='.$ads_banner_2_last[$n][0].'"><img src="'.$ads_banner_2_last[$n][2].'"></a>'; }
else{ echo '<a onclick="bonus_gift_3_show();" target="_blank" href="'.$serf_site.'/ads_banner_2/"><img src="'.$serf_site.'/images/cabinet/ads_is_banner/46860.gif"></a>'; }
}
echo '</div>
<script type="text/javascript">


function bonus_gift_3_show(){
if(document.getElementById(\'bonus_gift_3_message_banner\')!=null){
document.getElementById(\'bonus_gift_3_message_banner\').style.display=\'none\';
document.getElementById(\'bonus_gift_3_button\').style.display=\'block\';
}
}


</script>';
}


}


$bonus_gift_3_min=0;
$bonus_gift_3_max=0;
$bonus_gift_3_plan='';


foreach($bonus_gift_3_a as $v){
if($mydm['up_m']>=$v[0]){ $bonus_gift_3_min=$v[1]; $bonus_gift_3_max=$v[2]; }
$bonus_gift_3_plan.='<tr><td>��� ���������� �� '.$v[0].' �.&nbsp;</td><td> � ����, ����� �� '.number_format($v[1]/100,2,'.','').' �� '.number_format($v[2]/100,2,'.','').' �.</td></tr>';
}


if($bonus_gift_3_path=='balance'){ $bonus_gift_3_text.=' �� �������'; }
else{ $bonus_gift_3_text.=' �� �����'; }


echo '<div class="bonus_gift_3_text">
<div class="bonus_gift_3_text_1">'.$bonus_gift_3_text.'</div>
<div class="bonus_gift_3_text_2">���� ����� ������ �� <span>'.number_format($bonus_gift_3_min/100,2,'.','').'</span> �� <span>'.number_format($bonus_gift_3_max/100,2,'.','').'</span> �.</div>';
if(sizeof($bonus_gift_3_a)>1){
echo '<div class="bonus_gift_3_text_3"><table align="center" cellpadding="0" cellspacing="0">'.$bonus_gift_3_plan.'</table></div>';
}
echo '</div>';


if($bonus_gift_3_bet_time==0){ $bonus_gift_3_bet_time=$time+10; }


if($mydm['bets_time']+$bonus_gift_3_bet_time<$time && $mydm['balance']>=$bonus_gift_3_bet_sum){
$message='<div class="bonus_gift_3_message_bet">��� ��������� ������ �������� ������</div>';
}


if(empty($bonus_gift_3_time) || $bonus_gift_3_time<600){ echo 'bonus_gift_3 data error'; exit; }


if(!isset($_SESSION['a_time'])){ $_SESSION['a_time']=0; }


if(!empty($_POST['a_time']) && $_SESSION['a_time']!=$_POST['a_time']){


$_POST['a_time']=preg_replace("#[^0-9]+#",'',$_POST['a_time']);
$_SESSION['a_time']=0+substr($_POST['a_time'],0,20);


if($bonus_gift_3_bet_time==0 || ($bonus_gift_3_bet_time>0 && $mydm['balance']<$bonus_gift_3_bet_sum)){ $bonus_gift_3_bet_time=$time+10; }


if($mydm['bets_time']+$bonus_gift_3_bet_time>$time){


if($time-$mydm['bonus_gift_3_time']>$bonus_gift_3_time){


if($bonus_gift_3_g==1 || ($bonus_gift_3_g==2 && $mydm['soc_type']=='vkontakte') || ($bonus_gift_3_g==3 && $mydm['soc_type']=='vkontakte')){
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,'https://api.vk.com/method/groups.isMember?v='.$vk_v.'&group_id='.$vk_group_id.'&access_token='.$vk_at.'&user_id='.$mydm['soc_id']);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($curl,CURLOPT_REFERER,$_SERVER['HTTP_HOST']);
curl_setopt($curl,CURLOPT_USERAGENT,$_SERVER['HTTP_USER_AGENT']);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
$result=curl_exec($curl);
curl_close($curl);
$result=json_decode($result,true);
}
else{
$result['response']=1;
}


if($result['response']=='1'){


if($bonus_gift_3_g==3 && $mydm['soc_type']=='vkontakte'){ $bonus_gift_3_up_m=0; }


if($mydm['up_m']<$bonus_gift_3_up_m){
$message='<div class="bonus_gift_3_message_up_m">��� ��������� ������ ��������� ������ � �������� �� '.$bonus_gift_3_up_m.' ���.</div>';
}
else{


$bonus_gift_3_sum=rand($bonus_gift_3_min,rand($bonus_gift_3_min,$bonus_gift_3_max));
$bonus_gift_3_sum=number_format($bonus_gift_3_sum/100,2,'.','');
$mydm['bonus_gift_3_time']=$time;
mysqli_query($db,"INSERT INTO bonus_gift_3 (uid,login,avatar,sum,date,date_word) VALUES ('".$u_id."','".$mydm['login']."','".$mydm['avatar']."','".$bonus_gift_3_sum."','$time','".date('d.m.y H:i:s',$time)."')") or die('cant insert bonus_gift_3');
$last_id=0+mysqli_insert_id($db);
mysqli_query($db,"UPDATE users SET $bonus_gift_3_path=$bonus_gift_3_path+$bonus_gift_3_sum,bonus_gift_3_time=$time,bonus_gift_3_c=bonus_gift_3_c+1,bonus_gift_3_r=bonus_gift_3_r+$bonus_gift_3_sum WHERE uid=$u_id LIMIT 1") or die('cant update balance');
$bonus_gift_3_c=$last_id;
mysqli_query($db,"UPDATE data SET bonus_gift_3_c=$bonus_gift_3_c,bonus_gift_3_r=bonus_gift_3_r+$bonus_gift_3_sum LIMIT 1") or die('cant update data');


// ������� ������ ������
if($bonus_gift_3_c>$bonus_gift_3_c){
mysqli_query($db,'DELETE FROM bonus_gift_3 WHERE id<'.($bonus_gift_3_c-$bonus_gift_3_c+1));
mysqli_query($db,"OPTIMIZE TABLE bonus_gift_3") or die('cant optimize bonus_gift_3');
}



$mydm[$bonus_gift_3_path]+=$bonus_gift_3_sum;
$mydm[$bonus_gift_3_path]=number_format($mydm[$bonus_gift_3_path],4,'.','');


$t_seconds=$bonus_gift_3_time-1;
$t_d=(int)($t_seconds/86400); $t_h=(int)(($t_seconds-$t_d*86400)/3600); $t_m=(int)(($t_seconds-$t_d*86400-$t_h*3600)/60); $t_s=(int)($t_seconds-$t_d*86400-$t_h*3600-$t_m*60);
if($t_h<10){ $t_h='0'.$t_h; } if($t_m<10){ $t_m='0'.$t_m; } if($t_s<10){ $t_s='0'.$t_s; }
$t_d.='�'; $t_h.='�'; $t_m.='�'; $t_s.='�';
if($t_d=='0�'){ $t_d=''; } if($t_d=='' && $t_h=='00�'){ $t_h=''; } if($t_d=='' && $t_h=='' && $t_m=='00�'){ $t_m=''; }
$t_w=$t_d.$t_h.$t_m;
if($t_seconds<60){ $t_w.=$t_s; }
$t_w=preg_replace('#^0#','',$t_w);


$message='<script type="text/javascript">
if(document.getElementById("bonus_gift_3_menu")!=null){ document.getElementById("bonus_gift_3_menu").innerHTML=\'<img src="/images/pages/left/left_menu_bonus_gift_3.png">�����: '.$t_w.'\'; }
document.getElementById("my_'.$bonus_gift_3_path.'").innerHTML="'.$mydm[$bonus_gift_3_path].'";
document.getElementById("'.$bonus_gift_3_path.'_coin").style.display="block";
setTimeout(\'document.getElementById("'.$bonus_gift_3_path.'_coin").style.display="none";\',3000);
</script>
<div class="bonus_gift_3_message_gif">�� �������� <span>'.$bonus_gift_3_sum.'</span> �.</div>';


}


}
else{ $message='<div class="bonus_gift_3_message_link">��� ��������� ������ ����������� �� ��� ������ - <a href="'.$vk_group_link.'" target="_blank">'.$vk_group_link.'</a></div>'; }
}
else{
$message='<div class="bonus_gift_3_message_got">�� ��� �������� ����� �� ���� ������!</div>';
}
}
}


echo $message;


if($time-$mydm['bonus_gift_3_time']>$bonus_gift_3_time){
$bonus_gift_3_button='style="display:block;"';
if($mobile==0 && $bonus_gift_3_click==1){
$bonus_gift_3_button='style="display:none;"';
echo '<div id="bonus_gift_3_message_banner" class="bonus_gift_3_message_banner" style="display:block;">��� ��������� ������ �������� �� �������</div>';
}
echo '<form id="form_bonus_gift_3" style="display:none;" method="POST"><input type="hidden" name="a_time" value="'.$time.'"></form>
<div id="bonus_gift_3_button" '.$bonus_gift_3_button.' class="bonus_gift_3_button" onclick="document.getElementById(\'form_bonus_gift_3\').submit();">��������</div>';
}
else{
echo '<div class="bonus_gift_3_until">�� ���������� ������ ��������: <span id="timer_word_id"></span></div>
<script type="text/javascript">
var timer_word_st=new Date().getTime().toString().substr(0,10);
var timer_word_total='.($bonus_gift_3_time-($time-$mydm['bonus_gift_3_time'])).';
timer_word();
</script>';
}


echo '<div class="bonus_gift_3_s_word">��������� '.$bonus_gift_3_c.' �������</div>


<table class="bonus_gift_3_s_table" cellpadding="0" cellspacing="0">
<tr>
<td class="bonus_gift_3_s_title" style="text-align:center;">#</td>
<td class="bonus_gift_3_s_title" colspan="2">������������</td>
<td class="bonus_gift_3_s_title">�����</td>
<td class="bonus_gift_3_s_title">����</td>
</tr>';


$row_tr_n=0;


$s_q=mysqli_query($db,"SELECT * FROM bonus_gift_3 ORDER BY id DESC LIMIT ".$bonus_gift_3_c) or die('cant select last bonus_gift_3');
while($s_m=mysqli_fetch_assoc($s_q)){
if($row_tr_n==1){ $row_tr_n=0; } else { $row_tr_n++; }
$profile_link=md5($s_m['uid'].$profile_hash);
$profile_link=$s_m['uid'].'_'.substr($profile_link,0,4);
echo '<tr class="bonus_gift_3_s_tr_'.$row_tr_n.'">
<td class="bonus_gift_3_s_num">'.$s_m['id'].'</td>';
if($u_id==$admin_uid){
echo '<td class="bonus_gift_3_s_avatar"><a target="_blank" href="/profile/'.$profile_link.'"><img src="'.$s_m['avatar'].'"></a></td>
<td class="bonus_gift_3_s_login"><a target="_blank" href="/profile/'.$profile_link.'">'.$s_m['login'].'</a></td>';
}
else{
echo '<td class="bonus_gift_3_s_avatar"><img src="'.$s_m['avatar'].'"></td>
<td class="bonus_gift_3_s_login">'.$s_m['login'].'</td>';
}
echo '<td class="bonus_gift_3_s_sum">'.$s_m['sum'].' �.</td>
<td class="bonus_gift_3_s_date">'.$s_m['date_word'].'</td>
</tr>';
}
echo '</table>';


?>
